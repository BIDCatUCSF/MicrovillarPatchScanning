function[]=detect_microvilli_master_function_w_cluster(n_curve1,f_curve1,c_min,c_max,path_villi_ch1_init,path_villi_ch1_final,ens_curve_map,ens_curve_map_mask,small_thresh_from_user,i_curve1,cluster_curve1)

%This is a function that detects microvilli. This is the functionalized
%form of the code that was under the "Detect Microvilli" button in version
%19 of code.

%The only difference for this code is that it takes and saves information
%about the puncta (clusters). 

% inputs
% n_curve1=node matrix containing all curvature information
% f_curve1=face matrix for plotting
% c_min=minimum curvature selected by user person
% c_max=maximum curvature selected by user person
% path_villi_ch1_init=folder to put initially found villi
% path_villi_ch1_final=folder to put actual villi after watershed
% small_thresh_from_user = threshold valueto merge weakly overlap villi
% i_curve1=node matrix containing all intensity information
% cluster_curve1 = node matrix containing cluster information



%making a plot

figure, plotmesh(n_curve1,f_curve1); shading interp; title('Ch1 - Curvature'); caxis([-0.5,0.5]); colorbar;
colormap(ens_curve_map);freezeColors; hold on;
%finding extrema in z
z_low=min(n_curve1(:,3));
z_high=max(n_curve1(:,3));

%counter for preliminary peaks
count_prelim=1;

%declaring cell array
cell_prelim_peak=cell(5000,1);

%picking a spot on the mesh to examine the neighbors
the_point_arr=1:numel(n_curve1(:,1));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%initial screen for peaks (protrusions)%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:numel(n_curve1(:,1))

    if n_curve1(the_point_arr(i),4) >=c_min && n_curve1(the_point_arr(i),4)<=c_max && n_curve1(the_point_arr(i),3)>=(z_low) && n_curve1(the_point_arr(i),3)<=(z_high)
        
        %flag for detection
        is_peak=0;
        
        %getting the values of the curvature around point - ring 1
        [curve_ret_values]=peak_detection_ring_1(n_curve1,f_curve1,the_point_arr(i));
         
        %see if point is local maximum
        count_max1=0;
        count_max2=0;
        
        if numel(curve_ret_values)>1
            
            for p=1:numel(curve_ret_values(:,1))
                
                %difference
                the_dif=abs(curve_ret_values(p,4)-n_curve1(the_point_arr(i),4));
                
                if curve_ret_values(p,4)>n_curve1(the_point_arr(i),4) && the_dif>0.04
                    count_max1=count_max1+1;
                elseif the_dif<=0.04
                    count_max2=count_max2+1;
                end
                
                %clear statements
                clear the_dif;
                
            end
            
            if count_max1 >= (numel(curve_ret_values(:,1))-2)
                
                %changing flag
                is_peak=1;
                
                %plots for debugging
                %plot3(n_curve1(i,1),n_curve1(i,2),n_curve1(i,3),'g+','MarkerSize',12,'LineWidth',2);
                
            elseif count_max2>=(numel(curve_ret_values(:,1))*0.3) && count_max1>=(numel(curve_ret_values(:,1))*0.3)
                
                %changing flag
                is_peak=1;
                
                %plots for debugging
                %plot3(n_curve1(i,1),n_curve1(i,2),n_curve1(i,3),'g+','MarkerSize',12,'LineWidth',2);
                
             elseif count_max2>=(numel(curve_ret_values(:,1))-2)
                 
                %changing flag
                is_peak=1;
                 
                %plots for debugging
                %plot3(n_curve1(i,1),n_curve1(i,2),n_curve1(i,3),'g+','MarkerSize',12,'LineWidth',2);
                
            end
            
        end
       
        %holding onto preliminary list of peaks
        if is_peak == 1
           
            %storing
            prelim_peak(count_prelim,1)=n_curve1(i,1); %x
            prelim_peak(count_prelim,2)=n_curve1(i,2); %y 
            prelim_peak(count_prelim,3)=n_curve1(i,3); %z
            prelim_peak(count_prelim,4)=n_curve1(i,4); %curvature
            prelim_peak(count_prelim,5)=the_point_arr(i); % index of point in face array
            prelim_peak(count_prelim,6)=count_prelim; %counter to reference cell array
            
            %storing neighborhood information
            cell_prelim_peak(count_prelim,1)={curve_ret_values};
            
            %iterate counter
            count_prelim=count_prelim+1;
            
        end
        
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Displaying the rings around point of interest%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%Debugging%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%looking at where the rings
if count_prelim > 1
    
    %sorting by curvature - should put the lowest first (sharpest peak)
    sorted_prelim_peak=sortrows(prelim_peak,4);
    
    %these are the image indices to look through
    n_initial=1;
    n_final=numel(sorted_prelim_peak(:,1));

    %go through the list
    for q=n_initial:n_final %numel(sorted_prelim_peak(:,1))
       
         %plots debugging
         plot3(sorted_prelim_peak(q,1),sorted_prelim_peak(q,2),sorted_prelim_peak(q,3),'k+','MarkerSize',12,'LineWidth',2);
         %the_orig_curvature=sorted_prelim_peak(q,4);
        
        %ring 1
        ring1_tmp=cell_prelim_peak(sorted_prelim_peak(q,6),1);
        ring1=ring1_tmp{1};
        
        %ring 2
        ring2=peak_detection_ring_2_wrapper(ring1,n_curve1,f_curve1,sorted_prelim_peak(q,5));
        
        %ring 3
        ring_send=[ring1;ring2];
        ring3=peak_detection_ring_2_wrapper(ring_send,n_curve1,f_curve1,sorted_prelim_peak(q,5));
        clear ring_send;
        
        %plots for debugging
        plot3(ring1(:,1),ring1(:,2),ring1(:,3),'g+','MarkerSize',12,'LineWidth',2);
        plot3(ring2(:,1),ring2(:,2),ring2(:,3),'y+','MarkerSize',12,'LineWidth',2);
        plot3(ring3(:,1),ring3(:,2),ring3(:,3),'b+','MarkerSize',12,'LineWidth',2);

        %clear statements
        clear ring1_tmp; clear ring1; clear ring2; clear ring3;

    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%Displaying what might be the definition of%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%a protrusion%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%making a plot
figure, plotmesh(n_curve1,f_curve1); shading interp; title('Ch1 - Curvature w microvilli'); caxis([-0.5,0.5]); colorbar;
colormap(ens_curve_map);freezeColors; hold on;

%looking at where the rings
if count_prelim > 1
    
    %sorting by curvature - should put the lowest first (sharpest peak)
    sorted_prelim_peak=sortrows(prelim_peak,4);

    %go through the list
    parfor s=n_initial:n_final %numel(sorted_prelim_peak(:,1))
       s
         %plots debugging
         %plot3(sorted_prelim_peak(q,1),sorted_prelim_peak(q,2),sorted_prelim_peak(q,3),'ko','MarkerSize',12,'LineWidth',2);
         
        %get the matrix for detecting microvilli
        [XYZ_2_send_ret]=make_matrix_microvilli_detection(n_curve1,f_curve1,sorted_prelim_peak,s,cell_prelim_peak);
         
        %some file name to test
        file_test=strcat(path_villi_ch1_init,'MicroVilli_Initial_',num2str(s),'.mat');
        
        %trying out protrusion detection
        [XYZ_2_ret_test]=function_find_microvilli(XYZ_2_send_ret,file_test,s);
        
%         for m=1:numel(XYZ_2_ret_test(:,1))
%            plot3(XYZ_2_ret_test(m,2),XYZ_2_ret_test(m,1),XYZ_2_ret_test(m,3),'k+','MarkerSize',12,'LineWidth',1.5);
%         end
%  
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Fine-tuning definition of protrusion%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%Locating Duplicates%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%making sure something is there
if count_prelim > 1
    
    %counter
    count12=1;
    
    %reading in and assembling
    for t=n_initial:n_final
        %reading
        file_read_tmp=load(strcat(path_villi_ch1_init,'MicroVilli_Initial_',num2str(t),'.mat'));
        file_read=file_read_tmp.XYZ_2_ret;
        
        %put together
        if count12==1
            init_villi=file_read;
        else
            init_villi_tmp=init_villi;
            clear init_villi;
            init_villi=[init_villi_tmp;file_read];
            clear init_villi_tmp;
        end
        
        %iterate counter
        count12=count12+1;
        
        %clear statements
        clear file_read; clear file_read_tmp;
    end
    
    %seeing if there are duplicates - only for testing
    init_villi_test(:,1)=init_villi(:,1);
    init_villi_test(:,2)=init_villi(:,2);
    init_villi_test(:,3)=init_villi(:,3);
    init_villi_test_duplicates=unique(init_villi_test,'rows');
    
    %ok there are duplicates in there
    if numel(init_villi_test(:,1)) ~= numel(init_villi_test_duplicates(:,1))

        %add additional column to keep track of original position
        init_villi(:,7)=[1:numel(init_villi(:,6))]';
        
        %add column to keep track of duplicates
        init_villi(:,8)=zeros(numel(init_villi(:,1)),1);
        
        %counter
        countj=1;
        
        for c=n_initial:n_final
            if c==n_initial
            	[init_villi_ret,countj]=find_same_elements(init_villi,c,countj);
            else
                [init_villi_ret,countj]=find_same_elements(init_villi_ret,c,countj);
            end
        end
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%Fine tuning the selection of microvilli%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%Merging villi step 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%merging with large overlap%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %this is where I merge clusters with large overlap
    init_villi_ret_large=merge_large_overlapping_villi(init_villi_ret);
    
    %n_curve1=handles.NodeCurvature_1;
    n_curve1_k=n_curve1;
    idx_ok=find(n_curve1_k(:,4)<-0.5);
    n_curve1_k(idx_ok,4)=-0.5;
    idx_k=find(n_curve1_k(:,4)>c_max)
    n_curve1_k(idx_k,4)=-0.6;
    figure, plotmesh(n_curve1_k,f_curve1); shading interp; title('Ch1 - Curvature'); caxis([-0.6,0.5]); colorbar;
    colormap(ens_curve_map_mask); freezeColors; hold on;
    for r=1:numel(init_villi_ret_large(:,5))
        text(init_villi_ret_large(r,2),init_villi_ret_large(r,1),init_villi_ret_large(r,3),num2str(init_villi_ret_large(r,4)),'Color','green','FontWeight','bold');
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%Fine tuning the selection of microvilli%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%Merging villi step 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%merging with small overlap%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %counter
    count_re_overlap=1;
    
    %re-calculating overlap
    for s=min(init_villi_ret_large(:,4)):max(init_villi_ret_large(:,4))
        
        %check if there
        idx_yeah=find(init_villi_ret_large(:,4)==s);
        
        if numel(idx_yeah)>0
            if count_re_overlap==1
                [init_villi_ret_large_ret,count_re_overlap]=find_same_elements(init_villi_ret_large,s,count_re_overlap);
            else
                [init_villi_ret_large_ret,count_re_overlap]=find_same_elements(init_villi_ret_large_ret,s,count_re_overlap);
            end
        end
        
    end
    
    %plots for debugging
    count_over=1;
    for s=min(init_villi_ret_large_ret(:,4)):max(init_villi_ret_large_ret(:,4))
        idx_over=find(init_villi_ret_large_ret(:,4)==s);
        
        if numel(idx_over)>0
            for t=1:numel(idx_over)
                
                %intersection
                if init_villi_ret_large_ret(idx_over(t),8)~=0
                    plot3(init_villi_ret_large_ret(idx_over(t),2),init_villi_ret_large_ret(idx_over(t),1),init_villi_ret_large_ret(idx_over(t),3),'bx','MarkerSize',15,'LineWidth',5.5);
                end
                
                %local centers
                if init_villi_ret_large_ret(idx_over(t),5)~=0
                    plot3(init_villi_ret_large_ret(idx_over(t),2),init_villi_ret_large_ret(idx_over(t),1),init_villi_ret_large_ret(idx_over(t),3),'go','MarkerSize',15,'LineWidth',5.5);
                end
            end
            
            count_over=count_over+1;
            if count_over==9
                count_over=1;
            end
            
        end
        
        clear statements
        clear idx_over;
        
        
    end
    
    %merging the small villi
    %change to v2 on 01/28/2020
    [the_final_villi]=merge_small_villi_overlap_v2(init_villi_ret_large_ret,small_thresh_from_user);
    
    %saving
    save(strcat(path_villi_ch1_final,'Final_villi_info.mat'),'the_final_villi');
    
    %also saving the node and face matrices so that I re-assemble things
    save(strcat(path_villi_ch1_final,'Nodes_cluster_for_villi.mat'),'cluster_curve1');
    save(strcat(path_villi_ch1_final,'Nodes_intensity_for_villi.mat'),'i_curve1');
    save(strcat(path_villi_ch1_final,'Nodes_curvature_for_villi.mat'),'n_curve1');
    save(strcat(path_villi_ch1_final,'FaceMat_curvature_for_villi.mat'),'f_curve1');
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%plots for debugging%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%get the relevant node matrices
%channel 1
n_curve1_t=n_curve1;

idx_bad=find(n_curve1_t(:,4)<-0.5);
if numel(idx_bad)>0
        n_curve1_t(idx_bad,4)=-0.5;
end

idx_bad2=find(n_curve1_t(:,4)>=c_max);
if numel(idx_bad2)>0
    n_curve1_t(idx_bad2,4)=-0.6;
end

%making a plot
figure, plotmesh(n_curve1_t,f_curve1); shading interp; title('Ch1 - Curvature'); caxis([-0.6,0.5]); colorbar;
colormap(ens_curve_map_mask); freezeColors; hold on;
 plot3(the_final_villi(:,2),the_final_villi(:,1),the_final_villi(:,3),'g+','LineWidth',2,'MarkerSize',12);
 
 %making another plot
figure, plotmesh(n_curve1_t,f_curve1); shading interp; title('Ch1 - Curvature'); caxis([-0.6,0.5]); colorbar;
colormap(ens_curve_map_mask);freezeColors; hold on;
for r=1:numel(the_final_villi(:,5))
    text(the_final_villi(r,2),the_final_villi(r,1),the_final_villi(r,3),num2str(the_final_villi(r,4)),'Color','green','FontWeight','bold');
   %text(init_villi_ret_large(r,2),init_villi_ret_large(r,1),init_villi_ret_large(r,3),num2str(init_villi_ret_large(r,4)),'Color','green');
end

%making another plot
figure, plotmesh(n_curve1,f_curve1); shading interp; title('Ch1 - Curvature'); caxis([-0.5,0.5]); colorbar;
colormap(ens_curve_map);freezeColors; hold on;
for r=1:numel(the_final_villi(:,5))
    text(the_final_villi(r,2),the_final_villi(r,1),the_final_villi(r,3),num2str(the_final_villi(r,4)),'Color','green','FontWeight','bold');
   %text(init_villi_ret_large(r,2),init_villi_ret_large(r,1),init_villi_ret_large(r,3),num2str(init_villi_ret_large(r,4)),'Color','green');
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%Making more plots for debugging%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%get the relevant node matrices
%channel 1
n_curve1_k=n_curve1;

%making life a little easier for debugging
idx_jA=find(n_curve1_k(:,4)<-0.5);
if numel(idx_jA)>0
    n_curve1_k(idx_jA,4)=-0.5;
end

%valley surface
%applying threshold to nodes based on inputted threshold
n_curve1_valley=n_curve1_k;
idx_valley=find(n_curve1_valley(:,4)<c_min);
if numel(idx_valley)>0
    n_curve1_valley(:,4)=-0.6;
end

%hill surface
n_curve1_hill=n_curve1_k;
idx_hills=find(n_curve1_hill(:,4)>c_min);
if numel(idx_hills)>0
    n_curve1_hill(idx_hills)=-.6;
end

%surfaces with villi numbers
n_curve1_villi=n_curve1_k;
n_curve1_villi(:,4)=0;
for p=1:numel(the_final_villi(:,1))
   
    %find closest point
    the_diff=(n_curve1_villi(:,1)-the_final_villi(p,2))+(n_curve1_villi(:,2)-the_final_villi(p,1))+(n_curve1_villi(:,3)-the_final_villi(p,3));
    idx_diff=find(the_diff==0);
    if numel(idx_diff)>0
        n_curve1_villi(idx_diff,4)=the_final_villi(p,4);
    end
    clear the_diff; clear idx_diff;
    	
end

%scaling for rendering in color
n_curve1_villi(:,4)=n_curve1_villi(:,4).*(256/(max(n_curve1_villi(:,4))));

%making another plot
figure, plotmesh(n_curve1_villi,f_curve1); shading interp; title('Ch1 - Curvature'); colorbar;
colormap(jet); freezeColors; hold on;
