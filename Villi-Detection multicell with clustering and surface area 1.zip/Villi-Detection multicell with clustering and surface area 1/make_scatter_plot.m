function[]=make_scatter_plot(min_cl,max_cl,ncurve,ncluster,ncluster_info,is_size,stats_cl,the_channel)


%counter
count=1;

figure, hold on;

for i=min_cl:max_cl

    %counter
    count2=1;

    %find the cluster
    idx1=find(ncluster(:,4)==i);
    
    if numel(idx1)>0
       
        for k=1:numel(idx1)
           
            if ncurve(idx1(k)) ~= 0

                plot(ncurve(idx1(k),4),ncluster_info(idx1(k),4),'ko','MarkerSize',4,'MarkerEdgeColor',[0.62,0.62,0.62],'LineWidth',4)

                to_avg_arr(count2,1)=ncurve(idx1(k),4);
                to_avg_arr(count2,2)=ncluster_info(idx1(k),4);

                count2=count2+1;
                

            end
            
        end
       
       %storing the averages
       to_plot(count,1)=mean(to_avg_arr(:,1));
       to_plot(count,2)=mean(to_avg_arr(:,2));
       count=count+1;
       
       %clear statements
       clear to_avg_arr;
        
    end
   
    %clear statements
    clear idx1;
    
end

if is_size == 1
    plot(to_plot(:,1),to_plot(:,2),'k+','LineWidth',1.5,'MarkerSize',12);
    ylabel(strcat('Size of Cluster - ',the_channel)); xlabel(strcat('Curvature - ',the_channel));xlim([-0.5,0.5]); 
elseif is_size == 0
    plot(to_plot(:,1),to_plot(:,2),'k+','LineWidth',1.5,'MarkerSize',12);
    ylabel(strcat('Intensity of Cluster',the_channel)); xlabel(strcat('Curvature - ',the_channel));xlim([-0.5,0.5]); 
end

























