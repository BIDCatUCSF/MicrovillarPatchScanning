function[]=draw_curve_hist(node_mask_cluster_2,node_mask_cluster_2_rev,str_title)


%eliminating curvature at the top and bottom
minA=min(node_mask_cluster_2(:,3));
idxA_low=find(node_mask_cluster_2(:,3)<(minA+2));
if numel(idxA_low)>0
    node_mask_cluster_2(idxA_low,:)=[];
end

maxA=max(node_mask_cluster_2(:,3));
idxA_high=find(node_mask_cluster_2(:,3)>(maxA-2));
if numel(idxA_high)>0
    node_mask_cluster_2(idxA_high,:)=[];
end

minB=min(node_mask_cluster_2_rev(:,3));
idxB_low=find(node_mask_cluster_2_rev(:,3)<(minB+2));
if numel(idxB_low)>0
    node_mask_cluster_2_rev(idxB_low,:)=[];
end

maxB=max(node_mask_cluster_2_rev(:,3));
idxB_high=find(node_mask_cluster_2_rev(:,3)>(maxB-2));
if numel(idxB_high)>0
    node_mask_cluster_2_rev(idxB_high,:)=[];
end

%As a test, I am removing entries of '0' flat curvature
% idx_0_set1=find(node_mask_cluster_2(:,4)==0);
% idx_0_set2=find(node_mask_cluster_2_rev(:,4)==0);
% if numel(idx_0_set1)>0
%     node_mask_cluster_2(idx_0_set1,:)=[];
% end
% if numel(idx_0_set2)>0
%     node_mask_cluster_2_rev(idx_0_set2,:)=[];
% end

%creating the arrays for histogram
arr_12_1_hist=node_mask_cluster_2(:,4);
arr_12_2_hist=node_mask_cluster_2_rev(:,4);

idx_ok_12_1=find(arr_12_1_hist(:,1)==0);
if numel(idx_ok_12_1)>0
    arr_12_1_hist(idx_ok_12_1,:)=[];
end

idx_ok_12_2=find(arr_12_2_hist(:,1)==0);
if numel(idx_ok_12_2)>0
    arr_12_2_hist(idx_ok_12_2,:)=[];
end

idx_ok_12_1a=find(arr_12_1_hist(:,1)<-0.5);
idx_ok_12_2a=find(arr_12_2_hist(:,1)<-0.5);

if numel(idx_ok_12_1a)>0
    arr_12_1_hist(idx_ok_12_1a,:)=[];
end

if numel(idx_ok_12_2a)>0
    arr_12_2_hist(idx_ok_12_2a,:)=[];
end

%histogram of all the data - raw
nbins=linspace(-0.5,0.5,30);
[y1,x1]=hist(arr_12_1_hist,nbins);
[y2,x2]=hist(arr_12_2_hist,nbins);

figure, hold on; title(str_title);
plot(x1,y1,'k','LineWidth',1.5);
plot(x2,y2,'m','LineWidth',1.5);
xlabel('Curvature'); ylabel('#');
legend('In Cluster','Not In Cluster');

%histograms of all the data - normalized by area
x1=double(x1); y1=double(y1);
x2=double(x2); y2=double(y2);
y1_norm=y1./max(y1);
y2_norm=y2./max(y2);

figure, hold on; title(strcat(str_title,'- normalized'));
plot(x1,y1_norm,'k','LineWidth',1.5);
plot(x2,y2_norm,'m','LineWidth',1.5);
xlabel('Curvature'); ylabel('# Normalized');
legend('In Cluster','Not In Cluster');

% %histograms of low curvature
% nbins_low=linspace(-0.5,-0.01,20);
% [y1_low,x1_low]=hist(arr_12_1_hist,nbins_low);
% [y2_low,x2_low]=hist(arr_12_2_hist,nbins_low);
% 
% figure, hold on; title(str_title);
% plot(x1_low(1:(numel(x1_low)-1)),y1_low(1:(numel(x1_low)-1)),'k','LineWidth',1.5);
% plot(x2_low(1:(numel(x1_low)-1)),y2_low(1:(numel(x1_low)-1)),'m','LineWidth',1.5);
% xlabel('Curvature'); ylabel('#');
% legend('In Cluster','Not In Cluster');
% 
% %histograms of high curvature
% nbins_high=linspace(0.01,0.5,20);
% [y1_high,x1_high]=hist(arr_12_1_hist,nbins_high);
% [y2_high,x2_high]=hist(arr_12_2_hist,nbins_high);
% 
% figure, hold on; title(str_title);
% plot(x1_high(2:(numel(x1_high))),y1_high(2:(numel(x1_high))),'k','LineWidth',1.5);
% plot(x2_high(2:(numel(x2_high))),y2_high(2:(numel(x2_high))),'m','LineWidth',1.5);
% xlabel('Curvature'); ylabel('#');
% legend('In Cluster','Not In Cluster');


















