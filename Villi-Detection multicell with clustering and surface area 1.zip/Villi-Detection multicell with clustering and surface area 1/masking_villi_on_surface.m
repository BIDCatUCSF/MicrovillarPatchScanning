function[node_m]=masking_villi_on_surface(node_m,in_arr)

%This is a function written to mask out all but (1) villus

for i=1:numel(node_m(:,1))
   
    dist_test=(node_m(i,1)-in_arr(:,2))+(node_m(i,2)-in_arr(:,1))+(node_m(i,3)-in_arr(:,3));
    idx_test=find(dist_test==0);
    
    if numel(idx_test)==0
        node_m(i,4)=-0.6;
    end
    
    %clear statements
    clear dist_test; clear idx_test; 
    
end



