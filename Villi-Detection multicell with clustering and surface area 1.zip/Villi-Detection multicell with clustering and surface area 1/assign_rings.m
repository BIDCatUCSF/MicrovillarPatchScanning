function[r2_out]=assign_rings(r1,r2)

%This is a function written to assign r2 to r1 based on a calculation of
%nearest neighbors

%r1,r2 are coordinates of rings around a point that I am looking at
% r#(:,1)= x
% r#(:,2)= y
% r#(:,3)= z
% r#(:,4)= curvature
% r#(:,5)= index in face matrix

%outputs
%r2 matrix with an extra column
%r2_out(:,6) = index of r1 that corresponds to nearest neighbor

%define output
r2_out=r2;
r2_out(:,6)=zeros(numel(r2(:,1)),1);

for i=1:numel(r2(:,1))
    
   %calculate distance
   dist_m=(((r2(i,1)-r1(:,1)).^2)+((r2(i,2)-r1(:,2)).^2)+((r2(i,3)-r1(:,3)).^2)).^0.5
  
   %minimum distance
   min_d=min(dist_m)
   idx_min=find(dist_m==min_d);
   
   %output
   r2_out(i,6)=idx_min(1);
   
   %clear statements
   clear dist_m; clear min_d; clear idx_min
  
end














