function[the_rgb_im]=make_rgb_im(im_start,re_or_gre,the_scale)

%colormaps
gray_map=colormap(gray);
green_map=gray_map;
green_map(:,1)=0; green_map(:,3)=0;
red_map=gray_map;
red_map(:,2)=0; red_map(:,3)=0;

%image properties
im_start=double(im_start);
dim_f=size(im_start,1);
dim_g=size(im_start,2);

%intensity extrema
max_num=max(im_start(1:(dim_f*dim_g)));
min_num=min(im_start(1:(dim_f*dim_g)));
max_num=double(max_num);
min_num=double(min_num);

im_start=im_start-min_num;
max_num=max_num-min_num;
max_num=max_num*the_scale;

im_start=im_start.*(256/max_num);

if re_or_gre==1
    the_rgb_im=ind2rgb(uint16(im_start),green_map);
elseif re_or_gre==2
    the_rgb_im=ind2rgb(uint16(im_start),red_map);
else
    the_rgb_im=ind2rgb(uint16(im_start),gray_map);
end




