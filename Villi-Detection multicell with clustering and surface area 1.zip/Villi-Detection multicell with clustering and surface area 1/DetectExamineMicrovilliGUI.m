
function varargout = DetectExamineMicrovilliGUI(varargin)
% DETECTEXAMINEMICROVILLIGUI MATLAB code for DetectExamineMicrovilliGUI.fig
%      DETECTEXAMINEMICROVILLIGUI, by itself, creates a new DETECTEXAMINEMICROVILLIGUI or raises the existing
%      singleton*.
%
%      H = DETECTEXAMINEMICROVILLIGUI returns the handle to a new DETECTEXAMINEMICROVILLIGUI or the handle to
%      the existing singleton*.
%
%      DETECTEXAMINEMICROVILLIGUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DETECTEXAMINEMICROVILLIGUI.M with the given input arguments.
%
%      DETECTEXAMINEMICROVILLIGUI('Property','Value',...) creates a new DETECTEXAMINEMICROVILLIGUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before DetectExamineMicrovilliGUI_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to DetectExamineMicrovilliGUI_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help DetectExamineMicrovilliGUI

% Last Modified by GUIDE v2.5 10-Nov-2020 15:02:53

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @DetectExamineMicrovilliGUI_OpeningFcn, ...
                   'gui_OutputFcn',  @DetectExamineMicrovilliGUI_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before DetectExamineMicrovilliGUI is made visible.
function DetectExamineMicrovilliGUI_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to DetectExamineMicrovilliGUI (see VARARGIN)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%initializing GUI Handles%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initializing the handles that will used later in code for detecting villi
handles.OneChannel=1; %radiobutton 1
handles.TwoChannel=0; %radiobutton 2
handles.MinCurve=-1;  %edit 1 - Min. Curvature for villi detection
handles.MaxCurve=0;   %edit 2 - Max. Curvature for villi detection 
handles.small_over_thresh=30; % Threshold for merging villi
handles.AreYouClustering=0; %0 - No clustering, 1 - Yes clustering

%initializing handles files to calculate villi parameters from
handles.flag_file_villi_para_calc_ch1=0;
handles.flag_file_villi_para_calc_ch2=0;

%initializing the handles that will be used later to visualize the villi
handles.Ch1isLoaded=0;
handles.Ch2isLoaded=0;

%flags for histograms
%initializing checkbox to see if colocalization data should be included in
%histograms
handles.check10_for_coloc_hist=0;
handles.success_h1=0;
handles.success_h2=0;

%handles to use registered or unregistered colocalization
handles.UseRegisteredColocalization=0;
handles.UseUnRegisteredColocalization=0;

%handles for discrimination of villi
handles.UseColocCh1ForVilli=0;
handles.UseHeightCh1ForVilli=0;
handles.UseBaseAreaCh1ForVilli=0;
handles.UseSharpnessCh1ForVilli=0;

handles.UseColocCh2ForVilli=0;
handles.UseHeightCh2ForVilli=0;
handles.UseBaseAreaCh2ForVilli=0;
handles.UseSharpnessCh2ForVilli=0;

%thresholds for discriminating villi
handles.Ch1ColocMin=0;
handles.Ch1ColocMax=100;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%opening the inputs that went into the GUI%%%%%%%%%%%%%%%%%%%%%%%

%number of channels
theNumberChannels=varargin{1};
handles.NumberOfChannels=theNumberChannels;

%are you clustering
AreYouClustering=varargin{2};
handles.AreYouClustering=AreYouClustering;

if theNumberChannels == 1 
        
    if AreYouClustering == 0
        %getting relevant matrices
        handles.fcurve1=varargin{3};
        handles.ncurve1=varargin{4};
        handles.nint1=varargin{5};
        handles.path1v=varargin{6};
    else
        %getting relevant matrices
        handles.fcurve1=varargin{3};
        handles.ncurve1=varargin{4};
        handles.nint1=varargin{5};
        handles.ncluster1=varargin{6};
        handles.path1v=varargin{7};
    end
        
        %create directories to hold villi - 1 channel
        path_bd_ch1=handles.path1v;
        idx_yan=find(path_bd_ch1=='\');
        path_villi_ch1_init=strcat(path_bd_ch1(1:(idx_yan(numel(idx_yan)-1))),'Initial Microvilli Locs\');
        path_villi_ch1_final=strcat(path_bd_ch1(1:(idx_yan(numel(idx_yan)-1))),'Final Microvilli Locs\');
        mkdir(path_villi_ch1_init);
        mkdir(path_villi_ch1_final);
        handles.path_for_init_villi_ch1=path_villi_ch1_init;
        handles.path_for_final_villi_ch1=path_villi_ch1_final;
        
        %adding to text boxes at bottom of page
        idx_post1=find(path_bd_ch1=='\');
        path_post1=path_bd_ch1(idx_post1(numel(idx_post1)-5):idx_post1(numel(idx_post1)-2));
        set(handles.text2, 'String', path_post1);
        
%Two channel
elseif theNumberChannels == 2 
        
        %getting relevant matrices
        if handles.AreYouClustering==0
            handles.fcurve1=varargin{3};
            handles.ncurve1=varargin{4};
            handles.nint1=varargin{5};
            handles.path1v=varargin{6};
            
            handles.fcurve2=varargin{7};
            handles.ncurve2=varargin{8};
            handles.nint2=varargin{9};
            handles.path2v=varargin{10};
        else
            handles.fcurve1=varargin{3};
            handles.ncurve1=varargin{4};
            handles.nint1=varargin{5};
            handles.ncluster1=varargin{6};
            handles.path1v=varargin{7};
            
            
            handles.fcurve2=varargin{8};
            handles.ncurve2=varargin{9};
            handles.nint2=varargin{10};
            handles.ncluster2=varargin{11};
            handles.path2v=varargin{12};          
        end
        
        %create directories to hold villi - First channel
        path_bd_ch1=handles.path1v;
        idx_yan=find(path_bd_ch1=='\');
        path_villi_ch1_init=strcat(path_bd_ch1(1:(idx_yan(numel(idx_yan)-1))),'Initial Microvilli Locs\');
        path_villi_ch1_final=strcat(path_bd_ch1(1:(idx_yan(numel(idx_yan)-1))),'Final Microvilli Locs\');
        mkdir(path_villi_ch1_init);
        mkdir(path_villi_ch1_final);
        handles.path_for_init_villi_ch1=path_villi_ch1_init;
        handles.path_for_final_villi_ch1=path_villi_ch1_final;
        
        %adding Channel 1 to text box
        idx_post1=find(path_bd_ch1=='\');
        path_post1=path_bd_ch1(idx_post1(numel(idx_post1)-5):idx_post1(numel(idx_post1)-2));
        set(handles.text2, 'String', path_post1);
        
        %create directories to hold villi - Second channel
        path_bd_ch2=handles.path2v;
        idx_yan2=find(path_bd_ch2=='\');
        path_villi_ch2_init=strcat(path_bd_ch2(1:(idx_yan2(numel(idx_yan2)-1))),'Initial Microvilli Locs\');
        path_villi_ch2_final=strcat(path_bd_ch2(1:(idx_yan2(numel(idx_yan2)-1))),'Final Microvilli Locs\');
        mkdir(path_villi_ch2_init);
        mkdir(path_villi_ch2_final);
        handles.path_for_init_villi_ch2=path_villi_ch2_init;
        handles.path_for_final_villi_ch2=path_villi_ch2_final;
        
        %adding filename to text box
        idx_post2=find(path_bd_ch2=='\');
        path_post2=path_bd_ch1(idx_post2(numel(idx_post2)-5):idx_post2(numel(idx_post2)-2));
        set(handles.text3, 'String', path_post2);
        

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%Loading En's colormaps%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%making first element black
ens_curve_map_mask=[    0         0         0
    0.9966    0.0778    0.6523
    0.9936    0.0808    0.6534
    0.9907    0.0837    0.6545
    0.9877    0.0866    0.6556
    0.9847    0.0895    0.6567
    0.9817    0.0925    0.6578
    0.9788    0.0954    0.6589
    0.9758    0.0983    0.6600
    0.9728    0.1012    0.6611
    0.9699    0.1042    0.6622
    0.9669    0.1071    0.6633
    0.9639    0.1100    0.6644
    0.9610    0.1129    0.6655
    0.9580    0.1158    0.6666
    0.9550    0.1188    0.6677
    0.9520    0.1217    0.6688
    0.9491    0.1246    0.6699
    0.9461    0.1275    0.6710
    0.9431    0.1305    0.6721
    0.9402    0.1334    0.6732
    0.9372    0.1363    0.6743
    0.9342    0.1392    0.6754
    0.9312    0.1422    0.6765
    0.9283    0.1451    0.6776
    0.9253    0.1480    0.6787
    0.8813    0.1913    0.6950
    0.8373    0.2346    0.7113
    0.7932    0.2778    0.7277
    0.7492    0.3211    0.7440
    0.7052    0.3644    0.7603
    0.6612    0.4077    0.7766
    0.6172    0.4510    0.7930
    0.5732    0.4943    0.8093
    0.5291    0.5375    0.8256
    0.4851    0.5808    0.8419
    0.4411    0.6241    0.8583
    0.3971    0.6674    0.8746
    0.3531    0.7107    0.8909
    0.3091    0.7540    0.9072
    0.2650    0.7972    0.9236
    0.2210    0.8405    0.9399
    0.1770    0.8838    0.9562
    0.1714    0.8893    0.9583
    0.1657    0.8949    0.9604
    0.1601    0.9004    0.9625
    0.1545    0.9059    0.9645
    0.1489    0.9115    0.9666
    0.1432    0.9170    0.9687
    0.1376    0.9225    0.9708
    0.1320    0.9281    0.9729
    0.1263    0.9336    0.9750
    0.1207    0.9391    0.9771
    0.1151    0.9447    0.9791
    0.1095    0.9502    0.9812
    0.1038    0.9557    0.9833
    0.0982    0.9613    0.9854
    0.0926    0.9668    0.9875
    0.0869    0.9723    0.9896
    0.0813    0.9779    0.9917
    0.0757    0.9834    0.9937
    0.0701    0.9889    0.9958
    0.0644    0.9945    0.9979
    0.0588    1.0000    1.0000];

ens_curve_map=[1.0000    0.0745    0.6510
    0.9966    0.0778    0.6522
    0.9932    0.0812    0.6535
    0.9898    0.0845    0.6548
    0.9864    0.0879    0.6560
    0.9830    0.0912    0.6573
    0.9796    0.0945    0.6585
    0.9762    0.0979    0.6598
    0.9728    0.1012    0.6611
    0.9694    0.1046    0.6623
    0.9660    0.1079    0.6636
    0.9627    0.1112    0.6648
    0.9593    0.1146    0.6661
    0.9559    0.1179    0.6673
    0.9525    0.1213    0.6686
    0.9491    0.1246    0.6699
    0.9457    0.1279    0.6711
    0.9423    0.1313    0.6724
    0.9389    0.1346    0.6736
    0.9355    0.1379    0.6749
    0.9321    0.1413    0.6762
    0.9287    0.1446    0.6774
    0.9253    0.1480    0.6787
    0.8837    0.1888    0.6941
    0.8422    0.2297    0.7095
    0.8006    0.2706    0.7249
    0.7590    0.3115    0.7403
    0.7174    0.3524    0.7558
    0.6759    0.3932    0.7712
    0.6343    0.4341    0.7866
    0.5927    0.4750    0.8020
    0.5511    0.5159    0.8174
    0.5096    0.5568    0.8328
    0.4680    0.5976    0.8483
    0.4264    0.6385    0.8637
    0.3848    0.6794    0.8791
    0.3433    0.7203    0.8945
    0.3017    0.7612    0.9099
    0.2601    0.8021    0.9253
    0.2186    0.8429    0.9408
    0.1770    0.8838    0.9562
    0.1718    0.8889    0.9581
    0.1667    0.8939    0.9600
    0.1616    0.8990    0.9619
    0.1564    0.9040    0.9638
    0.1513    0.9091    0.9657
    0.1462    0.9141    0.9676
    0.1410    0.9192    0.9695
    0.1359    0.9242    0.9714
    0.1307    0.9293    0.9733
    0.1256    0.9343    0.9752
    0.1205    0.9394    0.9771
    0.1153    0.9444    0.9790
    0.1102    0.9495    0.9809
    0.1051    0.9545    0.9829
    0.0999    0.9596    0.9848
    0.0948    0.9646    0.9867
    0.0896    0.9697    0.9886
    0.0845    0.9747    0.9905
    0.0794    0.9798    0.9924
    0.0742    0.9848    0.9943
    0.0691    0.9899    0.9962
    0.0640    0.9949    0.9981
    0.0588    1.0000    1.0000];

handles.MaskedMap=ens_curve_map_mask;
handles.Map=ens_curve_map;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%MatLab-generated code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Choose default command line output for DetectExamineMicrovilliGUI
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes DetectExamineMicrovilliGUI wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = DetectExamineMicrovilliGUI_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the radio button to indicate analysis of Channel 1
handles.OneChannel=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of radiobutton1


% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the radio button to indicate analysis of Channel 2
handles.TwoChannel=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of radiobutton2



% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%This is the button that actual goes through the watershed calculation on
%the curvature surface in order to determine where microvilli are.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%grabbing the threshold
c_min_send=handles.MinCurve; 
c_max_send=handles.MaxCurve; 

%threshold for small overlapping merge
small_merge_thresh_em=handles.small_over_thresh;

%grabbbing colormaps
ens_curve_map_mask_send=handles.MaskedMap;
ens_curve_map_send=handles.Map;

%making a text file
if (handles.OneChannel==1 && handles.TwoChannel == 0)
    
    %paths
    pa1_final=handles.path_for_final_villi_ch1;
    
    %name for text file
    ch1_text_name=strcat(pa1_final,'Ch1_villi_thresh_info.txt');
    
    %open file
    fileID=fopen(ch1_text_name,'w');
    fprintf(fileID,'%12s %6.2f\n','Channel 1s Minimum Curvature is',c_min_send);
    fprintf(fileID,'%12s %6.2f\n','Channel 1s Maximum Curvature is',c_max_send);
    fprintf(fileID,'%12s %6.2f\n','Small Overlap % is',small_merge_thresh_em); 
    
    %closing file
    fclose(fileID);
    
elseif (handles.OneChannel==0 && handles.TwoChannel == 1)
    
    %path
    pa2_final=handles.path_for_final_villi_ch2;
    
    %name for text file
    ch2_text_name=strcat(pa2_final,'Ch2_villi_thresh_info.txt');
    
    %open file - channel 2
    fileID2=fopen(ch2_text_name,'w');
    fprintf(fileID2,'%12s %6.2f\n','Channel 1s Minimum Curvature is',c_min_send);
    fprintf(fileID2,'%12s %6.2f\n','Channel 1s Maximum Curvature is',c_max_send);
    fprintf(fileID2,'%12s %6.2f\n','Small Overlap % is',small_merge_thresh_em); 
    
    %closing file - channel 2
    fclose(fileID2);
            
elseif (handles.OneChannel==1 && handles.TwoChannel == 1)
    
    %paths
    pa1_final=handles.path_for_final_villi_ch1;
    pa2_final=handles.path_for_final_villi_ch2;
    
    %name for text file
    ch1_text_name=strcat(pa1_final,'Ch1_villi_thresh_info.txt');
    ch2_text_name=strcat(pa2_final,'Ch2_villi_thresh_info.txt');
    
    %open file - channel 1
    fileID=fopen(ch1_text_name,'w');
    fprintf(fileID,'%12s %6.2f\n','Channel 1s Minimum Curvature is',c_min_send);
    fprintf(fileID,'%12s %6.2f\n','Channel 1s Maximum Curvature is',c_max_send);
    fprintf(fileID,'%12s %6.2f\n','Small Overlap % is',small_merge_thresh_em); 
    
    %closing file - channel 1
    fclose(fileID);
            
    %open file - channel 2
    fileID2=fopen(ch2_text_name,'w');
    fprintf(fileID2,'%12s %6.2f\n','Channel 1s Minimum Curvature is',c_min_send);
    fprintf(fileID2,'%12s %6.2f\n','Channel 1s Maximum Curvature is',c_max_send);
    fprintf(fileID2,'%12s %6.2f\n','Small Overlap % is',small_merge_thresh_em); 
    
    %closing file - channel 2
    fclose(fileID2);
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Doing the watershed calculation%%%%%%%%%%%%%%%%%%%%%%%%%

%Channel 1 only
if (handles.OneChannel==1 && handles.TwoChannel == 0)
    
    %grabbing paths for villi
    path_villi_ch1_init_send=handles.path_for_init_villi_ch1;
    path_villi_ch1_final_send=handles.path_for_final_villi_ch1;
    
    %grabbing surface
    f_curve1_send=handles.fcurve1;
    n_curve1_send=handles.ncurve1;
    
    %grabbing the intensity surface
    i_curve1=handles.nint1;

    %In the event, you are looking at clusters
    if handles.AreYouClustering==1
        ncluster1_send=handles.ncluster1;
        detect_microvilli_master_function_w_cluster(n_curve1_send,f_curve1_send,c_min_send,c_max_send,path_villi_ch1_init_send,path_villi_ch1_final_send,ens_curve_map_send,ens_curve_map_mask_send,small_merge_thresh_em,i_curve1,ncluster1_send);
    else
        %This is the Go! button to detect microvilli
        detect_microvilli_master_function(n_curve1_send,f_curve1_send,c_min_send,c_max_send,path_villi_ch1_init_send,path_villi_ch1_final_send,ens_curve_map_send,ens_curve_map_mask_send,small_merge_thresh_em,i_curve1);
    end
    
%Channel 2 only
elseif (handles.OneChannel==0 && handles.TwoChannel == 1)
    
    %grabbing paths for villi
    path_villi_ch2_init_send=handles.path_for_init_villi_ch2;
    path_villi_ch2_final_send=handles.path_for_final_villi_ch2;
    
    %grabbing surface
    f_curve2_send=handles.fcurve2;
    n_curve2_send=handles.ncurve2;
    
    %grabbing the intensity surface
    i_curve2=handles.nint2;

    %In the event, you are looking at clusters
    if handles.AreYouClustering==1
        ncluster2_send=handles.ncluster2;
        detect_microvilli_master_function_w_cluster(n_curve2_send,f_curve2_send,c_min_send,c_max_send,path_villi_ch2_init_send,path_villi_ch2_final_send,ens_curve_map_send,ens_curve_map_mask_send,small_merge_thresh_em,i_curve2,ncluster2_send);
    else
        %This is the Go! button to detect microvilli
        detect_microvilli_master_function(n_curve2_send,f_curve2_send,c_min_send,c_max_send,path_villi_ch2_init_send,path_villi_ch2_final_send,ens_curve_map_send,ens_curve_map_mask_send,small_merge_thresh_em,i_curve2);
    end
    
    
%Channel 1 and Channel 2
elseif (handles.OneChannel==1 && handles.TwoChannel == 1)
    
    %grabbing paths for villi - Channel 1
    path_villi_ch1_init_send=handles.path_for_init_villi_ch1;
    path_villi_ch1_final_send=handles.path_for_final_villi_ch1;
    
    %grabbing paths for villi - Channel 2
    path_villi_ch2_init_send=handles.path_for_init_villi_ch2;
    path_villi_ch2_final_send=handles.path_for_final_villi_ch2;

    %grabbing surface - Channel 1
    f_curve1_send=handles.fcurve1;
    n_curve1_send=handles.ncurve1;
    
    %grabbing surface - Channel 2
    f_curve2_send=handles.fcurve2;
    n_curve2_send=handles.ncurve2;
    
    %grabbing the intensity surfaces
    i_curve1=handles.nint1;
    i_curve2=handles.nint2;

      %In the event, you are looking at clusters
    if handles.AreYouClustering==1
        %This is the Microvilli Detection - Channel 2 - with clustering
        ncluster2_send=handles.ncluster2;
        detect_microvilli_master_function_w_cluster(n_curve2_send,f_curve2_send,c_min_send,c_max_send,path_villi_ch2_init_send,path_villi_ch2_final_send,ens_curve_map_send,ens_curve_map_mask_send,small_merge_thresh_em,i_curve2,ncluster2_send);
        
        %This is the Microvilli Detection - Channel 1 - with clustering
        ncluster1_send=handles.ncluster1;
        detect_microvilli_master_function_w_cluster(n_curve1_send,f_curve1_send,c_min_send,c_max_send,path_villi_ch1_init_send,path_villi_ch1_final_send,ens_curve_map_send,ens_curve_map_mask_send,small_merge_thresh_em,i_curve1,ncluster1_send);
    else
        %This is the Go! button to detect microvilli - Channel 1
        detect_microvilli_master_function(n_curve1_send,f_curve1_send,c_min_send,c_max_send,path_villi_ch1_init_send,path_villi_ch1_final_send,ens_curve_map_send,ens_curve_map_mask_send,small_merge_thresh_em,i_curve1);
        
        %This is the Go! button to detect microvilli - Channel 2
        detect_microvilli_master_function(n_curve2_send,f_curve2_send,c_min_send,c_max_send,path_villi_ch2_init_send,path_villi_ch2_final_send,ens_curve_map_send,ens_curve_map_mask_send,small_merge_thresh_em,i_curve2);
    end
    
end


function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%getting value from edit box
handles.small_over_thresh=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the edit box for the minimum curvature indicated for villi
%analysis

handles.MinCurve=str2double(get(hObject,'String')) ;

%storing the handles
guidata(hObject, handles);

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double


% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the edit box for the maximum curvature indicated for villi
%analysis
handles.MaxCurve=str2double(get(hObject,'String')) ;

%storing the handles
guidata(hObject, handles);

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button where you can take a look at what your applied
%threshold looks like before you commit to doing the watershed calculation


%grabbing the threshold
min_cnow=handles.MinCurve; 
max_cnow=handles.MaxCurve; 

%get colormaps
ens_curve_map_masked=handles.MaskedMap;
ens_curve_map=handles.Map;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%thresholding%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Channel 1 - only
if (handles.OneChannel==1 && handles.TwoChannel == 0)
    
    %channel 1
    fc_1=handles.fcurve1;
    nc_1=handles.ncurve1;
    nc_1_thresh=nc_1;
    
    %applying threshold
    idx_too_high1=find(nc_1(:,4)>max_cnow);
    idx_too_low1=find(nc_1(:,4)<min_cnow);
    if numel(idx_too_high1)>0
        nc_1_thresh(idx_too_high1,4)=-0.6;
    end
    if numel(idx_too_low1)>0
        nc_1_thresh(idx_too_low1,4)=-0.6;
    end
    
    %For display
    idx_b1=find(nc_1_thresh(:,4)<-0.5);
    if numel(idx_b1)>0
        for i=1:numel(idx_b1)
            if nc_1_thresh(idx_b1(i),4)~=-0.6
                nc_1_thresh(idx_b1(i),4)=-0.5;
            end
        end
    end
    
    figure, hold on;
    
%     nc_1_thresh_tmp=nc_1_thresh;
%     nc_1_thresh(:,1)=nc_1_thresh_tmp(:,2);
%     nc_1_thresh(:,2)=nc_1_thresh_tmp(:,1);
%     clear nc1_thresh_tmp;
%     
%     nc_1_tmp=nc_1;
%     nc_1(:,1)=nc_1_tmp(:,2);
%     nc_1(:,2)=nc_1_tmp(:,1);
    
    subplot(1,2,1);
    plotmesh(nc_1_thresh,fc_1); shading interp; title('Curvature Threshed - Ch1'); caxis([-0.6,0.5]); 
    colormap(ens_curve_map_masked);freezeColors; hold on;
    
    subplot(1,2,2);
    plotmesh(nc_1,fc_1); shading interp; title('Curvature - Ch1'); caxis([-0.5,0.5]);
    colormap(ens_curve_map);freezeColors; hold on;
    
   
%Channel 2 Only
elseif (handles.OneChannel==0 && handles.TwoChannel == 1)
    
    %channel 2
    fc_2=handles.fcurve2;
    nc_2=handles.ncurve2;
    nc_2_thresh=nc_2;
    
    %applying threshold
    idx_too_high2=find(nc_2(:,4)>max_cnow);
    idx_too_low2=find(nc_2(:,4)<min_cnow);
    if numel(idx_too_high2)>0
        nc_2_thresh(idx_too_high2,4)=-0.6;
    end
    if numel(idx_too_low2)>0
        nc_2_thresh(idx_too_low2,4)=-0.6;
    end
    
     %For display
    idx_b2=find(nc_2_thresh(:,4)<-0.5);
    if numel(idx_b2)>0
        for i=1:numel(idx_b2)
            if nc_2_thresh(idx_b2(i),4)~=-0.6
                nc_2_thresh(idx_b2(i),4)=-0.5;
            end
        end
    end
    
%     nc_2_thresh_tmp=nc_2_thresh;
%     nc_2_thresh(:,1)=nc_2_thresh_tmp(:,2);
%     nc_2_thresh(:,2)=nc_2_thresh_tmp(:,1);
%     clear nc_2_thresh_tmp;
%     
%     nc_2_tmp=nc_2;
%     nc_2(:,1)=nc_2_tmp(:,2);
%     nc_2(:,2)=nc_2_tmp(:,1);
%     clear nc_2_tmp;
    
    figure, hold on;
    subplot(1,2,1);
    plotmesh(nc_2_thresh,fc_2); shading interp; title('Curvature Threshed - Ch2'); caxis([-0.6,0.5]); 
    colormap(ens_curve_map_masked);freezeColors; hold on;
    
    subplot(1,2,2);
    plotmesh(nc_2,fc_2); shading interp; title('Curvature - Ch2'); caxis([-0.5,0.5]); 
    colormap(ens_curve_map);freezeColors; hold on;

%both channels
elseif (handles.OneChannel==1 && handles.TwoChannel == 1)
    
   %%channel 1
    fc_1=handles.fcurve1;
    nc_1=handles.ncurve1;
    nc_1_thresh=nc_1;
    
    %applying threshold
    idx_too_high1=find(nc_1(:,4)>max_cnow);
    idx_too_low1=find(nc_1(:,4)<min_cnow);
    if numel(idx_too_high1)>0
        nc_1_thresh(idx_too_high1,4)=-0.6;
    end
    if numel(idx_too_low1)>0
        nc_1_thresh(idx_too_low1,4)=-0.6;
    end
    
    %For display
    idx_b1=find(nc_1_thresh(:,4)<-0.5);
    if numel(idx_b1)>0
        for i=1:numel(idx_b1)
            if nc_1_thresh(idx_b1(i),4)~=-0.6
                nc_1_thresh(idx_b1(i),4)=-0.5;
            end
        end
    end
   
    %channel 2
    fc_2=handles.fcurve2;
    nc_2=handles.ncurve2;
    nc_2_thresh=nc_2;
    
    %applying threshold
    idx_too_high2=find(nc_2(:,4)>max_cnow);
    idx_too_low2=find(nc_2(:,4)<min_cnow);
    if numel(idx_too_high2)>0
        nc_2_thresh(idx_too_high2,4)=-0.6;
    end
    if numel(idx_too_low2)>0
        nc_2_thresh(idx_too_low2,4)=-0.6;
    end
    
     %For display
    idx_b2=find(nc_2_thresh(:,4)<-0.5);
    if numel(idx_b2)>0
        for i=1:numel(idx_b2)
            if nc_2_thresh(idx_b2(i),4)~=-0.6
                nc_2_thresh(idx_b2(i),4)=-0.5;
            end
        end
    end
    
%     nc_1_thresh_tmp=nc_1_thresh;
%     nc_1_thresh(:,1)=nc_1_thresh_tmp(:,2);
%     nc_1_thresh(:,2)=nc_1_thresh_tmp(:,1);
%     clear nc1_thresh_tmp;
%     
%     nc_1_tmp=nc_1;
%     nc_1(:,1)=nc_1_tmp(:,2);
%     nc_1(:,2)=nc_1_tmp(:,1);
%     
%     nc_2_thresh_tmp=nc_2_thresh;
%     nc_2_thresh(:,1)=nc_2_thresh_tmp(:,2);
%     nc_2_thresh(:,2)=nc_2_thresh_tmp(:,1);
%     clear nc_2_thresh_tmp;
%     
%     nc_2_tmp=nc_2;
%     nc_2(:,1)=nc_2_tmp(:,2);
%     nc_2(:,2)=nc_2_tmp(:,1);
%     clear nc_2_tmp;
    
    %figures
    figure, hold on;
    subplot(2,2,2);
    plotmesh(nc_1,fc_1); shading interp; title('Curvature - Ch1'); caxis([-0.5,0.5]); 
    colormap(ens_curve_map);freezeColors; hold on;
    
    subplot(2,2,1);
    plotmesh(nc_1_thresh,fc_1); shading interp; title('Curvature Threshed - Ch1'); caxis([-0.6,0.5]); 
    colormap(ens_curve_map_masked);freezeColors; hold on;
    
    subplot(2,2,4);
    plotmesh(nc_2,fc_2); shading interp; title('Curvature - Ch2'); caxis([-0.5,0.5]); 
    colormap(ens_curve_map);freezeColors; hold on;
    
    subplot(2,2,3);
    plotmesh(nc_2_thresh,fc_2); shading interp; title('Curvature Threshed - Ch2'); caxis([-0.6,0.5]); 
    colormap(ens_curve_map_masked);freezeColors; hold on;
    
end


%making a plot
% figure, plotmesh(n_curve1,f_curve1); shading interp; title('Ch1 - Curvature'); caxis([-0.5,0.5]); colorbar;
% colormap(ens_curve_map);freezeColors; hold on;


% --- Executes on button press in checkbox2.
function checkbox2_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox2
handles.UseColocCh1ForVilli=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double

%This is edit box for minimum colocaliztion - channel 1
handles.Ch1ColocMin=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double

%This is edit box for maximum colocaliztion - channel 1
handles.Ch1ColocMax=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox3.
function checkbox3_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox3
john=get(hObject,'Value');
handles.UseHeightCh1ForVilli=john;

%storing the handles
guidata(hObject, handles);


function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double

%This is edit box for minimum height - channel 1
john=str2double(get(hObject,'String'))
handles.Ch1HeightMin=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit7_Callback(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit7 as text
%        str2double(get(hObject,'String')) returns contents of edit7 as a double

%This is edit box for maximum height - channel 1
handles.Ch1HeightMax=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit7_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox4.
function checkbox4_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox4
handles.UseBaseAreaCh1ForVilli=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double

%This is edit box for minimum base area - channel 1
handles.Ch1BaseAreaMin=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double

%This is edit box for maximum base area - channel 1
handles.Ch1BaseAreaMax=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox5.
function checkbox5_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox5
handles.UseSharpnessCh1ForVilli=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double


%This is edit box for minimum sharpness - channel 1
handles.Ch1SharpnessMin=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double

%This is edit box for maximum sharpness - channel 1
handles.Ch1SharpnessMax=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);



% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox6.
function checkbox6_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox6
handles.UseColocCh2ForVilli=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double

%This is edit box for minimum colocalization - channel 2
handles.Ch2ColocMin=str2double(get(hObject,'String'));


%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


%This is edit box for maximum colocalization - channel 2
handles.Ch2ColocMax=str2double(get(hObject,'String'));


%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox7.
function checkbox7_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox7

% Hint: get(hObject,'Value') returns toggle state of checkbox3
handles.UseHeightCh2ForVilli=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double

%This is edit box for minimum height - channel 2
handles.Ch2HeightMin=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double

%This is edit box for maximum height - channel 2
handles.Ch2HeightMax=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox8.
function checkbox8_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox8

handles.UseBaseAreaCh2ForVilli=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double

%This is edit box for minimum base area - channel 2
handles.Ch2BaseAreaMin=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit17_Callback(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit17 as text
%        str2double(get(hObject,'String')) returns contents of edit17 as a double

%This is edit box for maximum base area - channel 2
handles.Ch2BaseAreaMax=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit17_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in checkbox9.
function checkbox9_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox9
handles.UseSharpnessCh2ForVilli=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


function edit18_Callback(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit18 as text
%        str2double(get(hObject,'String')) returns contents of edit18 as a double

%This is edit box for minimum sharpness - channel 2
handles.Ch2SharpnessMin=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit18_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit18 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit19_Callback(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit19 as text
%        str2double(get(hObject,'String')) returns contents of edit19 as a double

%This is edit box for maximum sharpness - channel 2
handles.Ch2SharpnessMax=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit19_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%testing out the size of the plots
handles.axes1;
x=1:100;
y=10*x;
plot(x,y);
xlabel('x'); ylabel('y'); title('test');

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%This is the button to upload vill parameter information into%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%into histograms%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%channel 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%You can pick any file

%Button to get the "Final_villi_info.mat" file
[file_h1,path_h1,success_h1]=uigetfile;
handles.filename_h1=file_h1;
handles.pathname_h1=path_h1;

%flag to indicate file has been picked
handles.success_h1=success_h1;

%storing the handles
guidata(hObject, handles);

% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%This is the button that does the thresholding and occupancy%%%%%%
%%%%%%%%%%%%%%%%calculations and figure generation%%%%%%%%%%%%%%%%%%%%%%%%

%get thecolormaps
[ens_curve_map,ens_curve_map_mask]=get_curvature_maps();
[jet_map]=get_jet_map();
gray_map=colormap(gray);
red_map=gray_map;
red_map(:,2)=0;
red_map(:,3)=0;
green_map=gray_map;
green_map(:,1)=0;
green_map(:,3)=0;


%Get and load files - Channel 1
if handles.success_h1==1

    %pathname to villi geometry files
    path_geo1a=handles.pathname_h1;
    
    %gather_matrices_for_villi_thresh
    [Node_base_area1a,Node_villi_height1a,Node_villi_SA1a,node_curve1a,node_int1a,Face_mat_villi1a,int_stack1a,ns,ne,min_curve_1a,max_curve_1a,cluster_stack_1a]=gather_matrices_for_villi_thresh(path_geo1a,1);
    
    %Assuming data is scaled for LLS
    Node_base_area1a(:,3)=Node_base_area1a(:,3)./1.75;
    Node_villi_height1a(:,3)=Node_villi_height1a(:,3)./1.75;
    Node_villi_SA1a(:,3)=Node_villi_SA1a(:,3)./1.75;
    node_curve1a(:,3)=node_curve1a(:,3)./1.75;
    node_int1a(:,3)=node_int1a(:,3)./1.75;
    
    %number of images
    num_images_in=ne-ns+1;
    
    %doing the 2d projections
    [output_1_1a,output_2_1a,output_3_1a,output_4_1a]=create_all_the_2d_intensity_projections(int_stack1a,cluster_stack_1a,num_images_in);
    
    %intensity surface projections - sanity check
    [ch1_int_surface_2d_1]=make_2d_projection_figures(output_1_1a,node_int1a);
    [ch1_int_surface_2d_2]=make_2d_projection_figures(output_2_1a,node_int1a);
    [ch1_int_surface_2d_3]=make_2d_projection_figures(output_3_1a,node_int1a);
    [ch1_int_surface_2d_4]=make_2d_projection_figures(output_4_1a,node_int1a);
    
    %curvature surface projections
    [ch1_curve_surface_2d_1]=make_2d_projection_figures(output_1_1a,node_curve1a);
    [ch1_curve_surface_2d_2]=make_2d_projection_figures(output_2_1a,node_curve1a);
    [ch1_curve_surface_2d_3]=make_2d_projection_figures(output_3_1a,node_curve1a);
    [ch1_curve_surface_2d_4]=make_2d_projection_figures(output_4_1a,node_curve1a);
    
    %thresholding curvature surfaces
    [ch1_curve_surface_2d_1_ret,ch1_curve_surface_2d_2_ret,ch1_curve_surface_2d_3_ret,ch1_curve_surface_2d_4_ret]=screen_2d_projections_by_para(ch1_curve_surface_2d_1,ch1_curve_surface_2d_2,ch1_curve_surface_2d_3,ch1_curve_surface_2d_4,min_curve_1a,max_curve_1a,1);
    
     %height projections
    [ch1_height_surface_2d_1]=make_2d_projection_figures(output_1_1a,Node_villi_height1a);
    [ch1_height_surface_2d_2]=make_2d_projection_figures(output_2_1a,Node_villi_height1a);
    [ch1_height_surface_2d_3]=make_2d_projection_figures(output_3_1a,Node_villi_height1a);
    [ch1_height_surface_2d_4]=make_2d_projection_figures(output_4_1a,Node_villi_height1a);
%     
%     figure, plotmesh(Node_villi_height1a,Face_mat_villi1a); shading interp; title('Villi Height'); 
%     figure,plotmesh(node_curve1a,Face_mat_villi1a); shading interp; title('Curvature'); 
    
    %2d projections of clusters - from images not surfaces
    ch1_coloc_cluster_2d_1_tmp=output_1_1a(2,1);
    ch1_coloc_cluster_2d_1=ch1_coloc_cluster_2d_1_tmp{1};
    ch1_coloc_cluster_2d_2_tmp=output_2_1a(2,1);
    ch1_coloc_cluster_2d_2=ch1_coloc_cluster_2d_2_tmp{1};
    ch1_coloc_cluster_2d_3_tmp=output_3_1a(2,1);
    ch1_coloc_cluster_2d_3=ch1_coloc_cluster_2d_3_tmp{1};
    ch1_coloc_cluster_2d_4_tmp=output_4_1a(2,1);
    ch1_coloc_cluster_2d_4=ch1_coloc_cluster_2d_4_tmp{1};
   
    
    %2d projections of intensity - from images not surfaces
    ch1_intensity_2d_1_tmp=output_1_1a(1,1);
    ch1_intensity_2d_1=ch1_intensity_2d_1_tmp{1};
    ch1_intensity_2d_2_tmp=output_2_1a(1,1);
    ch1_intensity_2d_2=ch1_intensity_2d_2_tmp{1};
    ch1_intensity_2d_3_tmp=output_3_1a(1,1);
    ch1_intensity_2d_3=ch1_intensity_2d_3_tmp{1};
    ch1_intensity_2d_4_tmp=output_4_1a(1,1);
    ch1_intensity_2d_4=ch1_intensity_2d_4_tmp{1};
    max_g1=max(ch1_intensity_2d_1(1:(size(ch1_intensity_2d_1,1)*size(ch1_intensity_2d_1,2))));
    max_g2=max(ch1_intensity_2d_2(1:(size(ch1_intensity_2d_2,1)*size(ch1_intensity_2d_2,2))));
    max_g3=max(ch1_intensity_2d_3(1:(size(ch1_intensity_2d_3,1)*size(ch1_intensity_2d_3,2))));
    max_g4=max(ch1_intensity_2d_4(1:(size(ch1_intensity_2d_4,1)*size(ch1_intensity_2d_4,2))));
    max_g=(max([max_g1,max_g2,max_g3,max_g4]))*0.7;
    
    
    %base area projections
    [ch1_base_area_surface_2d_1]=make_2d_projection_figures(output_1_1a,Node_base_area1a);
    [ch1_base_area_surface_2d_2]=make_2d_projection_figures(output_2_1a,Node_base_area1a);
    [ch1_base_area_surface_2d_3]=make_2d_projection_figures(output_3_1a,Node_base_area1a);
    [ch1_base_area_surface_2d_4]=make_2d_projection_figures(output_4_1a,Node_base_area1a);
    
    %sharpness projections
    [ch1_sharpness_surface_2d_1]=make_sharpness_surface(ch1_base_area_surface_2d_1,ch1_height_surface_2d_1);
    [ch1_sharpness_surface_2d_2]=make_sharpness_surface(ch1_base_area_surface_2d_2,ch1_height_surface_2d_2);
    [ch1_sharpness_surface_2d_3]=make_sharpness_surface(ch1_base_area_surface_2d_3,ch1_height_surface_2d_3);
    [ch1_sharpness_surface_2d_4]=make_sharpness_surface(ch1_base_area_surface_2d_4,ch1_height_surface_2d_4);
    
    %screen by villi height
    height_1_test=handles.UseHeightCh1ForVilli;
    if height_1_test==1
       ch1_height_min=handles.Ch1HeightMin;
       ch1_height_max=handles.Ch1HeightMax;
       [ch1_height_surface_2d_1_ret,ch1_height_surface_2d_2_ret,ch1_height_surface_2d_3_ret,ch1_height_surface_2d_4_ret]=screen_2d_projections_by_para(ch1_height_surface_2d_1,ch1_height_surface_2d_2,ch1_height_surface_2d_3,ch1_height_surface_2d_4,ch1_height_min,ch1_height_max,0);
    else
        ch1_height_surface_2d_1_ret=ch1_height_surface_2d_1;
        ch1_height_surface_2d_2_ret=ch1_height_surface_2d_2;
        ch1_height_surface_2d_3_ret=ch1_height_surface_2d_3;
        ch1_height_surface_2d_4_ret=ch1_height_surface_2d_4;
    end
    
    %screen by base area
    base_1_test=handles.UseBaseAreaCh1ForVilli;
    if base_1_test==1
       ch1_base_min=handles.Ch1BaseAreaMin;
       ch1_base_max=handles.Ch1BaseAreaMax;
       [ch1_base_area_surface_2d_1_ret,ch1_base_area_surface_2d_2_ret,ch1_base_area_surface_2d_3_ret,ch1_base_area_surface_2d_4_ret]=screen_2d_projections_by_para(ch1_base_area_surface_2d_1,ch1_base_area_surface_2d_2,ch1_base_area_surface_2d_3,ch1_base_area_surface_2d_4,ch1_base_min,ch1_base_max,0);
    else
        ch1_base_area_surface_2d_1_ret=ch1_base_area_surface_2d_1;
        ch1_base_area_surface_2d_2_ret=ch1_base_area_surface_2d_2;
        ch1_base_area_surface_2d_3_ret=ch1_base_area_surface_2d_3;
        ch1_base_area_surface_2d_4_ret=ch1_base_area_surface_2d_4;
    end
    
    %screen by sharpness
    sharp_1_test=handles.UseSharpnessCh1ForVilli;
    if sharp_1_test==1
       ch1_sharp_min=handles.Ch1SharpnessMin;
       ch1_sharp_max=handles.Ch1SharpnessMax;
       [ch1_sharpness_surface_2d_1_ret,ch1_sharpness_surface_2d_2_ret,ch1_sharpness_surface_2d_3_ret,ch1_sharpness_surface_2d_4_ret]=screen_2d_projections_by_para(ch1_sharpness_surface_2d_1,ch1_sharpness_surface_2d_2,ch1_sharpness_surface_2d_3,ch1_sharpness_surface_2d_4,ch1_sharp_min,ch1_sharp_max,0);
    else
        ch1_sharpness_surface_2d_1_ret=ch1_sharpness_surface_2d_1;
        ch1_sharpness_surface_2d_2_ret=ch1_sharpness_surface_2d_2;
        ch1_sharpness_surface_2d_3_ret=ch1_sharpness_surface_2d_3;
        ch1_sharpness_surface_2d_4_ret=ch1_sharpness_surface_2d_4;
    end
    

    %rgb rendering - curvature
    ch1_curve_surface_2d_1_rgb=make_rgb_im_masked(ch1_curve_surface_2d_1,ch1_int_surface_2d_1,-0.5,0.5,ens_curve_map,1);
    ch1_curve_surface_2d_2_rgb=make_rgb_im_masked(ch1_curve_surface_2d_2,ch1_int_surface_2d_2,-0.5,0.5,ens_curve_map,1);
    ch1_curve_surface_2d_3_rgb=make_rgb_im_masked(ch1_curve_surface_2d_3,ch1_int_surface_2d_3,-0.5,0.5,ens_curve_map,1);
    ch1_curve_surface_2d_4_rgb=make_rgb_im_masked(ch1_curve_surface_2d_4,ch1_int_surface_2d_4,-0.5,0.5,ens_curve_map,1);
    
    %making shading to match surface
    idx_s1=find(ch1_curve_surface_2d_1<=-0.5);
    idx_s2=find(ch1_curve_surface_2d_1>=0.5);
    if numel(idx_s1)>0
        ch1_curve_surface_2d_1(idx_s1)=-0.5;
    end
    
    if numel(idx_s2)>0
        ch1_curve_surface_2d_1(idx_s2)=0.5;
    end
    
    idx_t1=find(ch1_curve_surface_2d_2<=-0.5);
    idx_t2=find(ch1_curve_surface_2d_2>=0.5);
    if numel(idx_t1)>0
        ch1_curve_surface_2d_2(idx_t1)=-0.5;
    end
    
    if numel(idx_t2)>0
        ch1_curve_surface_2d_2(idx_t2)=0.5;
    end
    
    idx_u1=find(ch1_curve_surface_2d_3<=-0.5);
    idx_u2=find(ch1_curve_surface_2d_3>=0.5);
    if numel(idx_u1)>0
        ch1_curve_surface_2d_3(idx_u1)=-0.5;
    end
    
    if numel(idx_u2)>0
        ch1_curve_surface_2d_3(idx_u2)=0.5;
    end
    
    idx_v1=find(ch1_curve_surface_2d_4<=-0.5);
    idx_v2=find(ch1_curve_surface_2d_4>=0.5);
    if numel(idx_v1)>0
        ch1_curve_surface_2d_4(idx_v1)=-0.5;
    end
    
    if numel(idx_v2)>0
        ch1_curve_surface_2d_4(idx_v2)=0.5;
    end
    
    ch1_curve_surface_2d_1=ch1_curve_surface_2d_1+0.5;
    idx_pav=find(ch1_int_surface_2d_1==0);
    ch1_curve_surface_2d_1(idx_pav)=-.1;
    figure, surf(ch1_curve_surface_2d_1); colormap(ens_curve_map); shading interp; colorbar; axis tight;title('Ch1 - Curvature 1');
     
    ch1_curve_surface_2d_2=ch1_curve_surface_2d_2+0.5;
    idx_pav2=find(ch1_int_surface_2d_2==0);
    ch1_curve_surface_2d_2(idx_pav2)=-.1;
    figure, surf(ch1_curve_surface_2d_2); colormap(ens_curve_map); shading interp; colorbar; axis tight;title('Ch1 - Curvature 2');
     
    ch1_curve_surface_2d_3=ch1_curve_surface_2d_3+0.5;
    idx_pav3=find(ch1_int_surface_2d_3==0);
    ch1_curve_surface_2d_3(idx_pav3)=-.1;
    figure, surf(ch1_curve_surface_2d_3); colormap(ens_curve_map); shading interp; colorbar; axis tight;title('Ch1 - Curvature 3');
      
    ch1_curve_surface_2d_4=ch1_curve_surface_2d_4+0.5;
    idx_pav4=find(ch1_int_surface_2d_4==0);
    ch1_curve_surface_2d_4(idx_pav4)=-.1;
    figure, surf(ch1_curve_surface_2d_4); colormap(ens_curve_map); shading interp; colorbar; axis tight;title('Ch1 - Curvature 4');
      
   
    
%     figure, imshow(ch1_curve_surface_2d_1_rgb); title('Ch1 - Curvature 1');
%     figure, imshow(ch1_curve_surface_2d_2_rgb); title('Ch1 - Curvature 2');
%     figure, imshow(ch1_curve_surface_2d_3_rgb); title('Ch1 - Curvature 3');
%     figure, imshow(ch1_curve_surface_2d_4_rgb); title('Ch1 - Curvature 4');
 
    figure, imagesc(ch1_intensity_2d_1); colormap(green_map); colorbar; title('Ch1 - Intensity - 1'); 
    figure, imagesc(ch1_intensity_2d_2); colormap(green_map); colorbar; title('Ch1 - Intensity - 2'); 
    figure, imagesc(ch1_intensity_2d_3); colormap(green_map); colorbar; title('Ch1 - Intensity - 3'); 
    figure, imagesc(ch1_intensity_2d_4); colormap(green_map); colorbar; title('Ch1 - Intensity - 4'); 
    
%     figure, imagesc(ch1_height_surface_2d_1); colormap(jet_map); colorbar; title('Ch1 - Height - 1'); 
%     figure, imagesc(ch1_height_surface_2d_2); colormap(jet_map); colorbar; title('Ch1 - Height - 2'); 
%     figure, imagesc(ch1_height_surface_2d_3); colormap(jet_map); colorbar; title('Ch1 - Height - 3'); 
%     figure, imagesc(ch1_height_surface_2d_4); colormap(jet_map); colorbar; title('Ch1 - Height - 4'); 
%     
%     figure, imagesc(ch1_base_area_surface_2d_1); colormap(jet_map); colorbar; title('Ch1 - Base Area - 1'); 
%     figure, imagesc(ch1_base_area_surface_2d_2); colormap(jet_map); colorbar; title('Ch1 - Base Area - 2'); 
%     figure, imagesc(ch1_base_area_surface_2d_3); colormap(jet_map); colorbar; title('Ch1 - Base Area - 3'); 
%     figure, imagesc(ch1_base_area_surface_2d_4); colormap(jet_map); colorbar; title('Ch1 - Base Area - 4'); 
%     
%     figure, imagesc(ch1_sharpness_surface_2d_1); colormap(jet_map); colorbar;title('Ch1 - Sharpness - 1');
%     figure, imagesc(ch1_sharpness_surface_2d_2); colormap(jet_map); colorbar;title('Ch1 - Sharpness - 2');
%     figure, imagesc(ch1_sharpness_surface_2d_3); colormap(jet_map); colorbar;title('Ch1 - Sharpness - 3');
%     figure, imagesc(ch1_sharpness_surface_2d_4); colormap(jet_map); colorbar;title('Ch1 - Sharpness - 4');
    
    figure, imagesc(ch1_int_surface_2d_1); colormap(green_map); colorbar; title('Ch1 Intensity Surface - 1');
    figure, imagesc(ch1_int_surface_2d_2); colormap(green_map); colorbar; title('Ch1 Intensity Surface - 2');
    figure, imagesc(ch1_int_surface_2d_3); colormap(green_map); colorbar; title('Ch1 Intensity Surface - 3');
    figure, imagesc(ch1_int_surface_2d_4); colormap(green_map); colorbar; title('Ch1 Intensity Surface - 4');
    
    ch1_curve_surface_2d_1_rgbm=make_rgb_im_masked(ch1_curve_surface_2d_1_ret,ch1_int_surface_2d_1,-0.5,0.5,ens_curve_map_mask,1);
    ch1_curve_surface_2d_2_rgbm=make_rgb_im_masked(ch1_curve_surface_2d_2_ret,ch1_int_surface_2d_2,-0.5,0.5,ens_curve_map_mask,1);
    ch1_curve_surface_2d_3_rgbm=make_rgb_im_masked(ch1_curve_surface_2d_3_ret,ch1_int_surface_2d_3,-0.5,0.5,ens_curve_map_mask,1);
    ch1_curve_surface_2d_4_rgbm=make_rgb_im_masked(ch1_curve_surface_2d_4_ret,ch1_int_surface_2d_4,-0.5,0.5,ens_curve_map_mask,1);
    
    figure, imshow(ch1_curve_surface_2d_1_rgbm); title('Ch1 - Curvature 1');
    figure, imshow(ch1_curve_surface_2d_2_rgbm); title('Ch1 - Curvature 2');
    figure, imshow(ch1_curve_surface_2d_3_rgbm); title('Ch1 - Curvature 3');
    figure, imshow(ch1_curve_surface_2d_4_rgbm); title('Ch1 - Curvature 4');

end

%Get and load files - Channel 2
if handles.success_h2==1

    %pathname to villi geometry files
    path_geo2a=handles.pathname_h2;
    
    %gather_matrices_for_villi_thresh
    [Node_base_area2a,Node_villi_height2a,Node_villi_SA2a,node_curve2a,node_int2a,Face_mat_villi2a,int_stack2a,ns,ne,min_curve_2a,max_curve_2a,cluster_stack_2a]=gather_matrices_for_villi_thresh(path_geo2a,2);

    %Assuming data is scaled for LLS
    Node_base_area2a(:,3)=Node_base_area2a(:,3)./1.75;
    Node_villi_height2a(:,3)=Node_villi_height2a(:,3)./1.75;
    Node_villi_SA2a(:,3)=Node_villi_SA2a(:,3)./1.75;
    node_curve2a(:,3)=node_curve2a(:,3)./1.75;
    node_int2a(:,3)=node_int2a(:,3)./1.75;
    
    %number of images
    num_images_in=ne-ns+1;
    
    %doing the 2d projections
    [output_1_2a,output_2_2a,output_3_2a,output_4_2a]=create_all_the_2d_intensity_projections(int_stack2a,cluster_stack_2a,num_images_in);
    
    %2d projections of clusters - from images not surfaces
    ch2_coloc_cluster_2d_1_tmp=output_1_2a(2,1);
    ch2_coloc_cluster_2d_1=ch2_coloc_cluster_2d_1_tmp{1};
    ch2_coloc_cluster_2d_2_tmp=output_2_2a(2,1);
    ch2_coloc_cluster_2d_2=ch2_coloc_cluster_2d_2_tmp{1};
    ch2_coloc_cluster_2d_3_tmp=output_3_2a(2,1);
    ch2_coloc_cluster_2d_3=ch2_coloc_cluster_2d_3_tmp{1};
    ch2_coloc_cluster_2d_4_tmp=output_4_2a(2,1);
    ch2_coloc_cluster_2d_4=ch2_coloc_cluster_2d_4_tmp{1};
    
    %2d projections of intensity - from images not surfaces
    ch2_intensity_2d_1_tmp=output_1_2a(1,1);
    ch2_intensity_2d_1=ch2_intensity_2d_1_tmp{1};
    ch2_intensity_2d_2_tmp=output_2_2a(1,1);
    ch2_intensity_2d_2=ch2_intensity_2d_2_tmp{1};
    ch2_intensity_2d_3_tmp=output_3_2a(1,1);
    ch2_intensity_2d_3=ch2_intensity_2d_3_tmp{1};
    ch2_intensity_2d_4_tmp=output_4_2a(1,1);
    ch2_intensity_2d_4=ch2_intensity_2d_4_tmp{1};
    max_r1=max(ch2_intensity_2d_1(1:(size(ch2_intensity_2d_1,1)*size(ch2_intensity_2d_1,2))));
    max_r2=max(ch2_intensity_2d_2(1:(size(ch2_intensity_2d_2,1)*size(ch2_intensity_2d_2,2))));
    max_r3=max(ch2_intensity_2d_3(1:(size(ch2_intensity_2d_3,1)*size(ch2_intensity_2d_3,2))));
    max_r4=max(ch2_intensity_2d_4(1:(size(ch2_intensity_2d_4,1)*size(ch2_intensity_2d_4,2))));
    max_r=(max([max_r1,max_r2,max_r3,max_r4]))*0.7;
    
    %intensity surface projections - sanity check
    [ch2_int_surface_1]=make_2d_projection_figures(output_1_2a,node_int2a);
    [ch2_int_surface_2]=make_2d_projection_figures(output_2_2a,node_int2a);
    [ch2_int_surface_3]=make_2d_projection_figures(output_3_2a,node_int2a);
    [ch2_int_surface_4]=make_2d_projection_figures(output_4_2a,node_int2a);
    
    %curvature surface projections
    [ch2_curve_surface_2d_1]=make_2d_projection_figures(output_1_2a,node_curve2a);
    [ch2_curve_surface_2d_2]=make_2d_projection_figures(output_2_2a,node_curve2a);
    [ch2_curve_surface_2d_3]=make_2d_projection_figures(output_3_2a,node_curve2a);
    [ch2_curve_surface_2d_4]=make_2d_projection_figures(output_4_2a,node_curve2a);
    
     %thresholding curvature surfaces
    [ch2_curve_surface_2d_1_ret,ch2_curve_surface_2d_2_ret,ch2_curve_surface_2d_3_ret,ch2_curve_surface_2d_4_ret]=screen_2d_projections_by_para(ch2_curve_surface_2d_1,ch2_curve_surface_2d_2,ch2_curve_surface_2d_3,ch2_curve_surface_2d_4,min_curve_2a,max_curve_2a,1);
    
    
    %making shading to match surface
    idx_s1=find(ch2_curve_surface_2d_1<=-0.5);
    idx_s2=find(ch2_curve_surface_2d_1>=0.5);
    if numel(idx_s1)>0
        ch2_curve_surface_2d_1(idx_s1)=-0.5;
    end
    
    if numel(idx_s2)>0
        ch2_curve_surface_2d_1(idx_s2)=0.5;
    end
    
    ch2_curve_surface_2d_1=ch2_curve_surface_2d_1+0.5;
    idx_pav_c2=find(ch2_int_surface_1==0);
    ch2_curve_surface_2d_1(idx_pav_c2)=-.1;
    figure, surf(ch2_curve_surface_2d_1); colormap(ens_curve_map); shading interp; colorbar; axis tight;title('Ch2 - Curvature 1');
   figure, imagesc(ch2_intensity_2d_1); colormap(red_map); colorbar; title('Ch2 - Intensity - 1'); 
    
     %height projections
    [ch2_height_surface_2d_1]=make_2d_projection_figures(output_1_2a,Node_villi_height2a);
    [ch2_height_surface_2d_2]=make_2d_projection_figures(output_2_2a,Node_villi_height2a);
    [ch2_height_surface_2d_3]=make_2d_projection_figures(output_3_2a,Node_villi_height2a);
    [ch2_height_surface_2d_4]=make_2d_projection_figures(output_4_2a,Node_villi_height2a);
    
    %base area projections
    [ch2_base_area_surface_2d_1]=make_2d_projection_figures(output_1_2a,Node_base_area2a);
    [ch2_base_area_surface_2d_2]=make_2d_projection_figures(output_2_2a,Node_base_area2a);
    [ch2_base_area_surface_2d_3]=make_2d_projection_figures(output_3_2a,Node_base_area2a);
    [ch2_base_area_surface_2d_4]=make_2d_projection_figures(output_4_2a,Node_base_area2a);
    
    %sharpness projections
    [ch2_sharpness_surface_2d_1]=make_sharpness_surface(ch2_base_area_surface_2d_1,ch2_height_surface_2d_1);
    [ch2_sharpness_surface_2d_2]=make_sharpness_surface(ch2_base_area_surface_2d_2,ch2_height_surface_2d_2);
    [ch2_sharpness_surface_2d_3]=make_sharpness_surface(ch2_base_area_surface_2d_3,ch2_height_surface_2d_3);
    [ch2_sharpness_surface_2d_4]=make_sharpness_surface(ch2_base_area_surface_2d_4,ch2_height_surface_2d_4);
    
    %screen by villi height
    height_2_test=handles.UseHeightCh2ForVilli;
    if height_2_test==1
       ch2_height_min=handles.Ch2HeightMin;
       ch2_height_max=handles.Ch2HeightMax;
       [ch2_height_surface_2d_1_ret,ch2_height_surface_2d_2_ret,ch2_height_surface_2d_3_ret,ch2_height_surface_2d_4_ret]=screen_2d_projections_by_para(ch2_height_surface_2d_1,ch2_height_surface_2d_2,ch2_height_surface_2d_3,ch2_height_surface_2d_4,ch2_height_min,ch2_height_max,0);
    else
        ch2_height_surface_2d_1_ret=ch2_height_surface_2d_1;
        ch2_height_surface_2d_2_ret=ch2_height_surface_2d_2;
        ch2_height_surface_2d_3_ret=ch2_height_surface_2d_3;
        ch2_height_surface_2d_4_ret=ch2_height_surface_2d_4;
    end
    
    %screen by base area
    base_2_test=handles.UseBaseAreaCh2ForVilli;
    if base_2_test==1
       ch2_base_min=handles.Ch2BaseAreaMin;
       ch2_base_max=handles.Ch2BaseAreaMax;
       [ch2_base_area_surface_2d_1_ret,ch2_base_area_surface_2d_2_ret,ch2_base_area_surface_2d_3_ret,ch2_base_area_surface_2d_4_ret]=screen_2d_projections_by_para(ch2_base_area_surface_2d_1,ch2_base_area_surface_2d_2,ch2_base_area_surface_2d_3,ch2_base_area_surface_2d_4,ch2_base_min,ch2_base_max,0);
    else
        ch2_base_area_surface_2d_1_ret=ch2_base_area_surface_2d_1;
        ch2_base_area_surface_2d_2_ret=ch2_base_area_surface_2d_2;
        ch2_base_area_surface_2d_3_ret=ch2_base_area_surface_2d_3;
        ch2_base_area_surface_2d_4_ret=ch2_base_area_surface_2d_4;
    end
    
    %screen by sharpness
    sharp_2_test=handles.UseSharpnessCh2ForVilli;
    if sharp_2_test==1
       ch2_sharp_min=handles.Ch2SharpnessMin;
       ch2_sharp_max=handles.Ch2SharpnessMax;
       [ch2_sharpness_surface_2d_1_ret,ch2_sharpness_surface_2d_2_ret,ch2_sharpness_surface_2d_3_ret,ch2_sharpness_surface_2d_4_ret]=screen_2d_projections_by_para(ch2_sharpness_surface_2d_1,ch2_sharpness_surface_2d_2,ch2_sharpness_surface_2d_3,ch2_sharpness_surface_2d_4,ch2_sharp_min,ch2_sharp_max,0);
    else
        ch1_sharpness_surface_2d_1_ret=ch1_sharpness_surface_2d_1;
        ch1_sharpness_surface_2d_2_ret=ch1_sharpness_surface_2d_2;
        ch1_sharpness_surface_2d_3_ret=ch1_sharpness_surface_2d_3;
        ch1_sharpness_surface_2d_4_ret=ch1_sharpness_surface_2d_4;
    end
    
        %rgb rendering - curvature
        ch2_curve_surface_2d_1_rgb=make_rgb_im_masked(ch2_curve_surface_2d_1,ch2_int_surface_1,-0.5,0.5,ens_curve_map,1);
        ch2_curve_surface_2d_2_rgb=make_rgb_im_masked(ch2_curve_surface_2d_2,ch2_int_surface_2,-0.5,0.5,ens_curve_map,1);
        ch2_curve_surface_2d_3_rgb=make_rgb_im_masked(ch2_curve_surface_2d_3,ch2_int_surface_3,-0.5,0.5,ens_curve_map,1);
        ch2_curve_surface_2d_4_rgb=make_rgb_im_masked(ch2_curve_surface_2d_4,ch2_int_surface_4,-0.5,0.5,ens_curve_map,1);

end

%loading colocalization information
if handles.UseColocCh1ForVilli==1 || handles.UseColocCh2ForVilli==1
    the_coloc_info=handles.MasterColocBlobMat
end


%storing the handles
guidata(hObject, handles);

% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%This is button to calculate geometric%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%parameters of villi from preloaded file%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%getting flags to tell me which channels are being used
flag_b1=handles.flag_file_villi_para_calc_ch1;
flag_b2=handles.flag_file_villi_para_calc_ch2;

%path and filename from user and calculating villi geo parameters
if flag_b1==1
    %get path
    path_user_villi_ch1=handles.pathname_v1;
    
    %create path and file to txt file with curv thrtesh
    path_txt_thresh1=strcat(path_user_villi_ch1,'Ch1_villi_thresh_info.txt');
    
    %calculate villi geometric parameters
	calc_geometry_of_villi(path_user_villi_ch1,path_txt_thresh1);
end
if flag_b2==1
    
    %get path
    path_user_villi_ch2=handles.pathname_v2;
    
    %create path and file to txt file with curv thresh
    path_txt_thresh2=strcat(path_user_villi_ch2,'Ch2_villi_thresh_info.txt');
    
    %calculate geometric parameters of villi
    calc_geometry_of_villi(path_user_villi_ch2,path_txt_thresh2);
end

%storing the handles
guidata(hObject, handles);

% --- Executes on button press in pushbutton14.
function pushbutton14_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%This is the button to direct program to grab villi files to calculate%%%
%%%%%%%%%%%%%%%%%%%%%%parameters that describe villi%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Channel 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Button to get the "Final_villi_info.mat" file
[file_pv1,path_pv1,success]=uigetfile;
handles.filename_v1=file_pv1;
handles.pathname_v1=path_pv1;

%this is flag to tell me someone is using this channel
handles.flag_file_villi_para_calc_ch1=success;

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in pushbutton15.
function pushbutton15_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%This is the button to direct program to grab villi files to calculate%%%
%%%%%%%%%%%%%%%%%%%%%%parameters that describe villi%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Channel 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Button to get the "Final_villi_info.mat" file
[file_pv2,path_pv2,success]=uigetfile;
handles.filename_v2=file_pv2;
handles.pathname_v2=path_pv2;

%this is flag to tell me someone is using this channel
handles.flag_file_villi_para_calc_ch2=success;

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in checkbox10.
function checkbox10_Callback(hObject, eventdata, handles)
% hObject    handle to checkbox10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of checkbox10

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%This is checkbox that indicates if colocalization%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%info should be in histograms%%%%%%%%%%%%%%%%%%%%%%

handles.check10_for_coloc_hist=get(handles.checkbox10,'value');

%storing the handles
guidata(hObject, handles);

% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%This is the radiobutton to select%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%registered colocallilzation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Hint: get(hObject,'Value') returns toggle state of radiobutton4
handles.UseRegisteredColocalization=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%This is the radiobutton to select%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%unregistered colocallilzation%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Hint: get(hObject,'Value') returns toggle state of radiobutton5

handles.UseUnRegisteredColocalization=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%This is the button to upload vill parameter information into%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%into histograms%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%channel 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%You can pick any file

%Button to get file
[file_h2,path_h2,success_h2]=uigetfile;
handles.filename_h2=file_h2;
handles.pathname_h2=path_h2;

%flag to indicate file has been picked
handles.success_h2=success_h2;

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in pushbutton17.
function pushbutton17_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton17 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%This is the pushbutton to populate histograms%%%%%%%%%%%%%%%%%%%
% 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%Getting and Loading Files%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%Get and load files - Channel 1
if handles.success_h1==1
   
    %pathname to villi geometry files
    file_geo_1=handles.pathname_h1;
    
    %matrix - for histogram - Channel 1
    MatHist1_tmp=load(strcat(file_geo_1,'Villi_GEO_Para_hist.mat'));
    handles.MatHist1=MatHist1_tmp.villi_para_master_mat;
    
    %Adding colocalization information
    if handles.check10_for_coloc_hist==1
        
        %registered colocalization
        if handles.UseRegisteredColocalization==1
            
            %Path for regidtered colocalization - Channel 1
            idx_reg1=find(file_geo_1=='\');
            file_reg1_tmp=file_geo_1(1:idx_reg1(numel(idx_reg1)-3));
            coloc_reg1_tmp=load(strcat(file_reg1_tmp,'Registered\g0\Blob Colocalization\Blob_Colocalization_Results.mat'));
            coloc_reg1=coloc_reg1_tmp.mat_save_the_blob;
            
            %store the blob matrix in a handle
            handles.MasterColocBlobMat=coloc_reg1;
            
        end
    end

    
end

%Get and load files - Channel 2
if handles.success_h2==1
   
    %pathname to villi geometry files
    file_geo_2=handles.pathname_h2;
    
    %matrix - for histogram - Channel 2
    MatHist2_tmp=load(strcat(file_geo_2,'Villi_GEO_Para_hist.mat'));
    handles.MatHist2=MatHist2_tmp.villi_para_master_mat;
    
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%Loading the Histograms%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Channel 1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if handles.success_h1==1

    %colocalization
    if handles.check10_for_coloc_hist==1
        %registered colocalization
        if handles.UseRegisteredColocalization==1
            axes(handles.axes1);
            nbins_coloc=linspace(0,100,10);
            hist(coloc_reg1(:,3),nbins_coloc);
            xlabel('Coloc. %'); ylabel('#');
        end
    end
    
    %villi height
    the_MatHist1=handles.MatHist1;
    axes(handles.axes2);
    hist(the_MatHist1(:,2));
    xlabel('Villi Height (um)'); ylabel('#');

    %villi surface area
    axes(handles.axes3);
    hist(the_MatHist1(:,4));
    xlabel('Base Area (um^2)'); ylabel('#');
    
    %villi sharpness
    axes(handles.axes4);
    hist(the_MatHist1(:,5));
    xlabel('Sharpness'); ylabel('#');
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%Loading the Histograms%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Channel 2%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if handles.success_h2==1

    %colocalization
    if handles.check10_for_coloc_hist==1
        %registered colocalization
        if handles.UseRegisteredColocalization==1
            axes(handles.axes5);
            nbins_coloc=linspace(0,100,10);
            hist(coloc_reg1(:,3),nbins_coloc);
            xlabel('Coloc. %'); ylabel('#');
        end
    end
    
    %villi height
    the_MatHist2=handles.MatHist2;
    axes(handles.axes6);
    hist(the_MatHist2(:,2));
    xlabel('Villi Height (um)'); ylabel('#');

    %villi surface area
    axes(handles.axes7);
    hist(the_MatHist2(:,4));
    xlabel('Base Area (um^2)'); ylabel('#');
    
    %villi sharpness
    axes(handles.axes8);
    hist(the_MatHist2(:,5));
    xlabel('Sharpness'); ylabel('#');
    
end

%storing the handles
guidata(hObject, handles);
