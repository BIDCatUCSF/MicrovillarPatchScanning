function[cl_1_ret,cl_2_ret,para_1_ret,para_2_ret,para_1_ret_rev,para_2_ret_rev]=mask_super_surfaces(cl_1,cl_2,para_1,para_2,in_mat,the_mark,nStart,nEnd)

%inputs
% cl_1 = node matrix cluster - ch1
% cl_2 = node matrix cluster - ch2
% para_1 = node matrix parameter - ch1
% para_2 = node matrix parameter - ch2
% in_mat = matrix of sper cluster #s (col 1 - green, col 2 - red)
% the_mark = tells me which parameter (1) - curvature, (2) - integrated intensity

%just for testing\debugging only
idx_john1=find(para_1(:,4)<-0.5);
idx_john2=find(para_2(:,4)<-0.5);
if numel(idx_john1)>0
    para_1(idx_john1,4)=-0.5;
end
if numel(idx_john2)>0
    para_2(idx_john2,4)=-0.5;
end

%intializing return nodes
cl_1_ret=cl_1;
cl_2_ret=cl_2;
para_1_ret=para_1;
para_2_ret=para_2;
para_1_ret_rev=para_1;
para_2_ret_rev=para_2;

%blanking
cl_1_ret(:,4)=0;
cl_2_ret(:,4)=0;
if the_mark==1
    para_1_ret(:,4)=-0.6;
    para_2_ret(:,4)=-0.6;
else
    para_1_ret(:,4)=0;
    para_2_ret(:,4)=0;
end

%masking
for i=1:numel(in_mat(:,1))
    
    %locate cluster
    idx1=find(cl_1(:,4)==in_mat(i,1));
    idx2=find(cl_2(:,4)==in_mat(i,2));
    
    %masking cluster nodes
    if numel(idx1)>0
        cl_1_ret(idx1,4)=cl_1(idx1,4);
    end
    if numel(idx2)>0
        cl_2_ret(idx2,4)=cl_2(idx2,4);
    end
    
    %making parameter nodes
    if the_mark==1
        %channel 1
        if numel(idx1)>0
            para_1_ret(idx1,4)=para_1(idx1,4);
            para_1_ret_rev(idx1,4)=-0.6;
        end
        %channel 2
        if numel(idx2)>0
            para_2_ret(idx2,4)=para_2(idx2,4);
            para_2_ret_rev(idx2,4)=-0.6;
        end
    else
        %channel 1
        if numel(idx1)>0
            para_1_ret(idx1,4)=para_1(idx1,4);
            para_1_ret_rev(idx1,4)=0;
        end
        %channel 2
        if numel(idx2)>0
            para_2_ret(idx2,4)=para_2(idx2,4);
            para_2_ret_rev(idx2,4)=0;
        end
    end
    
    %clear statements
    clear idx1; clear idx2;
    
end
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
%%%%%%%%%%%%%%%%%%%adding some histograms%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%extrema in z
min_z=min(para_1_ret_rev(:,3))+1.5;
max_z=max(para_1_ret_rev(:,3))-1.5;

%bins of histogram
if the_mark ==1 %curvature
    
    %removing the top-most and bottom-most (plateau region) so as not to
    %include it in curvature calculation
    %channel 1
    idx_bad1=find(para_1_ret_rev(:,3)<min_z);
    idx_bad2=find(para_1_ret_rev(:,3)>max_z);
    if numel(idx_bad1)>0
        para_1_ret_rev(idx_bad1,4)=-0.6;
    end
    if numel(idx_bad2)>0
        para_1_ret_rev(idx_bad2,4)=-0.6;
    end
    
    
    %channel 2
    idx_bad12=find(para_2_ret_rev(:,3)<(min_z));
    idx_bad22=find(para_2_ret_rev(:,3)>(max_z));
    if numel(idx_bad12)>0
        para_2_ret_rev(idx_bad12,4)=-0.6;
    end
     if numel(idx_bad22)>0
        para_2_ret_rev(idx_bad22,4)=-0.6;
    end
    
    %channel 1 and channel 2
    nbins1=linspace(-0.5,0.5,15);
    nbins2=linspace(-0.5,0.5,15);
    
    %arrays for histograms - in cluster
    idx1c=find(para_1_ret(:,4)>-0.6);
    para_1_ret_hist_tmp=para_1_ret(idx1c,4);
    idxA=find(para_1_ret_hist_tmp~=0);
    para_1_ret_hist=para_1_ret_hist_tmp(idxA);
    
    idx2c=find(para_2_ret(:,4)>-0.6);
    para_2_ret_hist_tmp=para_2_ret(idx2c,4);
    idxB=find(para_2_ret_hist_tmp~=0);
    para_2_ret_hist=para_2_ret_hist_tmp(idxB);
    
    %arrays for histograms - not in cluster
    idx1cR=find(para_1_ret_rev(:,4)>-0.6);
    para_1_ret_rev_hist_tmp=para_1_ret_rev(idx1cR,4);
    idxC=find(para_1_ret_rev_hist_tmp~=0);
    para_1_ret_rev_hist=para_1_ret_rev_hist_tmp(idxC);
    
    idx2cR=find(para_2_ret_rev(:,4)>-0.6);
    para_2_ret_rev_hist_tmp=para_2_ret_rev(idx2cR,4);
    idxD=find(para_2_ret_rev_hist_tmp~=0);
    para_2_ret_rev_hist=para_2_ret_rev_hist_tmp(idxD);
    
    
    
else %integrated intensity
    
    %channel 1
    idx_int1=find(para_1(:,4)>0);
    all_int1=para_1(idx_int1,4);
    avg1=mean(all_int1);
    std1=std(all_int1);
    nbins1=linspace(avg1-std1,avg1+std1,10);
    
    %channel 2
    idx_int2=find(para_2(:,4)>0);
    all_int2=para_2(idx_int2,4);
    avg2=mean(all_int2);
    std2=std(all_int2);
    nbins2=linspace(avg2-std2,avg2+std2,10);
    
end

%histogram - channel 1
[y1_in,x1_in]=hist(para_1_ret_hist,nbins1);
[y1_out,x1_out]=hist(para_1_ret_rev_hist,nbins1);
%y1_in=y1_in_tmp(3:(numel(y1_in_tmp)-1));
%x1_in=x1_in_tmp(3:(numel(y1_in_tmp)-1));
y1_in_norm=y1_in.*(max(y1_out)/max(y1_in));

%histogram - channel 2
[y2_in,x2_in]=hist(para_2_ret_hist,nbins2);
[y2_out,x2_out]=hist(para_2_ret_rev_hist,nbins2);    
%y2_in=y2_in_tmp(3:(numel(y2_in_tmp)-1));
%x2_in=x2_in_tmp(3:(numel(y2_in_tmp)-1));
y2_in_norm=y2_in.*(max(y2_out)/max(y2_in));
    
%figure - channel 1 
% figure, hold on; title('Channel 1');
% plot(x1_in,y1_in_norm,'k','LineWidth',1.5);
% plot(x1_out,y1_out,'k','Color',[0.6,0.6,0.6],'LineWidth',1.5);
% ylabel('#'); legend('In Coloc. Cl','Not In Coloc. Cl');
% if the_mark==1
%     xlabel('Curvature');
%    % xlim([-0.4,0.4]);
% else
%     xlabel('Integr. Intens.');
% end
% 
% %figure - channel 2
% figure, hold on; title('Channel 2');
% plot(x2_in,y2_in_norm,'k','LineWidth',1.5);
% plot(x2_out,y2_out,'k','Color',[0.6,0.6,0.6],'LineWidth',1.5);
% ylabel('#'); legend('In Coloc. Cl','Not In Coloc. Cl');
% if the_mark==1
%     xlabel('Curvature');
%     %xlim([-0.4,0.4]);
% else
%     xlabel('Integr. Intens.');
% end
    



































































