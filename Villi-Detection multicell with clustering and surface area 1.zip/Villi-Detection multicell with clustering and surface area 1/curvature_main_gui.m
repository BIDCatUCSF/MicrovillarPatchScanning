



function varargout = curvature_main_gui(varargin)
% CURVATURE_MAIN_GUI MATLAB code for curvature_main_gui.fig
%      CURVATURE_MAIN_GUI, by itself, creates a new CURVATURE_MAIN_GUI or raises the existing
%      singleton*.
%
%      H = CURVATURE_MAIN_GUI returns the handle to a new CURVATURE_MAIN_GUI or the handle to
%      the existing singleton*.
%
%      CURVATURE_MAIN_GUI('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in CURVATURE_MAIN_GUI.M with the given input arguments.
%
%      CURVATURE_MAIN_GUI('Property','Value',...) creates a new CURVATURE_MAIN_GUI or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before curvature_main_gui_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to curvature_main_gui_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help curvature_main_gui

% Last Modified by GUIDE v2.5 31-Jan-2020 13:50:40

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @curvature_main_gui_OpeningFcn, ...
                   'gui_OutputFcn',  @curvature_main_gui_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before curvature_main_gui is made visible.
function curvature_main_gui_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to curvature_main_gui (see VARARGIN)

% Choose default command line output for curvature_main_gui
handles.output = hObject;

%initializing the radio buttons

%intializing radio buttons
handles.CmeanYesNo=0;
handles.CGaussYesNo=0;
handles.CmaxYesNo=0;
handles.zScaleYes=0;
handles.zScaleNo=0;
handles.ClusterAnalysisYes=0;
handles.ClusterAnalysisNo=1;
handles.ScreenByCurvature=0;
handles.ScreenBySize=0;
handles.ScreenByIntensity=0;

%initializaing the thresholds
handles.MaxCurvature=1e6;
handles.MinCurvature=0;
handles.MaxIntensity=1e15;
handles.MinIntensity=0;
handles.MaxSize=1e9;
handles.MinSize=0;

%intializing smoothing factor
handles.MeshSmooth=1;

%intializing the color
handles.IsGreen=1;
handles.IsRed=0;

%handles to tell you if it is one or two channels
handles.ch1=0;
handles.ch2=0;

%handles for image registration of 2d curvature
handles.DeltaX2d=0;
handles.DeltaY2d=0;

%Initializing the surface areas of each channel
handles.SurfaceAreaCh1=0;
handles.SurfaceAreaCh2=0;

%Initializing the Surface Area of the Clusters
handles.SurfaceAreaClusterCh1=0;
handles.SurfaceAreaClusterCh2=0;

%Initializing the radio buttons for En's thresholding clusters by curvature
handles.CurveThreshCh1=0;
handles.ColocCurveWithCh1=0;
handles.CurveThreshCh2=0;
handles.ColocCurveWithCh2=0;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes curvature_main_gui wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = curvature_main_gui_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Button to get the initial boundary
[file_bd1g,path_bd1g,success]=uigetfile;
handles.filename_bd1g=file_bd1g;
handles.pathname_bd1g=path_bd1g;

%recording the channel
if success == 1
    handles.ch1=1;
end

%storing the handles
guidata(hObject, handles);

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%this is the go button

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%Condition for a single channel%%%%%%%%%%%%%%%%%%%%%%%%

%En's curvature map
ens_curve_map=[1.0000    0.0745    0.6510
    0.9966    0.0778    0.6522
    0.9932    0.0812    0.6535
    0.9898    0.0845    0.6548
    0.9864    0.0879    0.6560
    0.9830    0.0912    0.6573
    0.9796    0.0945    0.6585
    0.9762    0.0979    0.6598
    0.9728    0.1012    0.6611
    0.9694    0.1046    0.6623
    0.9660    0.1079    0.6636
    0.9627    0.1112    0.6648
    0.9593    0.1146    0.6661
    0.9559    0.1179    0.6673
    0.9525    0.1213    0.6686
    0.9491    0.1246    0.6699
    0.9457    0.1279    0.6711
    0.9423    0.1313    0.6724
    0.9389    0.1346    0.6736
    0.9355    0.1379    0.6749
    0.9321    0.1413    0.6762
    0.9287    0.1446    0.6774
    0.9253    0.1480    0.6787
    0.8837    0.1888    0.6941
    0.8422    0.2297    0.7095
    0.8006    0.2706    0.7249
    0.7590    0.3115    0.7403
    0.7174    0.3524    0.7558
    0.6759    0.3932    0.7712
    0.6343    0.4341    0.7866
    0.5927    0.4750    0.8020
    0.5511    0.5159    0.8174
    0.5096    0.5568    0.8328
    0.4680    0.5976    0.8483
    0.4264    0.6385    0.8637
    0.3848    0.6794    0.8791
    0.3433    0.7203    0.8945
    0.3017    0.7612    0.9099
    0.2601    0.8021    0.9253
    0.2186    0.8429    0.9408
    0.1770    0.8838    0.9562
    0.1718    0.8889    0.9581
    0.1667    0.8939    0.9600
    0.1616    0.8990    0.9619
    0.1564    0.9040    0.9638
    0.1513    0.9091    0.9657
    0.1462    0.9141    0.9676
    0.1410    0.9192    0.9695
    0.1359    0.9242    0.9714
    0.1307    0.9293    0.9733
    0.1256    0.9343    0.9752
    0.1205    0.9394    0.9771
    0.1153    0.9444    0.9790
    0.1102    0.9495    0.9809
    0.1051    0.9545    0.9829
    0.0999    0.9596    0.9848
    0.0948    0.9646    0.9867
    0.0896    0.9697    0.9886
    0.0845    0.9747    0.9905
    0.0794    0.9798    0.9924
    0.0742    0.9848    0.9943
    0.0691    0.9899    0.9962
    0.0640    0.9949    0.9981
    0.0588    1.0000    1.0000];

%making first element black
ens_curve_map_mask=[    0         0         0
    0.9966    0.0778    0.6523
    0.9936    0.0808    0.6534
    0.9907    0.0837    0.6545
    0.9877    0.0866    0.6556
    0.9847    0.0895    0.6567
    0.9817    0.0925    0.6578
    0.9788    0.0954    0.6589
    0.9758    0.0983    0.6600
    0.9728    0.1012    0.6611
    0.9699    0.1042    0.6622
    0.9669    0.1071    0.6633
    0.9639    0.1100    0.6644
    0.9610    0.1129    0.6655
    0.9580    0.1158    0.6666
    0.9550    0.1188    0.6677
    0.9520    0.1217    0.6688
    0.9491    0.1246    0.6699
    0.9461    0.1275    0.6710
    0.9431    0.1305    0.6721
    0.9402    0.1334    0.6732
    0.9372    0.1363    0.6743
    0.9342    0.1392    0.6754
    0.9312    0.1422    0.6765
    0.9283    0.1451    0.6776
    0.9253    0.1480    0.6787
    0.8813    0.1913    0.6950
    0.8373    0.2346    0.7113
    0.7932    0.2778    0.7277
    0.7492    0.3211    0.7440
    0.7052    0.3644    0.7603
    0.6612    0.4077    0.7766
    0.6172    0.4510    0.7930
    0.5732    0.4943    0.8093
    0.5291    0.5375    0.8256
    0.4851    0.5808    0.8419
    0.4411    0.6241    0.8583
    0.3971    0.6674    0.8746
    0.3531    0.7107    0.8909
    0.3091    0.7540    0.9072
    0.2650    0.7972    0.9236
    0.2210    0.8405    0.9399
    0.1770    0.8838    0.9562
    0.1714    0.8893    0.9583
    0.1657    0.8949    0.9604
    0.1601    0.9004    0.9625
    0.1545    0.9059    0.9645
    0.1489    0.9115    0.9666
    0.1432    0.9170    0.9687
    0.1376    0.9225    0.9708
    0.1320    0.9281    0.9729
    0.1263    0.9336    0.9750
    0.1207    0.9391    0.9771
    0.1151    0.9447    0.9791
    0.1095    0.9502    0.9812
    0.1038    0.9557    0.9833
    0.0982    0.9613    0.9854
    0.0926    0.9668    0.9875
    0.0869    0.9723    0.9896
    0.0813    0.9779    0.9917
    0.0757    0.9834    0.9937
    0.0701    0.9889    0.9958
    0.0644    0.9945    0.9979
    0.0588    1.0000    1.0000];

if (handles.ch1 == 1 && handles.ch2 == 0) || (handles.ch1 == 0 && handles.ch2 == 1)

    %figuring out the figure label
    if handles.ch1 == 1
        the_label='Ch1';
    else
        the_label='Ch2';
    end
    
    %getting the filenames
    if handles.ch1 == 1
        file_send_1=handles.filename_bd1g;
        path_send_1=handles.pathname_bd1g;
    else
        file_send_1=handles.filename_bd2g;
        path_send_1=handles.pathname_bd2g;
    end
    
    %doing some of the cluster calculations
    if handles.ClusterAnalysisYes == 1
        
        %cluster calculations
        [clust_raw_ret_1,clust_intens_arr_ret_1,clust_size_arr_ret_1]=cluster_calculations(path_send_1,file_send_1);
        
        %storing the results of calculation on clusters in handles
    
            handles.ClusterIntensity_1=clust_intens_arr_ret_1;
            handles.ClusterSize_1=clust_size_arr_ret_1;
            handles.RawClusterData_1=clust_raw_ret_1;
        
    end
    
    %figure out the color
    map_easy=colormap(jet);
    map_easy(1,:)=0;
    color_use=map_easy;
    
    %figuring out what to do here
    which_calc=0;
    if handles.CmeanYesNo==1
        which_calc=1;
    end
    if handles.CGaussYesNo==1
        which_calc=2;
    end
    if handles.CmaxYesNo==1
        which_calc=3;
    end
    
    %intializing smoothing factor
    smooth_send=handles.MeshSmooth;
    
    %clearing the figure
    axes(handles.axes1);
    cla reset;
    
    
    %this is the curvature calculation
    if handles.zScaleYes==1
        
        %scaling factor for LLS - z dimension
        scale_fac_send=1.75;
        
        %add cluster information to this
        if handles.ClusterAnalysisYes == 1
            
            %get the previous cluster calculations
            cluster_intensity_send=handles.ClusterIntensity_1;
            cluster_size_send=handles.ClusterSize_1;
            raw_cluster_send=handles.RawClusterData_1;
            
            %calculations
            [n_curve_1,f_curve_1,global_avg_ret,clust_curve_stats,n_cluster_1,n_cluster_size_1,n_cluster_intensity_1,node_intensity_ret_1,n_start,n_end]=the_curvature_function_zscaling_w_cluster_v2(path_send_1,file_send_1,smooth_send,which_calc,scale_fac_send,raw_cluster_send,cluster_size_send,cluster_intensity_send,color_use,the_label);
            
            %storing cluster statistics
            handles.cluster_curve_stats1=clust_curve_stats;
            
            %storing the information necessary to generate surface plots later
            handles.NodeCurvature_1=n_curve_1;
            handles.FaceCurvature_1=f_curve_1;
            handles.NodeCluster_1=n_cluster_1;
            handles.NodeClusterSize_1=n_cluster_size_1;
            handles.NodeClusterIntensity_1=n_cluster_intensity_1;
            handles.NodeIntensityData_1=node_intensity_ret_1;
            
            %storing the starting and ending indices
            handles.theStartNumber=n_start;
            handles.theEndNumber=n_end;
            
            %getting the surface area of the channel
            [tot_surface_area_Ch1]=calculate_surface_area_cell(n_curve_1,f_curve_1,scale_fac_send);
            handles.SurfaceAreaCh1=tot_surface_area_Ch1;
            
            %getting the surface area of the clusters
            handles.SurfaceAreaClusterCh1=calculate_surface_area_cluster(n_cluster_1,f_curve_1,scale_fac_send);

            
        else
            
            %calculations
            [n_curve_1,f_curve_1,global_avg_ret,node_intensity_ret_1,n_start,n_end]=the_curvature_function_zscaling(path_send_1,file_send_1,smooth_send,which_calc,scale_fac_send,color_use,the_label);
            
            %storing
            handles.NodeCurvature_1=n_curve_1;
            handles.FaceCurvature_1=f_curve_1;
            handles.NodeIntensityData_1=node_intensity_ret_1;
            
            %storing the starting and ending indices
            handles.theStartNumber=n_start;
            handles.theEndNumber=n_end;
            
            %getting the surface area of the channel
            [tot_surface_area_Ch1]=calculate_surface_area_cell(n_curve_1,f_curve_1,scale_fac_send);
            handles.SurfaceAreaCh1=tot_surface_area_Ch1;
            
        end
        
    else
        
        %scaling factor for LLS - z dimension
        scale_fac_send=1.00;
        
        %add cluster information to this
        if handles.ClusterAnalysisYes == 1
            
            %get the previous cluster calculations
            cluster_intensity_send=handles.ClusterIntensity_1;
            cluster_size_send=handles.ClusterSize_1;
            raw_cluster_send=handles.RawClusterData_1;
            
            %calculations
            [n_curve_1,f_curve_1,global_avg_ret,clust_curve_stats,n_cluster_1,n_cluster_size_1,n_cluster_intensity_1,node_intensity_ret_1,n_start,n_end]=the_curvature_function_zscaling_w_cluster_v2(path_send_1,file_send_1,smooth_send,which_calc,scale_fac_send,raw_cluster_send,cluster_size_send,cluster_intensity_send,color_use,the_label);
            
            %storing
            handles.cluster_curve_stats1=clust_curve_stats;
            
            %storing the information necessary to generate surface plots later
            handles.NodeCurvature_1=n_curve_1;
            handles.FaceCurvature_1=f_curve_1;
            handles.NodeCluster_1=n_cluster_1;
            handles.NodeClusterSize_1=n_cluster_size_1;
            handles.NodeClusterIntensity_1=n_cluster_intensity_1;
            handles.NodeIntensityData_1=node_intensity_ret_1;
            
            %storing the starting and ending indices
            handles.theStartNumber=n_start;
            handles.theEndNumber=n_end;
            
            %getting the surface area of the channel
            [tot_surface_area_Ch1]=calculate_surface_area_cell(n_curve_1,f_curve_1,scale_fac_send);
            handles.SurfaceAreaCh1=tot_surface_area_Ch1;
            
            %getting the surface area of the clusters
            handles.SurfaceAreaClusterCh1=calculate_surface_area_cluster(n_cluster_1,f_curve_1,scale_fac_send);
            
        else
            
            %calculations
            [n_curve_1,f_curve_1,global_avg_ret,node_intensity_ret_1,n_start,n_end]=the_curvature_function_zscaling(path_send_1,file_send_1,smooth_send,which_calc,scale_fac_send,color_use,the_label);
            
            %storing
            handles.NodeCurvature_1=n_curve_1;
            handles.FaceCurvature_1=f_curve_1;
            handles.NodeIntensityData_1=node_intensity_ret_1;
            
            %storing the starting and ending indices
            handles.theStartNumber=n_start;
            handles.theEndNumber=n_end;
            
            %getting the surface area of the channel
%             [tot_surface_area_Ch1]=calculate_surface_area_cell(n_curve_1,f_curve_1,scale_fac_send);
%             handles.SurfaceAreaCh1=tot_surface_area_Ch1;
            
        end
    end
    
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Conidition for 2 channel analysis%%%%%%%%%%%%%%%%%%%%%%
    
else
    
    %get the filenames
    file_send_1=handles.filename_bd1g;
    path_send_1=handles.pathname_bd1g;
    
    file_send_2=handles.filename_bd2g;
    path_send_2=handles.pathname_bd2g;
    
    %getting the cluster information if the person wants it
    %doing some of the cluster calculations
    if handles.ClusterAnalysisYes == 1
        
        %cluster calculations (Channel 1 and Channel 2)
        [clust_raw_ret_1,clust_intens_arr_ret_1,clust_size_arr_ret_1]=cluster_calculations(path_send_1,file_send_1);
        [clust_raw_ret_2,clust_intens_arr_ret_2,clust_size_arr_ret_2]=cluster_calculations(path_send_2,file_send_2);
        
        
        %storing the results of calculation on clusters in handles -
        %channel 1
        handles.ClusterIntensity_1=clust_intens_arr_ret_1;
        handles.ClusterSize_1=clust_size_arr_ret_1;
        handles.RawClusterData_1=clust_raw_ret_1;
        
        %storing the results of calculation on clusters in handles -
        %channel 2
        handles.ClusterIntensity_2=clust_intens_arr_ret_2;
        handles.ClusterSize_2=clust_size_arr_ret_2;
        handles.RawClusterData_2=clust_raw_ret_2;
        
    end
    
    %figure out the color
    map_easy=colormap(jet);
    map_easy(1,:)=0;
    color_use=map_easy;
    
    %figuring out what to do here
    which_calc=0;
    if handles.CmeanYesNo==1
        which_calc=1;
    end
    if handles.CGaussYesNo==1
        which_calc=2;
    end
    if handles.CmaxYesNo==1
        which_calc=3;
    end
    
    %intializing smoothing factor
    smooth_send=handles.MeshSmooth;
    
    %clearing the figure
    axes(handles.axes1);
    cla reset;
    
    %this is the curvature calculation
    if handles.zScaleYes==1
        
        %scaling factor for LLS - z dimension
        scale_fac_send=1.75;
        
        %add cluster information to this
        if handles.ClusterAnalysisYes == 1
            
            %get the previous cluster calculations - channel 1
            cluster_intensity_send_1=handles.ClusterIntensity_1;
            cluster_size_send_1=handles.ClusterSize_1;
            raw_cluster_send_1=handles.RawClusterData_1;
            
            %get the previous cluster calculations - channel 2
            cluster_intensity_send_2=handles.ClusterIntensity_2;
            cluster_size_send_2=handles.ClusterSize_2;
            raw_cluster_send_2=handles.RawClusterData_2;
            
            %calculations - channel 1
            [n_curve_1,f_curve_1,global_avg_ret_1,clust_curve_stats_1,n_cluster_1,n_cluster_size_1,n_cluster_intensity_1,node_intensity_ret_1,n_start,n_end]=the_curvature_function_zscaling_w_cluster_v2(path_send_1,file_send_1,smooth_send,which_calc,scale_fac_send,raw_cluster_send_1,cluster_size_send_1,cluster_intensity_send_1,color_use,'Ch1');
            
            %calculations - channel 2
            [n_curve_2,f_curve_2,global_avg_ret_2,clust_curve_stats_2,n_cluster_2,n_cluster_size_2,n_cluster_intensity_2,node_intensity_ret_2,n_start,n_end]=the_curvature_function_zscaling_w_cluster_v2(path_send_2,file_send_2,smooth_send,which_calc,scale_fac_send,raw_cluster_send_2,cluster_size_send_2,cluster_intensity_send_2,color_use,'Ch2');
            
            %storing cluster statistics
            handles.cluster_curve_stats1=clust_curve_stats_1;
            handles.cluster_curve_stats2=clust_curve_stats_2;
            
            %storing the information necessary to generate surface plots later
            %channel 1
            handles.NodeCurvature_1=n_curve_1;
            handles.FaceCurvature_1=f_curve_1;
            handles.NodeCluster_1=n_cluster_1;
            handles.NodeClusterSize_1=n_cluster_size_1;
            handles.NodeClusterIntensity_1=n_cluster_intensity_1;
            handles.NodeIntensityData_1=node_intensity_ret_1;
            
            %storing the information necessary to generate surface plots later
            %channel 2
            handles.NodeCurvature_2=n_curve_2;
            handles.FaceCurvature_2=f_curve_2;
            handles.NodeCluster_2=n_cluster_2;
            handles.NodeClusterSize_2=n_cluster_size_2;
            handles.NodeClusterIntensity_2=n_cluster_intensity_2;
            handles.NodeIntensityData_2=node_intensity_ret_2;
            
            %getting the surface area of the channel 1
            [tot_surface_area_Ch1]=calculate_surface_area_cell(n_curve_1,f_curve_1,scale_fac_send);
            handles.SurfaceAreaCh1=tot_surface_area_Ch1;
            
            %getting the surface area of the channel 1
            [tot_surface_area_Ch2]=calculate_surface_area_cell(n_curve_2,f_curve_2,scale_fac_send);
            handles.SurfaceAreaCh2=tot_surface_area_Ch2;
            
            %getting the surface area of the clusters - Channel 1
            handles.SurfaceAreaClusterCh1=calculate_surface_area_cluster(n_cluster_1,f_curve_1,scale_fac_send);
            
            %getting the surface area of the clusters - Channel 2
            handles.SurfaceAreaClusterCh2=calculate_surface_area_cluster(n_cluster_2,f_curve_2,scale_fac_send);
            
            %storing the starting and ending indices
            handles.theStartNumber=n_start;
            handles.theEndNumber=n_end;
            
            %doing some masking of the curvature ch1 curvature, ch2
            %clusters
            [node_mask_cluster_2,node_mask_cluster_2_rev]=mask_cluster_w_curvature_v3(n_curve_1,n_cluster_2);
            draw_curve_hist(node_mask_cluster_2,node_mask_cluster_2_rev,'Ch1 Curvature in Ch2 Clusters');
             
            
            %doing some masking of the curvature ch2 curvature, ch2
            %clusters
            [node_mask_cluster_2a,node_mask_cluster_2_reva]=mask_cluster_w_curvature_v2(n_curve_2,n_cluster_2);
            draw_curve_hist(node_mask_cluster_2a,node_mask_cluster_2_reva,'Ch2 Curvature in Ch2 Clusters');
            
            %some figures
            figure, hold on;
            
            subplot(2,4,1);
            plotmesh(n_curve_1,f_curve_1); shading interp; title('Ch1 - Curvature'); caxis([-0.5,0.5]);
            colormap(ens_curve_map); freezeColors; 
            
            subplot(2,4,2);
            plotmesh(n_cluster_2,f_curve_2);  title('Ch 2 - Cluster #'); caxis([0,max(n_cluster_2(:,4))]);shading interp;
            colormap(map_easy); freezeColors; 
            
            subplot(2,4,3);
            plotmesh(node_mask_cluster_2,f_curve_2); shading interp; title('Ch1 - Curv, Ch2 Clusters'); caxis([-0.6,0.5]);
            colormap(ens_curve_map_mask); freezeColors; 
            
            subplot(2,4,4);
            plotmesh(node_mask_cluster_2_rev,f_curve_2); shading interp; title('Rev. Ch1 - Curv, Ch2 Clusters'); caxis([-0.6,0.5]);
            colormap(ens_curve_map_mask); freezeColors; 
            
            
            subplot(2,4,5);
            plotmesh(n_curve_2,f_curve_2);  title('Ch 2 - Curvature'); caxis([-0.5,0.5]);shading interp;
            colormap(ens_curve_map); freezeColors; 
            
            subplot(2,4,6);
            plotmesh(n_cluster_2,f_curve_2);  title('Ch 2 - Cluster #'); caxis([0,max(n_cluster_2(:,4))]);shading interp;
            colormap(map_easy); freezeColors; 
            
            subplot(2,4,7);
            plotmesh(node_mask_cluster_2a,f_curve_2); shading interp; title('Ch2 - Curv, Ch2 Clusters'); caxis([-0.6,0.5]);
            colormap(ens_curve_map_mask); freezeColors; 
            
            subplot(2,4,8);
            plotmesh(node_mask_cluster_2_reva,f_curve_2); shading interp; title(' Rev. Ch2 - Curv, Ch2 Clusters'); caxis([-0.6,0.5]);
            colormap(ens_curve_map_mask); freezeColors; 
            
            
            
            
            figure, plotmesh(node_intensity_ret_1,f_curve_1);  title('Ch 1 - Intensity'); caxis([0,max(node_intensity_ret_1(:,4))]);shading interp;
            colormap(gray); colorbar;%freezeColors
            
            figure, plotmesh(node_intensity_ret_2,f_curve_2);  title('Ch 2 - Intensity'); caxis([0,max(node_intensity_ret_2(:,4))]);shading interp;
            colormap(gray); colorbar;%freezeColors
            
        else
            
            %calculations - channel 1
            [n_curve_1,f_curve_1,global_avg_ret_1,node_intensity_ret_1,n_start,n_end]=the_curvature_function_zscaling(path_send_1,file_send_1,smooth_send,which_calc,scale_fac_send,color_use,'Ch1');
            
            %calculations - channel 2
            [n_curve_2,f_curve_2,global_avg_ret_2,node_intensity_ret_2,n_start,n_end]=the_curvature_function_zscaling(path_send_2,file_send_2,smooth_send,which_calc,scale_fac_send,color_use,'Ch2');

            
            %storing - channel 1
            handles.NodeCurvature_1=n_curve_1;
            handles.FaceCurvature_1=f_curve_1;
            handles.NodeIntensityData_1=node_intensity_ret_1;
            
            %storing - channel 2
            handles.NodeCurvature_2=n_curve_2;
            handles.FaceCurvature_2=f_curve_2;
            handles.NodeIntensityData_2=node_intensity_ret_2;
            
            %storing the starting and ending indices
            handles.theStartNumber=n_start;
            handles.theEndNumber=n_end;
            
             %getting the surface area of the channel 1
            [tot_surface_area_Ch1]=calculate_surface_area_cell(n_curve_1,f_curve_1,scale_fac_send);
            handles.SurfaceAreaCh1=tot_surface_area_Ch1;
            
            %getting the surface area of the channel 1
            [tot_surface_area_Ch2]=calculate_surface_area_cell(n_curve_2,f_curve_2,scale_fac_send);
            handles.SurfaceAreaCh2=tot_surface_area_Ch2;
            
            %some figures
            figure, hold on;
            
            subplot(2,2,1);
            plotmesh(n_curve_1,f_curve_1);colormap(ens_curve_map);  shading interp; title('Ch1 - Curvature'); caxis([-0.5,0.5]); freezeColors;
            
            subplot(2,2,2);
            plotmesh(node_intensity_ret_2,f_curve_2);  title('Ch 2 - Intensity'); caxis([0,max(node_intensity_ret_2(:,4))]);shading interp;
            colormap(map_easy); colorbar; %freezeColors;
            
            subplot(2,2,3);
            plotmesh(n_curve_2,f_curve_2);  title('Ch 2 - Curvature'); caxis([-0.5,0.5]);shading interp;
            colormap(ens_curve_map);  freezeColors;
            
            subplot(2,2,4);
            plotmesh(node_intensity_ret_1,f_curve_1);  title('Ch 1 - Intensity'); caxis([0,max(node_intensity_ret_1(:,4))]);shading interp;
            colormap(map_easy); colorbar;  %freezeColors;
            
            
        end
        
    else
        
        %scaling factor for LLS - z dimension
        scale_fac_send=1.00;
        
        %add cluster information to this
        if handles.ClusterAnalysisYes == 1
            
            %get the previous cluster calculations - channel 1
            cluster_intensity_send_1=handles.ClusterIntensity_1;
            cluster_size_send_1=handles.ClusterSize_1;
            raw_cluster_send_1=handles.RawClusterData_1;
            
            %get the previous cluster calculations - channel 2
            cluster_intensity_send_2=handles.ClusterIntensity_2;
            cluster_size_send_2=handles.ClusterSize_2;
            raw_cluster_send_2=handles.RawClusterData_2;
            
            %calculations - channel 1
            [n_curve_1,f_curve_1,global_avg_ret_1,clust_curve_stats_1,n_cluster_1,n_cluster_size_1,n_cluster_intensity_1,node_intensity_ret_1,n_start,n_end]=the_curvature_function_zscaling_w_cluster_v2(path_send_1,file_send_1,smooth_send,which_calc,scale_fac_send,raw_cluster_send_1,cluster_size_send_1,cluster_intensity_send_1,color_use,'Ch1');
            
            %calculations - channel 2
            [n_curve_2,f_curve_2,global_avg_ret_2,clust_curve_stats_2,n_cluster_2,n_cluster_size_2,n_cluster_intensity_2,node_intensity_ret_2,n_start,n_end]=the_curvature_function_zscaling_w_cluster_v2(path_send_2,file_send_2,smooth_send,which_calc,scale_fac_send,raw_cluster_send_2,cluster_size_send_2,cluster_intensity_send_2,color_use,'Ch2');
            
            %storing cluster statistics
            handles.cluster_curve_stats1=clust_curve_stats_1;
            handles.cluster_curve_stats2=clust_curve_stats_2;
            
            %storing the information necessary to generate surface plots later
            %channel 1
            handles.NodeCurvature_1=n_curve_1;
            handles.FaceCurvature_1=f_curve_1;
            handles.NodeCluster_1=n_cluster_1;
            handles.NodeClusterSize_1=n_cluster_size_1;
            handles.NodeClusterIntensity_1=n_cluster_intensity_1;
            handles.NodeIntensityData_1=node_intensity_ret_1;
            
            %storing the information necessary to generate surface plots later
            %channel 2
            handles.NodeCurvature_2=n_curve_2;
            handles.FaceCurvature_2=f_curve_2;
            handles.NodeCluster_2=n_cluster_2;
            handles.NodeClusterSize_2=n_cluster_size_2;
            handles.NodeClusterIntensity_2=n_cluster_intensity_2;
            handles.NodeIntensityData_2=node_intensity_ret_2;
            
             %getting the surface area of the channel 1
            [tot_surface_area_Ch1]=calculate_surface_area_cell(n_curve_1,f_curve_1,scale_fac_send);
            handles.SurfaceAreaCh1=tot_surface_area_Ch1;
            
            %getting the surface area of the channel 1
            [tot_surface_area_Ch2]=calculate_surface_area_cell(n_curve_2,f_curve_2,scale_fac_send);
            handles.SurfaceAreaCh2=tot_surface_area_Ch2;
            
            %getting the surface area of the clusters - Channel 1
            handles.SurfaceAreaClusterCh1=calculate_surface_area_cluster(n_cluster_1,f_curve_1,scale_fac_send);
            
            %getting the surface area of the clusters - Channel 2
            handles.SurfaceAreaClusterCh2=calculate_surface_area_cluster(n_cluster_2,f_curve_2,scale_fac_send);
            
            %storing the starting and ending indices
            handles.theStartNumber=n_start;
            handles.theEndNumber=n_end;
            
            %doing some masking of the curvature
            [node_mask_cluster_2,node_mask_cluster_2_rev]=mask_cluster_w_curvature(n_curve_1,n_cluster_2);
            draw_curve_hist(node_mask_cluster_2,node_mask_cluster_2_rev,'Ch1 Curvature Ch2 Clusters');
            [node_mask_cluster_2a,node_mask_cluster_2_reva]=mask_cluster_w_curvature_v2(n_curve_2,n_cluster_2);
            draw_curve_hist(node_mask_cluster_2a,node_mask_cluster_2_reva,'Ch2 Curvature Ch2 Clusters');
            %some figures
            figure, hold on;
            
            subplot(2,4,1);
            plotmesh(n_curve_1,f_curve_1); shading interp; title('Ch1 - Curvature'); caxis([-0.5,0.5]);
            colormap(ens_curve_map); freezeColors; 
            
            subplot(2,4,2);
            plotmesh(n_cluster_2,f_curve_2);  title('Ch 2 - Cluster #'); caxis([0,max(n_cluster_2(:,4))]);shading interp;
            colormap(map_easy); freezeColors
            
            subplot(2,4,3);
            plotmesh(node_mask_cluster_2,f_curve_1); shading interp; title('Ch1 - Curv, Ch2 Clusters'); caxis([-0.6,0.5]);
            colormap(ens_curve_map_mask); freezeColors; 
            
            subplot(2,4,4);
            plotmesh(node_mask_cluster_2_rev,f_curve_1); shading interp; title('Rev. Ch1 - Curv, Ch2 Clusters'); caxis([-0.6,0.5]);
            colormap(ens_curve_map_mask); freezeColors; 
            
            
            subplot(2,4,5);
            plotmesh(n_curve_2,f_curve_2);  title('Ch 2 - Curvature'); caxis([-0.5,0.5]);shading interp;
            colormap(ens_curve_map); freezeColors; 
            
            subplot(2,4,6);
            plotmesh(n_cluster_2,f_curve_2);  title('Ch 2 - Cluster #'); caxis([0,max(n_cluster_2(:,4))]);shading interp;
            colormap(map_easy); freezeColors
            
            subplot(2,4,7);
            plotmesh(node_mask_cluster_2a,f_curve_2); shading interp; title('Ch2 - Curv, Ch2 Clusters'); caxis([-0.6,0.5]);
            colormap(ens_curve_map_mask); freezeColors; 
            
            subplot(2,4,8);
            plotmesh(node_mask_cluster_2_reva,f_curve_2); shading interp; title(' Rev. Ch2 - Curv, Ch2 Clusters'); caxis([-0.6,0.5]);
            colormap(ens_curve_map_mask); freezeColors; 
            
            
            
            
            figure, plotmesh(node_intensity_ret_1,f_curve_1);  title('Ch 1 - Intensity'); caxis([0,max(node_intensity_ret_1(:,4))]);shading interp;
            colormap(gray); colorbar;%freezeColors
            
            figure, plotmesh(node_intensity_ret_2,f_curve_2);  title('Ch 2 - Intensity'); caxis([0,max(node_intensity_ret_2(:,4))]);shading interp;
            colormap(gray); colorbar;%freezeColors
            
        else
            
            %calculations - channel 1
            [n_curve_1,f_curve_1,global_avg_ret,node_intensity_ret_1,n_start,n_end]=the_curvature_function_zscaling(path_send_1,file_send_1,smooth_send,which_calc,scale_fac_send,color_use,'Ch1');
            
            %calculations - channel 2
            [n_curve_2,f_curve_2,global_avg_ret,node_intensity_ret_2,n_start,n_end]=the_curvature_function_zscaling(path_send_2,file_send_2,smooth_send,which_calc,scale_fac_send,color_use,'Ch2');
            
            
            %storing - channel 1
            handles.NodeCurvature_1=n_curve_1;
            handles.FaceCurvature_1=f_curve_1;
            handles.NodeIntensityData_1=node_intensity_ret_1;
            
            %storing - channel 2
            handles.NodeCurvature_2=n_curve_2;
            handles.FaceCurvature_2=f_curve_2;
            handles.NodeIntensityData_2=node_intensity_ret_2;
            
             %getting the surface area of the channel 1
            [tot_surface_area_Ch1]=calculate_surface_area_cell(n_curve_1,f_curve_1,scale_fac_send);
            handles.SurfaceAreaCh1=tot_surface_area_Ch1;
            
            %getting the surface area of the channel 1
            [tot_surface_area_Ch2]=calculate_surface_area_cell(n_curve_2,f_curve_2,scale_fac_send);
            handles.SurfaceAreaCh2=tot_surface_area_Ch2;
            
            %storing the starting and ending indices
            handles.theStartNumber=n_start;
            handles.theEndNumber=n_end;
            
            %some figures
            figure, hold on;
            
            subplot(2,2,1);
            plotmesh(n_curve_1,f_curve_1); shading interp; title('Ch1 - Curvature'); caxis([-0.5,0.5]);
            colormap(ens_curve_map);freezeColors;
            
            subplot(2,2,2);
            plotmesh(node_intensity_ret_2,f_curve_2);  title('Ch 2 - Intensity'); caxis([0,max(node_intensity_ret_2(:,4))]);shading interp;
            colormap(map_easy); colorbar;%freezeColors;
            
            subplot(2,2,3);
            plotmesh(n_curve_2,f_curve_2);  title('Ch 2 - Curvature'); caxis([-0.5,0.5]);shading interp;
            colormap(ens_curve_map); freezeColors;
            
            subplot(2,2,4);
            plotmesh(node_intensity_ret_1,f_curve_1);  title('Ch 1 - Intensity'); caxis([0,max(node_intensity_ret_1(:,4))]);shading interp;
            colormap(map_easy); colorbar;%freezeColors;
            
        end
    end
    
    


end

%left panel
axes(handles.axes1);freezeColors;
plotmesh(n_curve_1,f_curve_1); colormap(ens_curve_map); shading interp; colorbar;   caxis([-0.5,0.5]); 

%at the end of the run, the filenames will appear
% text26 - ch1
% text28 - ch2

if (handles.ch1 == 1 && handles.ch2 == 0) || (handles.ch1 == 0 && handles.ch2 == 1)

    %getting the filenames
    if handles.ch1 == 1
        path_send_1a=handles.pathname_bd1g;
    else
        path_send_1a=handles.pathname_bd2g;
    end
    
    %making the string to display
    idx1a=find(path_send_1a == '\');
    path_post1_tmp=path_send_1a(idx1a(numel(idx1a)-4):idx1a(numel(idx1a)));
    set(handles.text26, 'String', path_post1_tmp);
    
elseif (handles.ch1 == 1 && handles.ch2 == 1) 
    
        %Channel 1
        path_send_1a=handles.pathname_bd1g;

         %Channel 2
        path_send_2a=handles.pathname_bd2g;
        
        %making the string to display - Channel 1
        idx1a=find(path_send_1a == '\');
        path_post1_tmp=path_send_1a(idx1a(numel(idx1a)-4):idx1a(numel(idx1a)));
        set(handles.text26, 'String', path_post1_tmp);
        
        %making the string to display - Channel 2
        idx2a=find(path_send_2a == '\');
        path_post2_tmp=path_send_2a(idx2a(numel(idx2a)-4):idx2a(numel(idx2a)));
        set(handles.text28, 'String', path_post2_tmp);
        
        
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%Making Surface Area to GUI%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%single channel
if (handles.ch1 == 1 && handles.ch2 == 0) || (handles.ch1 == 0 && handles.ch2 == 1)

    %total surface area
    tot_aurface_area_dis_ch1=handles.SurfaceAreaCh1;
        
    %adding to GUI
    if handles.ch1 == 1
        set(handles.text35, 'String', num2str(tot_aurface_area_dis_ch1));
    else
        set(handles.text36, 'String', num2str(tot_aurface_area_dis_ch1));
    end
    
    %add cluster analysis?
    if handles.ClusterAnalysisYes == 1
        
        %surface area of clusters
        ch1_cluster_sa_arr=handles.SurfaceAreaClusterCh1;
        
        %adding to GUI
        if handles.ch1 == 1
            set(handles.text39, 'String', num2str(sum(ch1_cluster_sa_arr(:,2))));
        else
            set(handles.text40, 'String', num2str(sum(ch1_cluster_sa_arr(:,2))));
        end
        
    end

%two channel
else
    
    %total surface area
    tot_aurface_area_dis_ch1=handles.SurfaceAreaCh1;
    tot_aurface_area_dis_ch2=handles.SurfaceAreaCh2;
    
    %Adding to GUI
    set(handles.text35, 'String', num2str(tot_aurface_area_dis_ch1));
    set(handles.text36, 'String', num2str(tot_aurface_area_dis_ch2));
   
    
    %add cluster analysis?
    if handles.ClusterAnalysisYes == 1
        
         %surface area of clusters
         ch1_cluster_sa_arr=handles.SurfaceAreaClusterCh1;
         ch2_cluster_sa_arr=handles.SurfaceAreaClusterCh2;
         
         %making a histogram
         nbins_now=linspace(0,2,20);
         [y1a,x1a]=hist(ch1_cluster_sa_arr(:,2),nbins_now);
         [y2a,x2a]=hist(ch2_cluster_sa_arr(:,2),nbins_now);
         figure, hold on; title('Histograms of Cluster Surface Area');
         plot(x1a,y1a,'g','LineWidth',1.5);
         plot(x2a,y2a,'r','LineWidth',1.5);
         legend('Ch1','Ch2'); xlabel('Surface Area (um^2)'); ylabel('#');
        
        %Add to GUI
        set(handles.text39, 'String', num2str(sum(ch1_cluster_sa_arr(:,2))));
        set(handles.text40, 'String', num2str(sum(ch2_cluster_sa_arr(:,2))));
        
    end
    
end

ch1_cluster_sa_arr=handles.SurfaceAreaClusterCh1
ch2_cluster_sa_arr=handles.SurfaceAreaClusterCh2

%save('Nodes_cluster_for_villi.mat','n_cluster_1')

%storing the handles
guidata(hObject, handles);





% --- Executes on button press in radiobutton1.
function radiobutton1_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton1

%Cmean radio button
handles.CmeanYesNo=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

% --- Executes on button press in radiobutton2.
function radiobutton2_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton2

%This is the gaussian curvature radio button
handles.CGaussYesNo=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

% --- Executes on button press in radiobutton3.
function radiobutton3_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton3
 
%This is the curvature max button
handles.CmaxYesNo=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


function edit1_Callback(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit1 as text
%        str2double(get(hObject,'String')) returns contents of edit1 as a double

%smoothing factor for generating the surface
handles.MeshSmooth=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in radiobutton4.
function radiobutton4_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the "yes" button for LLS z scaling
handles.zScaleYes=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


% Hint: get(hObject,'Value') returns toggle state of radiobutton4


% --- Executes on button press in radiobutton5.
function radiobutton5_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the "no" button for LLS z scaling
handles.zScaleNo=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

% Hint: get(hObject,'Value') returns toggle state of radiobutton5


% --- Executes on button press in radiobutton6.
function radiobutton6_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton6


%This is the "yes" button for adding cluster analysis
handles.ClusterAnalysisYes=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in radiobutton7.
function radiobutton7_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of radiobutton7

%This is the "no" button for adding cluster analysis
handles.ClusterAnalysisNo=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in pushbutton6.



% --- Executes on button press in pushbutton3.
function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button to save clustering and curvature data to an excel file

if (handles.ch1 == 1 && handles.ch2 == 0) || (handles.ch1 == 0 && handles.ch2 == 1)

    
    %getting the matrix to save
    matrrix_to_save_tmp=handles.cluster_curve_stats1;
    
    %surface area of clusters in um
    surface_area_clusters_ch1=handles.SurfaceAreaClusterCh1;
    countA=1;
    
    for r=min(surface_area_clusters_ch1(:,1)):max(surface_area_clusters_ch1(:,1))
        idxA=find(surface_area_clusters_ch1(:,1)==r);
        if numel(idxA)>0
           idxB=find(matrrix_to_save_tmp(:,1)==r);
           if numel(idxB)>0
               matrrix_to_save(countA,1)=r;
               matrrix_to_save(countA,2)=surface_area_clusters_ch1(idxA(1),2);
               matrrix_to_save(countA,3)=matrrix_to_save_tmp(idxB(1),3);
               matrrix_to_save(countA,4)=matrrix_to_save_tmp(idxB(1),4);
               matrrix_to_save(countA,5)=matrrix_to_save_tmp(idxB(1),5);
               countA=countA+1;
           end
           clear idxB;
        end
        clear idxA;
    end
    
    %getting the location and filename to save file
    [file_save_tmp,path_save]=uiputfile;
    
    %edit the filename
    idx_save=find(file_save_tmp=='.');
    file_save=strcat(path_save,file_save_tmp(1:idx_save(1)),'xlsx');
    
    %saving data to excel file
    save_data_to_excel(matrrix_to_save,file_save);
    
else
    
    %getting the matrix to save - channel 1
    matrrix_to_save1_tmp=handles.cluster_curve_stats1;
    
    %getting the matrix to save - channel 2
    matrrix_to_save2_tmp=handles.cluster_curve_stats2;
    
    %getting the surface area of clusters in um2
    surface_area_clusters_ch1=handles.SurfaceAreaClusterCh1;
    surface_area_clusters_ch2=handles.SurfaceAreaClusterCh2;
    
    %channel 1
    countA=1;
    for r=min(surface_area_clusters_ch1(:,1)):max(surface_area_clusters_ch1(:,1))
        idxA=find(surface_area_clusters_ch1(:,1)==r);
        if numel(idxA)>0
            idxB=find(matrrix_to_save1_tmp(:,1)==r);
            if numel(idxB)>0
                matrrix_to_save1(countA,1)=r;
                matrrix_to_save1(countA,2)=surface_area_clusters_ch1(idxA(1),2);
                matrrix_to_save1(countA,3)=matrrix_to_save1_tmp(idxB(1),3);
                matrrix_to_save1(countA,4)=matrrix_to_save1_tmp(idxB(1),4);
                matrrix_to_save1(countA,5)=matrrix_to_save1_tmp(idxB(1),5);
                countA=countA+1;
            end
            clear idxB;
        end
        clear idxA;
    end
    
    %channel 2
    countA=1;
    for r=min(surface_area_clusters_ch2(:,1)):max(surface_area_clusters_ch2(:,1))
        idxA=find(surface_area_clusters_ch2(:,1)==r);
        if numel(idxA)>0
            idxB=find(matrrix_to_save2_tmp(:,1)==r);
            if numel(idxB)>0
                matrrix_to_save2(countA,1)=r;
                matrrix_to_save2(countA,2)=surface_area_clusters_ch2(idxA(1),2);
                matrrix_to_save2(countA,3)=matrrix_to_save2_tmp(idxB(1),3);
                matrrix_to_save2(countA,4)=matrrix_to_save2_tmp(idxB(1),4);
                matrrix_to_save2(countA,5)=matrrix_to_save2_tmp(idxB(1),5);
                countA=countA+1;
            end
            clear idxB;
        end
        clear idxA;
    end
    
    %getting the location and filename to save file
    [file_save_tmp,path_save]=uiputfile;
    
    %edit the filename
    idx_save=find(file_save_tmp=='.');
    file_save=strcat(path_save,file_save_tmp(1:idx_save(1)),'xlsx');
    
    %saving data to excel file
    save_data_to_excel_two_channel(matrrix_to_save1,matrrix_to_save2,file_save);
    
    
end








% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button to save only the x, y, and z coordinates of nodes and
%corresponding curvature

%getting the scaling factor
if handles.zScaleYes==1
    scale_corr=1.75;
else
    scale_corr=1;
end
scale_corr=double(scale_corr);

%getting the starting and ending indices for the image stack
ns=handles.theStartNumber;
ne=handles.theEndNumber;
ns=double(ns);
ne=double(ne);

if (handles.ch1 == 1 && handles.ch2 == 0) || (handles.ch1 == 0 && handles.ch2 == 1)
    
    %get the matrix that I an interested in
    node_of_curvature_to_save=handles.NodeCurvature_1;

    %scaling
    node_of_curvature_to_save(:,3)=node_of_curvature_to_save(:,3)./scale_corr;
    node_of_curvature_to_save(:,3)=node_of_curvature_to_save(:,3)-1+ns;
    
    %getting the intensity data
    intens_excel_node=handles.NodeIntensityData_1;
    
    %adding a column of intensities to the matrix to be saved by excel
    node_of_curvature_to_save(:,5)=intens_excel_node(:,4);
    
    %asking the user to identify the file
    [file_tmp,path_save_tmp]=uiputfile;
    
    %edit the filename
    idx_save_new=find(file_tmp=='.');
    file_save_new=strcat(path_save_tmp,file_tmp(1:idx_save_new(1)),'xlsx');
    
    %saving to excel file
    save_coords_curvature_to_excel(node_of_curvature_to_save,file_save_new);
    
else
    
    %getting the intensity data
    intens_excel_node_1=handles.NodeIntensityData_1;
    intens_excel_node_2=handles.NodeIntensityData_2;
    
    %getting the matrices to save
    node_of_curvature_to_save_1=handles.NodeCurvature_1;
    node_of_curvature_to_save_2=handles.NodeCurvature_2;
    
    %scaling - Channel 1
    node_of_curvature_to_save_1(:,3)=node_of_curvature_to_save_1(:,3)./scale_corr;
    node_of_curvature_to_save_1(:,3)=node_of_curvature_to_save_1(:,3)-1+ns;
    
    %scaling - Channel 2
    node_of_curvature_to_save_2(:,3)=node_of_curvature_to_save_2(:,3)./scale_corr;
    node_of_curvature_to_save_2(:,3)=node_of_curvature_to_save_2(:,3)-1+ns;
    
    %adding the intensity to matrix to be saved - Channel 1
    node_of_curvature_to_save_1(:,5)=intens_excel_node_1(:,4);
    
    %adding the intensity to matrix to be saved - Channel 2
    node_of_curvature_to_save_2(:,5)=intens_excel_node_2(:,4);
    
    %asking the user to identify the file
    [file_tmp,path_save_tmp]=uiputfile;
    
    %edit the filename
    idx_save_new=find(file_tmp=='.');
    file_save_new2=strcat(path_save_tmp,file_tmp(1:idx_save_new(1)),'xlsx');
    
    %saving to excel
    save_coords_curvature_to_excel_two_channel(node_of_curvature_to_save_1,node_of_curvature_to_save_2,file_save_new2);
    
end


%storing the handles
guidata(hObject, handles);


% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%Button to get the initial boundary
[file_bd2g,path_bd2g,success]=uigetfile;
handles.filename_bd2g=file_bd2g;
handles.pathname_bd2g=path_bd2g;

%recording the channel
if success == 1
    handles.ch2=1;
end

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button to make to histograms of cluster occupancy

if (handles.ch1 == 1 && handles.ch2 == 0) || (handles.ch1 == 0 && handles.ch2 == 1)
    
        %making a copy of the surface information - Channel 1
        node_of_curvature_1=handles.NodeCurvature_1;
        face_of_curvature_1=handles.FaceCurvature_1;
        node_cl_sizes_1=handles.NodeClusterSize_1;
        node_cl_intensity_1=handles.NodeClusterIntensity_1;
        node_intensity_1=handles.NodeIntensityData_1;
        node_cl_numbers_1=handles.NodeCluster_1;
        
        %make_multi_level_histogram - channel 1
        make_multi_level_histogram(node_of_curvature_1,node_cl_numbers_1);

else
    
    %making a copy of the surface information - Channel 1
    node_of_curvature_1=handles.NodeCurvature_1;
    face_of_curvature_1=handles.FaceCurvature_1;
    node_cl_sizes_1=handles.NodeClusterSize_1;
    node_cl_intensity_1=handles.NodeClusterIntensity_1;
    node_intensity_1=handles.NodeIntensityData_1;
    node_cl_numbers_1=handles.NodeCluster_1;
    
    %making a copy of the surface information - Channel 2
    node_of_curvature_2=handles.NodeCurvature_2;
    face_of_curvature_2=handles.FaceCurvature_2;
    node_cl_sizes_2=handles.NodeClusterSize_2;
    node_cl_intensity_2=handles.NodeClusterIntensity_2;
    node_intensity_2=handles.NodeIntensityData_2;
    node_cl_numbers_2=handles.NodeCluster_2;
    
    %some debugging - taking over the surface
%     for t=1:numel(node_of_curvature_2(:,1))
%        
%         if node_of_curvature_2(t,1)>80 && node_of_curvature_2(t,1)<130 && node_of_curvature_2(t,2)>60 && node_of_curvature_2(t,2)<130 && node_of_curvature_2(t,3)>20 && node_of_curvature_2(t,3)<80
%             node_of_curvature_2(t,4)=-0.5;
%         end
%             
%     end
%     
%     node_of_curvature_1(:,4)=node_of_curvature_1(:,4)+0.2;
%     
%     %another colormap
%     map_easy=colormap(jet);
%     map_easy(1,:)=0;
% 
%     figure, hold on; plotmesh(node_cl_sizes_2,face_of_curvature_2); colormap(gca,map_easy); colorbar; shading interp; title('Clusters: Surface 2'); caxis([0,max(node_cl_sizes_1(:,4))]);
%     figure, hold on; plotmesh(node_of_curvature_1,face_of_curvature_1); colormap(gca,map_easy); colorbar; shading interp; title('Curvature: Surface 1'); caxis([-0.5,0.5]);
%     
%     figure, hold on; plotmesh(node_cl_sizes_1,face_of_curvature_1); colormap(gca,map_easy); colorbar; shading interp; title('Clusters: Surface 1'); caxis([0,max(node_cl_sizes_1(:,4))]);
%     figure, hold on; plotmesh(node_of_curvature_2,face_of_curvature_2); colormap(gca,map_easy); colorbar; shading interp; title('Curvature: Surface 2'); caxis([-0.5,0.5]);
%     
%     
    
    %make_multi_level_histogram - channel 1
    the_title_1='Curvature - Channel 1';
    make_multi_level_histogram_2ch(node_of_curvature_1,node_cl_numbers_1,the_title_1);
    
    %make_multi_level_histogram - channel 2
    the_title_2='Curvature - Channel 2';
    make_multi_level_histogram_2ch(node_of_curvature_2,node_cl_numbers_2,the_title_2);
    
    
    %making multi level histogram - channel 1 and 2
    %Cluster Channel = 1, Surface Channel = 2
    make_multi_level_histogram_2ch_v2(node_of_curvature_1,node_of_curvature_2,node_cl_numbers_2,'Curvature of Ch.2 Clusters in Ch1 relative to All Ch2 Curvature');
    
    %making multi level histogram - channel 2 and 1
    %Cluster Channel = 2, Surface Channel = 1
    make_multi_level_histogram_2ch_v2(node_of_curvature_2,node_of_curvature_1,node_cl_numbers_1,'Curvature of Ch.1 Clusters in Ch2 relative to All Ch1 Curvature');

    
end


% --- Executes on button press in pushbutton10.
function pushbutton10_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button to make scatter plots

if (handles.ch1 == 1 && handles.ch2 == 0) || (handles.ch1 == 0 && handles.ch2 == 1)
    
        
        %making a copy of the surface information - Channel 1
        node_of_curvature_1=handles.NodeCurvature_1;
        face_of_curvature_1=handles.FaceCurvature_1;
        node_cl_sizes_1=handles.NodeClusterSize_1;
        node_cl_intensity_1=handles.NodeClusterIntensity_1;
        node_intensity_1=handles.NodeIntensityData_1;
        node_cl_numbers_1=handles.NodeCluster_1;
        
        %cluster stats - channel 1
        clust_curve_stats_arr_1=handles.cluster_curve_stats1;
           

        
    
else
    
    %making a copy of the surface information - Channel 1
    node_of_curvature_1=handles.NodeCurvature_1;
    face_of_curvature_1=handles.FaceCurvature_1;
    node_cl_sizes_1=handles.NodeClusterSize_1;
    node_cl_intensity_1=handles.NodeClusterIntensity_1;
    node_intensity_1=handles.NodeIntensityData_1;
    node_cl_numbers_1=handles.NodeCluster_1;
    
    
    %making a copy of the surface information - Channel 2
    node_of_curvature_2=handles.NodeCurvature_2;
    face_of_curvature_2=handles.FaceCurvature_2;
    node_cl_sizes_2=handles.NodeClusterSize_2;
    node_cl_intensity_2=handles.NodeClusterIntensity_2;
    node_intensity_2=handles.NodeIntensityData_2;
    node_cl_numbers_2=handles.NodeCluster_2;
    
%     %some screening for debugging
%     for r=1:numel(node_of_curvature_1(:,4))
%         
%         if node_of_curvature_1(r,1)>110 && node_of_curvature_1(r,1)<130 && node_of_curvature_1(r,2)>60 && node_of_curvature_1(r,2)<95 && node_of_curvature_1(r,3)>20 && node_of_curvature_1(r,3)<80
%                node_of_curvature_1(r,4)=0.45;
%         end
%     end
%     
    %another colormap
    map_easy=colormap(jet);
    map_easy(1,:)=0;
    
    %some figures
    figure, hold on;
    colormap(gca,map_easy);
     plotmesh(node_cl_numbers_2,face_of_curvature_2); colorbar; shading interp; title('Ch1 - Clustering'); caxis([0 max(node_cl_numbers_2(:,4))]);
     figure, hold on;
    colormap(gca,map_easy);
    plotmesh(node_of_curvature_2,face_of_curvature_2); colorbar; shading interp; title('Ch2 - Curvature'); caxis([-0.5,0.5]);
    
    
    %cluster stats - channel 1
    clust_curve_stats_arr_1=handles.cluster_curve_stats1;
    
    %cluster stats - channel 2
    clust_curve_stats_arr_2=handles.cluster_curve_stats2;
    
    %make plots
    make_multi_para_scatter_plot_2_ch(node_of_curvature_1,node_cl_numbers_1,node_cl_sizes_1,node_of_curvature_2,node_cl_numbers_2,node_cl_sizes_2,clust_curve_stats_arr_1,clust_curve_stats_arr_2,1)
    make_multi_para_scatter_plot_2_ch(node_of_curvature_1,node_cl_numbers_1,node_cl_intensity_1,node_of_curvature_2,node_cl_numbers_2,node_cl_intensity_2,clust_curve_stats_arr_1,clust_curve_stats_arr_2,0)

    
end


% --- Executes on button press in pushbutton11.
function pushbutton11_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button to create the image stacks necessary to make 2d
%projections. This was requested by Casey

%figuring out the path
%asking the user to identify the file
[file_tmp,path_save_2d]=uiputfile;
idx_casey=find(file_tmp=='.');
file_save_2d=file_tmp(1:(idx_casey-1));
path_file_save_casey=strcat(path_save_2d,file_save_2d);

%getting the starting and ending indices for the image stack
ns1=handles.theStartNumber;
ne1=handles.theEndNumber;
ns1=double(ns1);
ne1=double(ne1);

%getting a test image
%paths
if handles.ch1 == 1
    file_send_1=handles.filename_bd1g;
    path_send_1=handles.pathname_bd1g;
else
    file_send_1=handles.filename_bd2g;
    path_send_1=handles.pathname_bd2g;
end

idx_test=find(path_send_1=='\');
path_test_image_tmp=path_send_1(1:(idx_test(numel(idx_test)-1)))
path_test_image=strcat(path_test_image_tmp,'ErodedBoundaryImages\MaskBoundErode');
i_size_send=imread(strcat(path_test_image,num2str(ns1),'.tif'));

%getting the scaling factor
if handles.zScaleYes==1
    scale_corr=1.75;
else
    scale_corr=1;
end
scale_corr=double(scale_corr);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Making Image Stacks from the Surface%%%%%%%%%%%%%%%%%%%%%

if (handles.ch1 == 1 && handles.ch2 == 0) || (handles.ch1 == 0 && handles.ch2 == 1)
    
    %get the matrix that I an interested in
    node_of_curvature_to_save_2d=handles.NodeCurvature_1;

    %scaling
    node_of_curvature_to_save_2d(:,3)=node_of_curvature_to_save_2d(:,3)./scale_corr;
   % node_of_curvature_to_save_2d(:,3)=node_of_curvature_to_save_2d(:,3);
    
    %getting the intensity data
    intens_excel_node_2d=handles.NodeIntensityData_1;
    
    %adding a column of intensities to the matrix to be saved by excel
    node_of_curvature_to_save_2d(:,5)=intens_excel_node_2d(:,4);

    %debugging
    %node_of_curvature_to_save_2d_sort=sortrows(node_of_curvature_to_save_2d,3);
    
    %making the image stacks
    if handles.ch1 == 1
        make_stacks_for_2d_proj_1chan(node_of_curvature_to_save_2d(:,2),node_of_curvature_to_save_2d(:,1),node_of_curvature_to_save_2d(:,3),node_of_curvature_to_save_2d(:,4),node_of_curvature_to_save_2d(:,5),ns1,ne1,i_size_send,1,path_file_save_casey);
    else
        make_stacks_for_2d_proj_1chan(node_of_curvature_to_save_2d(:,2),node_of_curvature_to_save_2d(:,1),node_of_curvature_to_save_2d(:,3),node_of_curvature_to_save_2d(:,4),node_of_curvature_to_save_2d(:,5),ns1,ne1,i_size_send,2,path_file_save_casey);
    end
    
else
    
    %getting the intensity data
    intens_excel_node_2d_1=handles.NodeIntensityData_1;
    intens_excel_node_2d_2=handles.NodeIntensityData_2;
    
    %getting the matrices to save
    node_of_curvature_to_save_2d_1=handles.NodeCurvature_1;
    node_of_curvature_to_save_2d_2=handles.NodeCurvature_2;
    
    %scaling - Channel 1
    node_of_curvature_to_save_2d_1(:,3)=node_of_curvature_to_save_2d_1(:,3)./scale_corr;
  %  node_of_curvature_to_save_2d_1(:,3)=node_of_curvature_to_save_2d_1(:,3);
    
    %scaling - Channel 2
    node_of_curvature_to_save_2d_2(:,3)=node_of_curvature_to_save_2d_2(:,3)./scale_corr;
   % node_of_curvature_to_save_2d_2(:,3)=node_of_curvature_to_save_2d_2(:,3);
    
    %adding the intensity to matrix to be saved - Channel 1
    node_of_curvature_to_save_2d_1(:,5)=intens_excel_node_2d_1(:,4);
    
    %adding the intensity to matrix to be saved - Channel 2
    node_of_curvature_to_save_2d_2(:,5)=intens_excel_node_2d_2(:,4);
    
    %making the image stacks
    make_stacks_for_2d_proj_2chan(node_of_curvature_to_save_2d_1(:,2),node_of_curvature_to_save_2d_1(:,1),node_of_curvature_to_save_2d_1(:,3),node_of_curvature_to_save_2d_1(:,4),node_of_curvature_to_save_2d_2(:,2),node_of_curvature_to_save_2d_2(:,1),node_of_curvature_to_save_2d_2(:,3),node_of_curvature_to_save_2d_2(:,4),node_of_curvature_to_save_2d_1(:,5),node_of_curvature_to_save_2d_2(:,5),ns1,ne1,i_size_send,path_file_save_casey);

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%Making the Image Stack from%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%the original images%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if (handles.ch1 == 1 && handles.ch2 == 0) || (handles.ch1 == 0 && handles.ch2 == 1)
    
    if handles.ch1 == 1
        
        %channel 1
        path_send_1a=handles.pathname_bd1g;
        
        idx_test1=find(path_send_1a=='\');
        path_test1_image_tmp=path_send_1a(1:(idx_test1(numel(idx_test1)-1)));
        path_test1_image=strcat(path_test1_image_tmp,'ErodedBoundaryImages\MaskBoundErode');

        %counter
        count_e=1;
        
        for r=ns1:ne1
            
            %reading in images
            im1=imread(strcat(path_test1_image,num2str(r),'.tif'));
            
            %pre-allocating for speed
            if count_e==1
                dim1=size(im1,1);
                dim2=size(im1,2);
                gr_er_stack=uint16(zeros(dim1,dim2,ne1-ns1+1));
                gr_er_mask_stack=uint16(zeros(dim1,dim2,ne1-ns1+1));
            end
            
            %making mask
            green_mask=uint16(zeros(dim1,dim2));
            idx_gr=find(im1>0);
            
            
            if numel(idx_gr)>0
                green_mask(idx_gr)=1;
            end
            
            
            %loading
            gr_er_stack(:,:,count_e)=uint16(im1);
            gr_er_mask_stack(:,:,count_e)=uint16(green_mask);
            
            %iterate counter
            count_e=count_e+1;
            
            %clear statements
            clear im1;clear green_mask;
            clear idx_gr;
            
        end
        
        %saving paths
        green1_int_name=strcat(path_file_save_casey,'_ch1_original_intensity_stack.tif');
        green1_mask_name=strcat(path_file_save_casey,'_ch1_original_mask_stack.tif');
        
        %saving
        write_file(green1_int_name,ne1-ns1+1,gr_er_stack);
        write_file(green1_mask_name,ne1-ns1+1,gr_er_mask_stack);
        
        
    else

        %channel 2
        path_send_2a=handles.pathname_bd2g;
        
        idx_test2=find(path_send_2a=='\');
        path_test2_image_tmp=path_send_2a(1:(idx_test2(numel(idx_test2)-1)));
        path_test2_image=strcat(path_test2_image_tmp,'ErodedBoundaryImages\MaskBoundErode');
        
        %counter
        count_e=1;
        
        for r=ns1:ne1
            
            %reading in images
            im2=imread(strcat(path_test2_image,num2str(r),'.tif'));
            
            %pre-allocating for speed
            if count_e==1
                dim1=size(im2,1);
                dim2=size(im2,2);
                red_er_stack=uint16(zeros(dim1,dim2,ne1-ns1+1));
                red_er_mask_stack=uint16(zeros(dim1,dim2,ne1-ns1+1));
            end
            
            %making mask
            red_mask=uint16(zeros(dim1,dim2));
            idx_red=find(im2>0);
            
            
            if numel(idx_red)>0
                red_mask(idx_red)=1;
            end
            
            %loading
            red_er_stack(:,:,count_e)=uint16(im2);
            red_er_mask_stack(:,:,count_e)=uint16(red_mask);
            
            %iterate counter
            count_e=count_e+1;
            
            %clear statements
            clear im1; clear im2; clear green_mask; clear red_mask;
            clear idx_gr; clear idx_red;
            
        end
        
        %saving paths
        red1_int_name=strcat(path_file_save_casey,'_ch2_original_intensity_stack.tif');
        red1_mask_name=strcat(path_file_save_casey,'_ch2_original_mask_stack.tif');
        
        %saving
        write_file(red1_int_name,ne1-ns1+1,red_er_stack)
        write_file(red1_mask_name,ne1-ns1+1,red_er_mask_stack);
        
    end
    
    
else
    
    %channel 1
    path_send_1a=handles.pathname_bd1g;
    
    idx_test1=find(path_send_1a=='\');
    path_test1_image_tmp=path_send_1a(1:(idx_test1(numel(idx_test1)-1)));
    path_test1_image=strcat(path_test1_image_tmp,'ErodedBoundaryImages\MaskBoundErode');
    
    %channel 2
    path_send_2a=handles.pathname_bd2g;
    
    idx_test2=find(path_send_2a=='\');
    path_test2_image_tmp=path_send_2a(1:(idx_test2(numel(idx_test2)-1)));
    path_test2_image=strcat(path_test2_image_tmp,'ErodedBoundaryImages\MaskBoundErode');
    
    %counter
    count_e=1;
    
    for r=ns1:ne1
        
        %reading in images
        im1=imread(strcat(path_test1_image,num2str(r),'.tif'));
        im2=imread(strcat(path_test2_image,num2str(r),'.tif'));
        
        %pre-allocating for speed
        if count_e==1
            dim1=size(im1,1);
            dim2=size(im1,2);
            gr_er_stack=uint16(zeros(dim1,dim2,ne1-ns1+1));
            red_er_stack=uint16(zeros(dim1,dim2,ne1-ns1+1));
            gr_er_mask_stack=uint16(zeros(dim1,dim2,ne1-ns1+1));
            red_er_mask_stack=uint16(zeros(dim1,dim2,ne1-ns1+1));
        end
        
        %making mask
        green_mask=uint16(zeros(dim1,dim2));
        red_mask=uint16(zeros(dim1,dim2));
        idx_gr=find(im1>0);
        idx_red=find(im2>0);
        
        if numel(idx_gr)>0
            green_mask(idx_gr)=1;
        end
        if numel(idx_red)>0
            red_mask(idx_red)=1;
        end
        
        %loading
        gr_er_stack(:,:,count_e)=uint16(im1);
        red_er_stack(:,:,count_e)=uint16(im2);
        gr_er_mask_stack(:,:,count_e)=uint16(green_mask);
        red_er_mask_stack(:,:,count_e)=uint16(red_mask);
        
        %iterate counter
        count_e=count_e+1;
        
        %clear statements
        clear im1; clear im2; clear green_mask; clear red_mask;
        clear idx_gr; clear idx_red;

    end
    
    %saving paths
    green1_int_name=strcat(path_file_save_casey,'_ch1_original_intensity_stack.tif');
    green1_mask_name=strcat(path_file_save_casey,'_ch1_original_mask_stack.tif');

    red1_int_name=strcat(path_file_save_casey,'_ch2_original_intensity_stack.tif');
    red1_mask_name=strcat(path_file_save_casey,'_ch2_original_mask_stack.tif');
    
    %saving
    write_file(green1_int_name,ne1-ns1+1,gr_er_stack);
    write_file(green1_mask_name,ne1-ns1+1,gr_er_mask_stack);
    
    write_file(red1_int_name,ne1-ns1+1,red_er_stack);
    write_file(red1_mask_name,ne1-ns1+1,red_er_mask_stack);
    
end

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in pushbutton12.
function pushbutton12_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button to get and display the intensity - only 2d projection

persistent lastPath path_int2d
% If this is the first time running the function this session,
% Initialize lastPath to 0
if isempty(lastPath) 
    lastPath = 0;
end
% First time calling 'uigetfile', use the pwd
if lastPath == 0
    [file_int2d, path_int2d] = uigetfile;
    
% All subsequent calls, use the path to the last selected file
else
    [file_int2d, path_int2d] = uigetfile(lastPath);
end
% Use the path to the last selected file
% If 'uigetfile' is called, but no item is selected, 'lastPath' is not overwritten with 0
if path_int2d ~= 0
    lastPath = path_int2d;
end

% [file_int2d,path_int2d,success]=uigetfile;

%read in the image
im_int_2d=imread(strcat(path_int2d,file_int2d));

%make figure
file_int2d_title=file_int2d;
title_idx=find(file_int2d_title=='_');
if numel(title_idx)>0
    file_int2d_title(title_idx)='-';
end



figure, imagesc(im_int_2d); colormap(gray); colorbar; title(strcat('Intensity2d',file_int2d_title));

%hang onto the image
handles.Intensity2d=im_int_2d;



%storing the handles
guidata(hObject, handles);


% --- Executes on button press in pushbutton16.
function pushbutton16_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button to make an overlay

%intensity image
int_im_now_tmp=handles.Intensity2d;

%curvature image
curve_im_now_tmp=handles.Curvature2d;

%cropping to same size => x
dim_int_x=size(int_im_now_tmp,1);
dim_cur_x=size(curve_im_now_tmp,1);
if dim_int_x>dim_cur_x
    dim_x=dim_cur_x;
else
    dim_x=dim_int_x;
end

%cropping to same size => y
dim_int_y=size(int_im_now_tmp,2);
dim_cur_y=size(curve_im_now_tmp,2);
if dim_int_y>dim_cur_y
    dim_y=dim_cur_y;
else
    dim_y=dim_int_y;
end

%cropping
int_im_now=imcrop(int_im_now_tmp,[1,1,dim_y-1,dim_x-1]);
int_im_now=double(int_im_now);
curve_im_now=imcrop(curve_im_now_tmp,[1,1,dim_y-1,dim_x-1]);
curve_im_now=double(curve_im_now);

%performing image registration - if so desired
dx=handles.DeltaX2d;
dy=handles.DeltaY2d;

control_x_tmp=uint16([dim_y.*0.25,dim_y.*0.5,dim_y.*0.75]);
control_y_tmp=uint16([dim_x.*0.25,dim_x.*0.75,dim_x.*0.750]);
control_x_tmp=double(control_x_tmp);
control_y_tmp=double(control_y_tmp);


if dx~=0 || dy~=0

    control_x_1=control_x_tmp';
    control_y_1=control_y_tmp';
    control_x_2=[control_x_tmp+dx]';
    control_y_2=[control_y_tmp+dy]';
    
    tform = cp2tform([control_x_2,control_y_2],[control_x_1,control_y_1],'affine');
    new_im=imtransform(int_im_now,tform,'xdata',[1,size(int_im_now,2)],'ydata',[1,size(int_im_now,1)]);
    
    %renaming
    clear int_im_now;
    int_im_now=new_im;

end

%Extrema for RGB rendering
min_cur=handles.MinCurvature2d;
max_cur=handles.MaxCurvature2d;
min_int=handles.MinIntensity2d;
max_int=handles.MaxIntensity2d;

%rgb rendering
[curve_im_rgb]=make_rgb_blank_2d_proj(curve_im_now,max_cur,min_cur,1);
[int_im_rgb]=make_rgb_blank_2d_proj(int_im_now,max_int,min_int,2);

%making overlay
overlay_2d_rgb(:,:,1)=int_im_rgb(:,:,1).*curve_im_rgb(:,:,1);
overlay_2d_rgb(:,:,2)=int_im_rgb(:,:,2).*curve_im_rgb(:,:,2);
overlay_2d_rgb(:,:,3)=int_im_rgb(:,:,3).*curve_im_rgb(:,:,3);

%making final output
figure, imshow([int_im_rgb;curve_im_rgb;overlay_2d_rgb]);



% --- Executes on button press in pushbutton13.
function pushbutton13_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button to get and display the curvature - only 2d projection

%En's curvature map
ens_curve_map=[1.0000    0.0745    0.6510
    0.9966    0.0778    0.6522
    0.9932    0.0812    0.6535
    0.9898    0.0845    0.6548
    0.9864    0.0879    0.6560
    0.9830    0.0912    0.6573
    0.9796    0.0945    0.6585
    0.9762    0.0979    0.6598
    0.9728    0.1012    0.6611
    0.9694    0.1046    0.6623
    0.9660    0.1079    0.6636
    0.9627    0.1112    0.6648
    0.9593    0.1146    0.6661
    0.9559    0.1179    0.6673
    0.9525    0.1213    0.6686
    0.9491    0.1246    0.6699
    0.9457    0.1279    0.6711
    0.9423    0.1313    0.6724
    0.9389    0.1346    0.6736
    0.9355    0.1379    0.6749
    0.9321    0.1413    0.6762
    0.9287    0.1446    0.6774
    0.9253    0.1480    0.6787
    0.8837    0.1888    0.6941
    0.8422    0.2297    0.7095
    0.8006    0.2706    0.7249
    0.7590    0.3115    0.7403
    0.7174    0.3524    0.7558
    0.6759    0.3932    0.7712
    0.6343    0.4341    0.7866
    0.5927    0.4750    0.8020
    0.5511    0.5159    0.8174
    0.5096    0.5568    0.8328
    0.4680    0.5976    0.8483
    0.4264    0.6385    0.8637
    0.3848    0.6794    0.8791
    0.3433    0.7203    0.8945
    0.3017    0.7612    0.9099
    0.2601    0.8021    0.9253
    0.2186    0.8429    0.9408
    0.1770    0.8838    0.9562
    0.1718    0.8889    0.9581
    0.1667    0.8939    0.9600
    0.1616    0.8990    0.9619
    0.1564    0.9040    0.9638
    0.1513    0.9091    0.9657
    0.1462    0.9141    0.9676
    0.1410    0.9192    0.9695
    0.1359    0.9242    0.9714
    0.1307    0.9293    0.9733
    0.1256    0.9343    0.9752
    0.1205    0.9394    0.9771
    0.1153    0.9444    0.9790
    0.1102    0.9495    0.9809
    0.1051    0.9545    0.9829
    0.0999    0.9596    0.9848
    0.0948    0.9646    0.9867
    0.0896    0.9697    0.9886
    0.0845    0.9747    0.9905
    0.0794    0.9798    0.9924
    0.0742    0.9848    0.9943
    0.0691    0.9899    0.9962
    0.0640    0.9949    0.9981
    0.0588    1.0000    1.0000];

%This is the button to get and display the curvature - only 2d projection

persistent lastPath path_curve2d
% If this is the first time running the function this session,
% Initialize lastPath to 0
if isempty(lastPath) 
    lastPath = 0;
end
% First time calling 'uigetfile', use the pwd
if lastPath == 0
    [file_curve2d, path_curve2d] = uigetfile();
    
% All subsequent calls, use the path to the last selected file
else
    [file_curve2d, path_curve2d] = uigetfile(lastPath);
end
% Use the path to the last selected file
% If 'uigetfile' is called, but no item is selected, 'lastPath' is not overwritten with 0
if path_curve2d ~= 0
    lastPath = path_curve2d;
end

%[file_curve2d,path_curve2d,success]=uigetfile;

%read in the image
im_curve_2d_tmp=imread(strcat(path_curve2d,file_curve2d));

%some scaling
im_curve_2d=double(im_curve_2d_tmp);
% im_curve_2d=im_curve_2d./10;
% im_curve_2d=im_curve_2d-100;

%make figure
file_curve2d_title=file_curve2d;
idx_c_title=find(file_curve2d_title=='_');
if numel(idx_c_title)>0
    file_curve2d_title(idx_c_title)='-';
end

%making histogram
dim3=size(im_curve_2d,1);
dim4=size(im_curve_2d,2);

max_c1=max(im_curve_2d(1:(dim3*dim4)));
mean_c1=mean(im_curve_2d(1:(dim3*dim4)));
std_c1=std(im_curve_2d(1:(dim3*dim4)));

nbins=linspace(0,max_c1,25);
figure, hist(im_curve_2d(1:(dim3*dim4)),nbins);
title('Curvature Histogram for ScaleBar'); xlabel('Eff. Curve'); ylabel('#');

max_plot=mean_c1+(3*std_c1);

figure, imagesc(im_curve_2d,[0,max_plot]); colormap(ens_curve_map); colorbar; title(strcat('Curvature2d:',file_curve2d_title));

%hang onto the image
handles.Curvature2d=im_curve_2d;

%storing the handles
guidata(hObject, handles);

function edit8_Callback(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit8 as text
%        str2double(get(hObject,'String')) returns contents of edit8 as a double

%This is the dit button for min intensity
handles.MinIntensity2d=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit8_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double

%This is the dit button for max intensity
handles.MaxIntensity2d=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit10_Callback(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit10 as text
%        str2double(get(hObject,'String')) returns contents of edit10 as a double

%This is the dit button for min curvature
handles.MinCurvature2d=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit10_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double

%This is the dit button for max curvature
handles.MaxCurvature2d=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double

%This is the edit box to indicate a delta x
handles.DeltaX2d=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double

%This is the edit box to indicate a delta y
handles.DeltaY2d=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end






    
  


% --- Executes on button press in pushbutton19.
function pushbutton19_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


cluster_surface_area_ch1=handles.SurfaceAreaClusterCh1
cluster_surface_area_ch2=handles.SurfaceAreaClusterCh2


% --- Executes on button press in pushbutton21.
function pushbutton21_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton21 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the pushbutton to do this curvature threshold thing that En wanted

%This are the colobars for curvature
%En's curvature map
ens_curve_map=[1.0000    0.0745    0.6510
    0.9966    0.0778    0.6522
    0.9932    0.0812    0.6535
    0.9898    0.0845    0.6548
    0.9864    0.0879    0.6560
    0.9830    0.0912    0.6573
    0.9796    0.0945    0.6585
    0.9762    0.0979    0.6598
    0.9728    0.1012    0.6611
    0.9694    0.1046    0.6623
    0.9660    0.1079    0.6636
    0.9627    0.1112    0.6648
    0.9593    0.1146    0.6661
    0.9559    0.1179    0.6673
    0.9525    0.1213    0.6686
    0.9491    0.1246    0.6699
    0.9457    0.1279    0.6711
    0.9423    0.1313    0.6724
    0.9389    0.1346    0.6736
    0.9355    0.1379    0.6749
    0.9321    0.1413    0.6762
    0.9287    0.1446    0.6774
    0.9253    0.1480    0.6787
    0.8837    0.1888    0.6941
    0.8422    0.2297    0.7095
    0.8006    0.2706    0.7249
    0.7590    0.3115    0.7403
    0.7174    0.3524    0.7558
    0.6759    0.3932    0.7712
    0.6343    0.4341    0.7866
    0.5927    0.4750    0.8020
    0.5511    0.5159    0.8174
    0.5096    0.5568    0.8328
    0.4680    0.5976    0.8483
    0.4264    0.6385    0.8637
    0.3848    0.6794    0.8791
    0.3433    0.7203    0.8945
    0.3017    0.7612    0.9099
    0.2601    0.8021    0.9253
    0.2186    0.8429    0.9408
    0.1770    0.8838    0.9562
    0.1718    0.8889    0.9581
    0.1667    0.8939    0.9600
    0.1616    0.8990    0.9619
    0.1564    0.9040    0.9638
    0.1513    0.9091    0.9657
    0.1462    0.9141    0.9676
    0.1410    0.9192    0.9695
    0.1359    0.9242    0.9714
    0.1307    0.9293    0.9733
    0.1256    0.9343    0.9752
    0.1205    0.9394    0.9771
    0.1153    0.9444    0.9790
    0.1102    0.9495    0.9809
    0.1051    0.9545    0.9829
    0.0999    0.9596    0.9848
    0.0948    0.9646    0.9867
    0.0896    0.9697    0.9886
    0.0845    0.9747    0.9905
    0.0794    0.9798    0.9924
    0.0742    0.9848    0.9943
    0.0691    0.9899    0.9962
    0.0640    0.9949    0.9981
    0.0588    1.0000    1.0000];

%making first element black
ens_curve_map_mask=[    0         0         0
    0.9966    0.0778    0.6523
    0.9936    0.0808    0.6534
    0.9907    0.0837    0.6545
    0.9877    0.0866    0.6556
    0.9847    0.0895    0.6567
    0.9817    0.0925    0.6578
    0.9788    0.0954    0.6589
    0.9758    0.0983    0.6600
    0.9728    0.1012    0.6611
    0.9699    0.1042    0.6622
    0.9669    0.1071    0.6633
    0.9639    0.1100    0.6644
    0.9610    0.1129    0.6655
    0.9580    0.1158    0.6666
    0.9550    0.1188    0.6677
    0.9520    0.1217    0.6688
    0.9491    0.1246    0.6699
    0.9461    0.1275    0.6710
    0.9431    0.1305    0.6721
    0.9402    0.1334    0.6732
    0.9372    0.1363    0.6743
    0.9342    0.1392    0.6754
    0.9312    0.1422    0.6765
    0.9283    0.1451    0.6776
    0.9253    0.1480    0.6787
    0.8813    0.1913    0.6950
    0.8373    0.2346    0.7113
    0.7932    0.2778    0.7277
    0.7492    0.3211    0.7440
    0.7052    0.3644    0.7603
    0.6612    0.4077    0.7766
    0.6172    0.4510    0.7930
    0.5732    0.4943    0.8093
    0.5291    0.5375    0.8256
    0.4851    0.5808    0.8419
    0.4411    0.6241    0.8583
    0.3971    0.6674    0.8746
    0.3531    0.7107    0.8909
    0.3091    0.7540    0.9072
    0.2650    0.7972    0.9236
    0.2210    0.8405    0.9399
    0.1770    0.8838    0.9562
    0.1714    0.8893    0.9583
    0.1657    0.8949    0.9604
    0.1601    0.9004    0.9625
    0.1545    0.9059    0.9645
    0.1489    0.9115    0.9666
    0.1432    0.9170    0.9687
    0.1376    0.9225    0.9708
    0.1320    0.9281    0.9729
    0.1263    0.9336    0.9750
    0.1207    0.9391    0.9771
    0.1151    0.9447    0.9791
    0.1095    0.9502    0.9812
    0.1038    0.9557    0.9833
    0.0982    0.9613    0.9854
    0.0926    0.9668    0.9875
    0.0869    0.9723    0.9896
    0.0813    0.9779    0.9917
    0.0757    0.9834    0.9937
    0.0701    0.9889    0.9958
    0.0644    0.9945    0.9979
    0.0588    1.0000    1.0000];

%figure out the color
map_easy=[         0         0    0.5625
         0         0    0.6250
         0         0    0.6875
         0         0    0.7500
         0         0    0.8125
         0         0    0.8750
         0         0    0.9375
         0         0    1.0000
         0    0.0625    1.0000
         0    0.1250    1.0000
         0    0.1875    1.0000
         0    0.2500    1.0000
         0    0.3125    1.0000
         0    0.3750    1.0000
         0    0.4375    1.0000
         0    0.5000    1.0000
         0    0.5625    1.0000
         0    0.6250    1.0000
         0    0.6875    1.0000
         0    0.7500    1.0000
         0    0.8125    1.0000
         0    0.8750    1.0000
         0    0.9375    1.0000
         0    1.0000    1.0000
    0.0625    1.0000    0.9375
    0.1250    1.0000    0.8750
    0.1875    1.0000    0.8125
    0.2500    1.0000    0.7500
    0.3125    1.0000    0.6875
    0.3750    1.0000    0.6250
    0.4375    1.0000    0.5625
    0.5000    1.0000    0.5000
    0.5625    1.0000    0.4375
    0.6250    1.0000    0.3750
    0.6875    1.0000    0.3125
    0.7500    1.0000    0.2500
    0.8125    1.0000    0.1875
    0.8750    1.0000    0.1250
    0.9375    1.0000    0.0625
    1.0000    1.0000         0
    1.0000    0.9375         0
    1.0000    0.8750         0
    1.0000    0.8125         0
    1.0000    0.7500         0
    1.0000    0.6875         0
    1.0000    0.6250         0
    1.0000    0.5625         0
    1.0000    0.5000         0
    1.0000    0.4375         0
    1.0000    0.3750         0
    1.0000    0.3125         0
    1.0000    0.2500         0
    1.0000    0.1875         0
    1.0000    0.1250         0
    1.0000    0.0625         0
    1.0000         0         0
    0.9375         0         0
    0.8750         0         0
    0.8125         0         0
    0.7500         0         0
    0.6875         0         0
    0.6250         0         0
    0.5625         0         0
    0.5000         0         0];
map_easy(1,:)=0;

%get the relevant node matrices
%channel 1
n_curve1=handles.NodeCurvature_1;
f_curve1=handles.FaceCurvature_1;
node_intensity1=handles.NodeIntensityData_1;
node_cluster1=handles.NodeCluster_1;

%channel 2
n_curve2=handles.NodeCurvature_2;
f_curve2=handles.FaceCurvature_2;
node_intensity2=handles.NodeIntensityData_2;
node_cluster2=handles.NodeCluster_2;

%curvature threshold
MinCurve=handles.MinCurveThresh;
MaxCurve=handles.MaxCurveThresh;

%cluster 5 threshold
cluster_per_final=handles.ClusterCurvePercentThresh;

%cluster stuff
% %getting the matrix to save - channel 1
% matrrix_to_save1=handles.cluster_curve_stats1;
% 
% %getting the matrix to save - channel 2
% matrrix_to_save2=handles.cluster_curve_stats2;
% 
% %getting the surface area of clusters in um2
% surface_area_clusters_ch1=handles.SurfaceAreaClusterCh1;
% surface_area_clusters_ch2=handles.SurfaceAreaClusterCh2;
% matrrix_to_save1(:,2)=surface_area_clusters_ch1(:,2);
% matrrix_to_save2(:,2)=surface_area_clusters_ch2(:,2);

    

%applying threshold and colocalization
if handles.CurveThreshCh1 == 1 && handles.ColocCurveWithCh1==1
    
    %do the calculation
    [n1_threshed,ni1_threshed,nc1_threshed_tmp,nc1_threshed]=thresh_and_coloc_homo_ch(n_curve1,node_intensity1,node_cluster1,MinCurve,MaxCurve,cluster_per_final);
    
    %make figures
    figure, hold on;
    
    subplot(2,2,1);
    plotmesh(n_curve1,f_curve1); shading interp; title('Ch1 - Curvature1john'); caxis([-0.5,0.5]);
    colormap(ens_curve_map);freezeColors;
    
    subplot(2,2,2);
    plotmesh(n1_threshed,f_curve1);  title('Ch 1 - Curv. Thresh.'); caxis([-0.6,0.5]);shading interp;
    colormap(ens_curve_map_mask);  freezeColors;
    
    subplot(2,2,3);
    plotmesh(nc1_threshed,f_curve1);  title('Ch 1 - Clusters - Threshed'); caxis([0,max(nc1_threshed(:,4))]);shading interp; colorbar;
    colormap(map_easy); freezeColors;
    
    subplot(2,2,4);
    plotmesh(node_cluster1,f_curve1); title('Ch 1 - Clusters - All'); caxis([0,max(nc1_threshed_tmp(:,4))]);shading interp; colorbar;
    colormap(map_easy); freezeColors;
    
    %some histograms - curvature, surface area and integrated intensity -
    %Channel 1
    matrrix_to_hist1_tmp=handles.cluster_curve_stats1;
    surface_area_clusters_ch1=handles.SurfaceAreaClusterCh1;
    countA=1;
    for t=min(surface_area_clusters_ch1(:,1)):max(surface_area_clusters_ch1(:,1))
        idxA=find(surface_area_clusters_ch1(:,1)==t);
        if idxA>0
            idxB=find(matrrix_to_hist1_tmp(:,1)==t);
            if numel(idxB)>0
                matrrix_to_hist1(countA,1)=t;
                matrrix_to_hist1(countA,2)=surface_area_clusters_ch1(idxA(1),2);
                matrrix_to_hist1(countA,3)=matrrix_to_hist1_tmp(idxB(1),3);
                matrrix_to_hist1(countA,4)=matrrix_to_hist1_tmp(idxB(1),4);
                matrrix_to_hist1(countA,5)=matrrix_to_hist1_tmp(idxB(1),5);
                countA=countA+1;
            end
            clear idxB;
        end
        clear idxA;
    end
    
   %getting the information on the clusters that survived the thresholding
   [sa1_thresh_arr,int1_thresh_arr,curve_thr_excel1]=get_stats_curve_thresh(nc1_threshed,matrrix_to_hist1);
   
   %saving the cluster statitstics in handle
   handles.ClusterStatsCurveThreshedCh1=curve_thr_excel1;

   %making the histograms
    nbins_sa1=linspace(min(matrrix_to_hist1(:,2)),max(matrrix_to_hist1(:,2)),10);
    nbins_int1=linspace(min(matrrix_to_hist1(:,3)),max(matrrix_to_hist1(:,3)),10);
    [y_sa1_thresh,x_sa1_thresh]=hist(sa1_thresh_arr(:,1),nbins_sa1);
    [y_sa1,x_sa1]=hist(matrrix_to_hist1(:,2),nbins_sa1);
    [y_int1_thresh,x_int1_thresh]=hist(int1_thresh_arr(:,1),nbins_int1);
    [y_int1,x_int1]=hist(matrrix_to_hist1(:,3),nbins_int1);
    
    figure, hold on; title('Surface Area - Ch1 Clusters');
    plot(x_sa1,y_sa1,'r','LineWidth',1.5);
    plot(x_sa1_thresh,y_sa1_thresh,'k','LineWidth',1.5);
    xlabel('Surface Area - um^2'); ylabel('# of Cluster');
    legend('All Clusters','Clusters in Thresh.');
    
    figure, hold on; title('Integr. Intens. - Ch1 Clusters');
    plot(x_int1,y_int1,'r','LineWidth',1.5);
    plot(x_int1_thresh,y_int1_thresh,'k','LineWidth',1.5);
    xlabel('Integrated Intensity'); ylabel('# of Cluster');
    legend('All Clusters','Clusters in Thresh.');
    
elseif handles.CurveThreshCh1 == 1 && handles.ColocCurveWithCh2==1

    %do the calculation
    [n1_threshed,ni2_threshed,nc2_threshed_tmp,nc2_threshed]=thresh_and_coloc_hetero_ch_v2(n_curve1,node_intensity2,node_cluster2,MinCurve,MaxCurve,cluster_per_final);

     %make figures
    figure, hold on;
    
    subplot(2,2,1);
    plotmesh(n_curve1,f_curve1); shading interp; title('Ch1 - Curvature'); caxis([-0.5,0.5]);
    colormap(ens_curve_map);freezeColors;
    
    subplot(2,2,2);
    plotmesh(n1_threshed,f_curve1);  title('Ch 1 - Curv. Thresh.'); caxis([-0.6,0.5]);shading interp;
    colormap(ens_curve_map_mask);  freezeColors;

    subplot(2,2,3);
    plotmesh(nc2_threshed_tmp,f_curve2);  title('Ch 2 - Clusters - Threshed'); caxis([0,max(nc2_threshed(:,4))]);shading interp; colorbar;
    colormap(map_easy); freezeColors;
   
    subplot(2,2,4);
    plotmesh(node_cluster2,f_curve2); title('Ch 2 - Clusters - All'); caxis([0,max(nc2_threshed(:,4))]); shading interp;colorbar;
    colormap(map_easy); freezeColors;
    
    %some histograms - curvature, surface area and integrated intensity -
    %Channel 2
    matrrix_to_hist2_tmp=handles.cluster_curve_stats2;
    surface_area_clusters_ch2=handles.SurfaceAreaClusterCh2;
    countA=1;
    for t=min(surface_area_clusters_ch2(:,1)):max(surface_area_clusters_ch2(:,1))
        idxA=find(surface_area_clusters_ch2(:,1)==t);
        if idxA>0
            idxB=find(matrrix_to_hist2_tmp(:,1)==t);
            if numel(idxB)>0
                matrrix_to_hist2(countA,1)=t;
                matrrix_to_hist2(countA,2)=surface_area_clusters_ch2(idxA(1),2);
                matrrix_to_hist2(countA,3)=matrrix_to_hist2_tmp(idxB(1),3);
                matrrix_to_hist2(countA,4)=matrrix_to_hist2_tmp(idxB(1),4);
                matrrix_to_hist2(countA,5)=matrrix_to_hist2_tmp(idxB(1),5);
                countA=countA+1;
            end
            clear idxB;
        end
        clear idxA;
    end
    
    %getting the information on the clusters that survived the thresholding
    [sa2_thresh_arr,int2_thresh_arr,curve_thr_excel2]=get_stats_curve_thresh(nc2_threshed_tmp,matrrix_to_hist2);
    
    %saving the cluster statitstics in handle
    handles.ClusterStatsCurveThreshedCh2=curve_thr_excel2;
  
    %Making the histogram
    nbins_sa2=linspace(min(matrrix_to_hist2(:,2)),max(matrrix_to_hist2(:,2)),10);
    nbins_int2=linspace(min(matrrix_to_hist2(:,3)),max(matrrix_to_hist2(:,3)),10);
    [y_sa2_thresh,x_sa2_thresh]=hist(sa2_thresh_arr(:,1),nbins_sa2);
    [y_sa2,x_sa2]=hist(matrrix_to_hist2(:,2),nbins_sa2);
    [y_int2_thresh,x_int2_thresh]=hist(int2_thresh_arr(:,1),nbins_int2);
    [y_int2,x_int2]=hist(matrrix_to_hist2(:,3),nbins_int2);
    
    figure, hold on; title('Surface Area - Ch2 Clusters');
    plot(x_sa2,y_sa2,'r','LineWidth',1.5);
    plot(x_sa2_thresh,y_sa2_thresh,'k','LineWidth',1.5);
    xlabel('Surface Area - um^2'); ylabel('# of Cluster');
    legend('All Clusters','Clusters in Thresh.');
    
    figure, hold on; title('Integr. Intens. - Ch2 Clusters');
    plot(x_int2,y_int2,'r','LineWidth',1.5);
    plot(x_int2_thresh,y_int2_thresh,'k','LineWidth',1.5);
    xlabel('Integrated Intensity'); ylabel('# of Cluster');
    legend('All Clusters','Clusters in Thresh.');


elseif handles.CurveThreshCh2 == 1 && handles.ColocCurveWithCh2==1

    %do the calculation
    [n2_threshed,ni2_threshed,nc2_threshed_tmp,nc2_threshed]=thresh_and_coloc_homo_ch(n_curve2,node_intensity2,node_cluster2,MinCurve,MaxCurve,cluster_per_final);
    
    %make figures
    figure, hold on;
    
    subplot(2,2,1);
    plotmesh(n_curve2,f_curve2); shading interp; title('Ch2 - Curvature'); caxis([-0.5,0.5]);
    colormap(ens_curve_map);freezeColors;
    
    subplot(2,2,2);
    plotmesh(n2_threshed,f_curve2);  title('Ch 2 - Curv. Thresh.'); caxis([-0.6,0.5]);shading interp;
    colormap(ens_curve_map_mask);  freezeColors;
    
    subplot(2,2,3);
    plotmesh(nc2_threshed,f_curve2);  title('Ch 2 - Clusters - Thresh'); caxis([0,max(nc2_threshed(:,4))]);shading interp;
    colormap(map_easy); colorbar; freezeColors;
 
    subplot(2,2,4);
    plotmesh(node_cluster2,f_curve2);  title('Ch 2 - Clusters - All'); caxis([0,max(nc2_threshed_tmp(:,4))]);colormap(map_easy);shading interp;
     colorbar;

    %some histograms - curvature, surface area and integrated intensity -
    %Channel 2
    matrrix_to_hist2_tmp=handles.cluster_curve_stats2;
    surface_area_clusters_ch2=handles.SurfaceAreaClusterCh2;
    countA=1;
    for t=min(surface_area_clusters_ch2(:,1)):max(surface_area_clusters_ch2(:,1))
        idxA=find(surface_area_clusters_ch2(:,1)==t);
        if idxA>0
            idxB=find(matrrix_to_hist2_tmp(:,1)==t);
            if numel(idxB)>0
                matrrix_to_hist2(countA,1)=t;
                matrrix_to_hist2(countA,2)=surface_area_clusters_ch2(idxA(1),2);
                matrrix_to_hist2(countA,3)=matrrix_to_hist2_tmp(idxB(1),3);
                matrrix_to_hist2(countA,4)=matrrix_to_hist2_tmp(idxB(1),4);
                matrrix_to_hist2(countA,5)=matrrix_to_hist2_tmp(idxB(1),5);
                countA=countA+1;
            end
            clear idxB;
        end
        clear idxA;
    end
   
    %getting the information on the clusters that survived the thresholding
    [sa2_thresh_arr,int2_thresh_arr,curve_thr_excel2]=get_stats_curve_thresh(nc2_threshed,matrrix_to_hist2);
    
    %saving the cluster statitstics in handle
    handles.ClusterStatsCurveThreshedCh2=curve_thr_excel2;
    
    %making the histogram
    nbins_sa2=linspace(min(matrrix_to_hist2(:,2)),max(matrrix_to_hist2(:,2)),10);
    nbins_int2=linspace(min(matrrix_to_hist2(:,3)),max(matrrix_to_hist2(:,3)),10);
    [y_sa2_thresh,x_sa2_thresh]=hist(sa2_thresh_arr(:,1),nbins_sa2);
    [y_sa2,x_sa2]=hist(matrrix_to_hist2(:,2),nbins_sa2);
    [y_int2_thresh,x_int2_thresh]=hist(int2_thresh_arr(:,1),nbins_int2);
    [y_int2,x_int2]=hist(matrrix_to_hist2(:,3),nbins_int2);
    
    figure, hold on; title('Surface Area - Ch2 Clusters');
    plot(x_sa2,y_sa2,'r','LineWidth',1.5);
    plot(x_sa2_thresh,y_sa2_thresh,'k','LineWidth',1.5);
    xlabel('Surface Area - um^2'); ylabel('# of Cluster');
    legend('All Clusters','Clusters in Thresh.');
    
    figure, hold on; title('Integr. Intens. - Ch2 Clusters');
    plot(x_int2,y_int2,'r','LineWidth',1.5);
    plot(x_int2_thresh,y_int2_thresh,'k','LineWidth',1.5);
    xlabel('Integrated Intensity'); ylabel('# of Cluster');
    legend('All Clusters','Clusters in Thresh.');

    
elseif handles.CurveThreshCh2 == 1 && handles.ColocCurveWithCh1==1

    % do the calculation
    [n2_threshed,ni1_threshed,nc1_threshed_tmp,nc1_threshed]=thresh_and_coloc_hetero_ch_v2(n_curve2,node_intensity1,node_cluster1,MinCurve,MaxCurve,cluster_per_final);

    %make figures
    figure, hold on;
    
    subplot(2,2,1);
    plotmesh(n_curve2,f_curve2); shading interp; title('Ch2 - Curvature'); caxis([-0.5,0.5]);
    colormap(ens_curve_map);freezeColors;
    
    subplot(2,2,2);
    plotmesh(n2_threshed,f_curve2);  title('Ch 2 - Curv. Thresh.'); caxis([-0.6,0.5]);shading interp;
    colormap(ens_curve_map_mask);  freezeColors;

    subplot(2,2,3);
    plotmesh(nc1_threshed_tmp,f_curve1);  title('Ch 1 - Clusters - Threshed'); caxis([0,max(nc1_threshed(:,4))]);shading interp;
    colormap(map_easy); colorbar;freezeColors;
    
    subplot(2,2,4);
    plotmesh(node_cluster1,f_curve1); title('Ch 1 - Clusters - All'); caxis([0,max(nc1_threshed(:,4))]); colorbar;shading interp;
    colormap(map_easy); freezeColors;
    
    %some histograms - curvature, surface area and integrated intensity -
    %Channel 1
    matrrix_to_hist1_tmp=handles.cluster_curve_stats1;
    surface_area_clusters_ch1=handles.SurfaceAreaClusterCh1;
    countA=1;
    for t=min(surface_area_clusters_ch1(:,1)):max(surface_area_clusters_ch1(:,1))
        idxA=find(surface_area_clusters_ch1(:,1)==t);
        if idxA>0
            idxB=find(matrrix_to_hist1_tmp(:,1)==t);
            if numel(idxB)>0
                matrrix_to_hist1(countA,1)=t;
                matrrix_to_hist1(countA,2)=surface_area_clusters_ch1(idxA(1),2);
                matrrix_to_hist1(countA,3)=matrrix_to_hist1_tmp(idxB(1),3);
                matrrix_to_hist1(countA,4)=matrrix_to_hist1_tmp(idxB(1),4);
                matrrix_to_hist1(countA,5)=matrrix_to_hist1_tmp(idxB(1),5);
                countA=countA+1;
            end
            clear idxB;
        end
        clear idxA;
    end
    
    %getting the information on the clusters that survived the thresholding
    [sa1_thresh_arr,int1_thresh_arr,curve_thr_excel1]=get_stats_curve_thresh(nc1_threshed_tmp,matrrix_to_hist1);
    
    %saving the cluster statitstics in handle
    handles.ClusterStatsCurveThreshedCh1=curve_thr_excel1;
    
    %making the histogtams
    nbins_sa1=linspace(min(matrrix_to_hist1(:,2)),max(matrrix_to_hist1(:,2)),10);
    nbins_int1=linspace(min(matrrix_to_hist1(:,3)),max(matrrix_to_hist1(:,3)),10);
    [y_sa1_thresh,x_sa1_thresh]=hist(sa1_thresh_arr(:,1),nbins_sa1);
    [y_sa1,x_sa1]=hist(matrrix_to_hist1(:,2),nbins_sa1);
    [y_int1_thresh,x_int1_thresh]=hist(int1_thresh_arr(:,1),nbins_int1);
    [y_int1,x_int1]=hist(matrrix_to_hist1(:,3),nbins_int1);
    
    figure, hold on; title('Surface Area - Ch1 Clusters');
    plot(x_sa1,y_sa1,'r','LineWidth',1.5);
    plot(x_sa1_thresh,y_sa1_thresh,'k','LineWidth',1.5);
    xlabel('Surface Area - um^2'); ylabel('# of Cluster');
    legend('All Clusters','Clusters in Thresh.');
    
    figure, hold on; title('Integr. Intens. - Ch1 Clusters');
    plot(x_int1,y_int1,'r','LineWidth',1.5);
    plot(x_int1_thresh,y_int1_thresh,'k','LineWidth',1.5);
    xlabel('Integrated Intensity'); ylabel('# of Cluster');
    legend('All Clusters','Clusters in Thresh.');

end


%storing the handles
guidata(hObject, handles);


% --- Executes on button press in radiobutton12.
function radiobutton12_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the radiobutton that tells the code to colocalize with ch1
handles.ColocCurveWithCh1=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);

% --- Executes on button press in radiobutton13.
function radiobutton13_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the radiobutton that tells the code to colocalize with ch1
handles.ColocCurveWithCh2=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in radiobutton10.
function radiobutton10_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton10 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%curvature threshold - ch1 
%This is the radiobutton that indicates a curvature threshold is to be applied to channel 1 
handles.CurveThreshCh1=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


% --- Executes on button press in radiobutton11.
function radiobutton11_Callback(hObject, eventdata, handles)
% hObject    handle to radiobutton11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%curvature threshold - ch2 
%This is the radiobutton that indicates a curvature threshold is to be applied to channel 2 
handles.CurveThreshCh2=get(hObject,'Value');

%storing the handles
guidata(hObject, handles);


function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the edit box that will hold the minimum level of allow curvature.
MinCurveThreshStr=get(hObject,'String');
handles.MinCurveThresh=str2num(MinCurveThreshStr);

%storing the handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the edit box that will hold the maximum level of allow curvature.
MaxCurveThreshStr=get(hObject,'String');
handles.MaxCurveThresh=str2num(MaxCurveThreshStr);

%storing the handles
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the edit box to indicate percentage of cluster that needs to
%contain after threshold to be included
handles.ClusterCurvePercentThresh=str2double(get(hObject,'String'));

%storing the handles
guidata(hObject, handles);

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton22.
function pushbutton22_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton22 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the pushbutton needed to save the statistics from the clusters
%that survive the threshold of curvature that was selected

%getting the location and filename to save file
[file_save_thresh_tmp,path_save_thresh]=uiputfile;

%edit the filename
idx_save_thresh=find(file_save_thresh_tmp=='.');
file_save_thresh=strcat(path_save_thresh,file_save_thresh_tmp(1:idx_save_thresh(1)),'xlsx');

%getting the matrix to save as excel file
if handles.CurveThreshCh1 == 1 && handles.ColocCurveWithCh1==1
    
    %matrix to save
    CurveThreshClusterCh1_ex=handles.ClusterStatsCurveThreshedCh1;
    %saving data to excel file
    save_data_to_excel(CurveThreshClusterCh1_ex,file_save_thresh);
    
elseif handles.CurveThreshCh1 == 1 && handles.ColocCurveWithCh2==1
    
    %matrix to save
    CurveThreshClusterCh2_ex=handles.ClusterStatsCurveThreshedCh2;
    %saving data to excel file
    save_data_to_excel(CurveThreshClusterCh2_ex,file_save_thresh);
    
elseif handles.CurveThreshCh2 == 1 && handles.ColocCurveWithCh2==1
    
    %matrix to save
    CurveThreshClusterCh2_ex=handles.ClusterStatsCurveThreshedCh2;
    %saving data to excel file
    save_data_to_excel(CurveThreshClusterCh2_ex,file_save_thresh);
    
elseif handles.CurveThreshCh2 == 1 && handles.ColocCurveWithCh1==1
    
    %matrix to save
    CurveThreshClusterCh1_ex=handles.ClusterStatsCurveThreshedCh1;
    %saving data to excel file
    save_data_to_excel(CurveThreshClusterCh1_ex,file_save_thresh);
    
end


% --- Executes on button press in pushbutton23.
function pushbutton23_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton23 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% %for debugging only 
% %these are the image indices to look through
% n_initial=1;
% n_final=75;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%Step 1 - Figuring out if this (1) or (2) channel data%%%%%%%%%%%%%%%%%%

%No clustering - first
if handles.ClusterAnalysisYes == 0 || handles.ClusterAnalysisNo==1
    
    %clustering flag
    cluster_and_villi=0;
    
    if handles.ch1 == 1 && handles.ch2 == 0
        num_ch_send=1;
        n_curve1=handles.NodeCurvature_1;
        n_int1=handles.NodeIntensityData_1;
        f_curve1=handles.FaceCurvature_1;
        path1_v=handles.pathname_bd1g;
        
        %call to next GUI page
        DetectExamineMicrovilliGUI(num_ch_send,cluster_and_villi,f_curve1,n_curve1,n_int1,path1_v);
        
    elseif handles.ch1 == 0 && handles.ch2 == 1
        num_ch_send=1;
        n_curve2=handles.NodeCurvature_2;
        n_int2=handles.NodeIntensityData_2;
        f_curve2=handles.FaceCurvature_2;
        path2_v=handles.pathname_bd2g;
        
        %call to next GUI page
        DetectExamineMicrovilliGUI(num_ch_send,cluster_and_villi,f_curve2,n_curve2,n_int2,path2_v);
        
    elseif handles.ch1 == 1 && handles.ch2 == 1
        num_ch_send=2;
        %channel 1
        n_curve1=handles.NodeCurvature_1;
        n_int1=handles.NodeIntensityData_1;
        f_curve1=handles.FaceCurvature_1;
        path1_v=handles.pathname_bd1g
        
        %channel 2
        n_curve2=handles.NodeCurvature_2;
        n_int2=handles.NodeIntensityData_2;
        f_curve2=handles.FaceCurvature_2;
        path2_v=handles.pathname_bd2g
        
        %call to next GUI page
        DetectExamineMicrovilliGUI(num_ch_send,cluster_and_villi,f_curve1,n_curve1,n_int1,path1_v,f_curve2,n_curve2,n_int2,path2_v);
        
    end

%include clustering for villi 
else

    %clustering flag
    cluster_and_villi=1;
    
    if handles.ch1 == 1 && handles.ch2 == 0
        num_ch_send=1;
        n_curve1=handles.NodeCurvature_1;
        n_int1=handles.NodeIntensityData_1;
        f_curve1=handles.FaceCurvature_1;
        n_cluster1=handles.NodeCluster_1;
        path1_v=handles.pathname_bd1g;
        
        %call to next GUI page
        DetectExamineMicrovilliGUI(num_ch_send,cluster_and_villi,f_curve1,n_curve1,n_int1,n_cluster1,path1_v);
        
    elseif handles.ch1 == 0 && handles.ch2 == 1
        num_ch_send=1;
        n_curve2=handles.NodeCurvature_2;
        n_int2=handles.NodeIntensityData_2;
        f_curve2=handles.FaceCurvature_2;
        n_cluster2=handles.NodeCluster_2;
        path2_v=handles.pathname_bd2g;
        
        %call to next GUI page
        DetectExamineMicrovilliGUI(num_ch_send,cluster_and_villi,f_curve2,n_curve2,n_int2,n_cluster2,path2_v);
        
    elseif handles.ch1 == 1 && handles.ch2 == 1
        num_ch_send=2;
        %channel 1
        n_curve1=handles.NodeCurvature_1;
        n_int1=handles.NodeIntensityData_1;
        f_curve1=handles.FaceCurvature_1;
        n_cluster1=handles.NodeCluster_1;
        path1_v=handles.pathname_bd1g
        %channel 2
        n_curve2=handles.NodeCurvature_2;
        n_int2=handles.NodeIntensityData_2;
        f_curve2=handles.FaceCurvature_2;
        n_cluster2=handles.NodeCluster_2;
        path2_v=handles.pathname_bd2g
        
        %call to next GUI page
        DetectExamineMicrovilliGUI(num_ch_send,cluster_and_villi,f_curve1,n_curve1,n_int1,n_cluster1,path1_v,f_curve2,n_curve2,n_int2,n_cluster2,path2_v);
    end
end

%This is the button that I am experimenting essentially with a mountain (or
%protrusion) finder for En's stu
john=10000




% --- Executes on button press in pushbutton24.
function pushbutton24_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton24 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the code for the stuff En needed (end of Nov 2019 - early Dec
%2019)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%getting the information necessary to generate surface plots later%%%%%%
 
%This are the colobars for curvature
%En's curvature map
ens_curve_map=[1.0000    0.0745    0.6510
    0.9966    0.0778    0.6522
    0.9932    0.0812    0.6535
    0.9898    0.0845    0.6548
    0.9864    0.0879    0.6560
    0.9830    0.0912    0.6573
    0.9796    0.0945    0.6585
    0.9762    0.0979    0.6598
    0.9728    0.1012    0.6611
    0.9694    0.1046    0.6623
    0.9660    0.1079    0.6636
    0.9627    0.1112    0.6648
    0.9593    0.1146    0.6661
    0.9559    0.1179    0.6673
    0.9525    0.1213    0.6686
    0.9491    0.1246    0.6699
    0.9457    0.1279    0.6711
    0.9423    0.1313    0.6724
    0.9389    0.1346    0.6736
    0.9355    0.1379    0.6749
    0.9321    0.1413    0.6762
    0.9287    0.1446    0.6774
    0.9253    0.1480    0.6787
    0.8837    0.1888    0.6941
    0.8422    0.2297    0.7095
    0.8006    0.2706    0.7249
    0.7590    0.3115    0.7403
    0.7174    0.3524    0.7558
    0.6759    0.3932    0.7712
    0.6343    0.4341    0.7866
    0.5927    0.4750    0.8020
    0.5511    0.5159    0.8174
    0.5096    0.5568    0.8328
    0.4680    0.5976    0.8483
    0.4264    0.6385    0.8637
    0.3848    0.6794    0.8791
    0.3433    0.7203    0.8945
    0.3017    0.7612    0.9099
    0.2601    0.8021    0.9253
    0.2186    0.8429    0.9408
    0.1770    0.8838    0.9562
    0.1718    0.8889    0.9581
    0.1667    0.8939    0.9600
    0.1616    0.8990    0.9619
    0.1564    0.9040    0.9638
    0.1513    0.9091    0.9657
    0.1462    0.9141    0.9676
    0.1410    0.9192    0.9695
    0.1359    0.9242    0.9714
    0.1307    0.9293    0.9733
    0.1256    0.9343    0.9752
    0.1205    0.9394    0.9771
    0.1153    0.9444    0.9790
    0.1102    0.9495    0.9809
    0.1051    0.9545    0.9829
    0.0999    0.9596    0.9848
    0.0948    0.9646    0.9867
    0.0896    0.9697    0.9886
    0.0845    0.9747    0.9905
    0.0794    0.9798    0.9924
    0.0742    0.9848    0.9943
    0.0691    0.9899    0.9962
    0.0640    0.9949    0.9981
    0.0588    1.0000    1.0000];

%making first element black
ens_curve_map_mask=[    0         0         0
    0.9966    0.0778    0.6523
    0.9936    0.0808    0.6534
    0.9907    0.0837    0.6545
    0.9877    0.0866    0.6556
    0.9847    0.0895    0.6567
    0.9817    0.0925    0.6578
    0.9788    0.0954    0.6589
    0.9758    0.0983    0.6600
    0.9728    0.1012    0.6611
    0.9699    0.1042    0.6622
    0.9669    0.1071    0.6633
    0.9639    0.1100    0.6644
    0.9610    0.1129    0.6655
    0.9580    0.1158    0.6666
    0.9550    0.1188    0.6677
    0.9520    0.1217    0.6688
    0.9491    0.1246    0.6699
    0.9461    0.1275    0.6710
    0.9431    0.1305    0.6721
    0.9402    0.1334    0.6732
    0.9372    0.1363    0.6743
    0.9342    0.1392    0.6754
    0.9312    0.1422    0.6765
    0.9283    0.1451    0.6776
    0.9253    0.1480    0.6787
    0.8813    0.1913    0.6950
    0.8373    0.2346    0.7113
    0.7932    0.2778    0.7277
    0.7492    0.3211    0.7440
    0.7052    0.3644    0.7603
    0.6612    0.4077    0.7766
    0.6172    0.4510    0.7930
    0.5732    0.4943    0.8093
    0.5291    0.5375    0.8256
    0.4851    0.5808    0.8419
    0.4411    0.6241    0.8583
    0.3971    0.6674    0.8746
    0.3531    0.7107    0.8909
    0.3091    0.7540    0.9072
    0.2650    0.7972    0.9236
    0.2210    0.8405    0.9399
    0.1770    0.8838    0.9562
    0.1714    0.8893    0.9583
    0.1657    0.8949    0.9604
    0.1601    0.9004    0.9625
    0.1545    0.9059    0.9645
    0.1489    0.9115    0.9666
    0.1432    0.9170    0.9687
    0.1376    0.9225    0.9708
    0.1320    0.9281    0.9729
    0.1263    0.9336    0.9750
    0.1207    0.9391    0.9771
    0.1151    0.9447    0.9791
    0.1095    0.9502    0.9812
    0.1038    0.9557    0.9833
    0.0982    0.9613    0.9854
    0.0926    0.9668    0.9875
    0.0869    0.9723    0.9896
    0.0813    0.9779    0.9917
    0.0757    0.9834    0.9937
    0.0701    0.9889    0.9958
    0.0644    0.9945    0.9979
    0.0588    1.0000    1.0000];

%figure out the color
map_easy=[         0         0    0.5625
         0         0    0.6250
         0         0    0.6875
         0         0    0.7500
         0         0    0.8125
         0         0    0.8750
         0         0    0.9375
         0         0    1.0000
         0    0.0625    1.0000
         0    0.1250    1.0000
         0    0.1875    1.0000
         0    0.2500    1.0000
         0    0.3125    1.0000
         0    0.3750    1.0000
         0    0.4375    1.0000
         0    0.5000    1.0000
         0    0.5625    1.0000
         0    0.6250    1.0000
         0    0.6875    1.0000
         0    0.7500    1.0000
         0    0.8125    1.0000
         0    0.8750    1.0000
         0    0.9375    1.0000
         0    1.0000    1.0000
    0.0625    1.0000    0.9375
    0.1250    1.0000    0.8750
    0.1875    1.0000    0.8125
    0.2500    1.0000    0.7500
    0.3125    1.0000    0.6875
    0.3750    1.0000    0.6250
    0.4375    1.0000    0.5625
    0.5000    1.0000    0.5000
    0.5625    1.0000    0.4375
    0.6250    1.0000    0.3750
    0.6875    1.0000    0.3125
    0.7500    1.0000    0.2500
    0.8125    1.0000    0.1875
    0.8750    1.0000    0.1250
    0.9375    1.0000    0.0625
    1.0000    1.0000         0
    1.0000    0.9375         0
    1.0000    0.8750         0
    1.0000    0.8125         0
    1.0000    0.7500         0
    1.0000    0.6875         0
    1.0000    0.6250         0
    1.0000    0.5625         0
    1.0000    0.5000         0
    1.0000    0.4375         0
    1.0000    0.3750         0
    1.0000    0.3125         0
    1.0000    0.2500         0
    1.0000    0.1875         0
    1.0000    0.1250         0
    1.0000    0.0625         0
    1.0000         0         0
    0.9375         0         0
    0.8750         0         0
    0.8125         0         0
    0.7500         0         0
    0.6875         0         0
    0.6250         0         0
    0.5625         0         0
    0.5000         0         0];
map_easy(1,:)=0;

%channel 1
 n_curve_1e=handles.NodeCurvature_1;
 f_curve_1e=handles.FaceCurvature_1;
 n_cluster_1e=handles.NodeCluster_1;
 n_cluster_size_1e=handles.NodeClusterSize_1;
 n_cluster_intensity_1e=handles.NodeClusterIntensity_1;
 node_intensity_ret_1e=handles.NodeIntensityData_1;
 
 %channel 2
 n_curve_2e=handles.NodeCurvature_2;
 f_curve_2e=handles.FaceCurvature_2;
 n_cluster_2e=handles.NodeCluster_2;
 n_cluster_size_2e=handles.NodeClusterSize_2;
 n_cluster_intensity_2e=handles.NodeClusterIntensity_2;
 node_intensity_ret_2e=handles.NodeIntensityData_2;
 
 %for debugging only 
%  for q=1:numel(n_curve_2e(:,1))
%     
%      if n_curve_2e(q,1)>30 && n_curve_2e(q,1)<60 && n_curve_2e(q,2)>10 && n_curve_2e(q,2)<60 && n_curve_2e(q,3)>30 && n_curve_2e(q,3)<60
%          n_curve_2e(q,4)=-1;
%      end
%      
%      
%  end
 
 %doing some masking of the curvature ch2 curvature, ch1 clusters
 [node_mask_cluster_1,node_mask_cluster_1_rev]=mask_cluster_w_curvature_v3(n_curve_2e,n_cluster_1e);
 
 %what does this look like?
 figure, hold on;
 
 subplot(1,4,1);
 plotmesh(n_curve_2e,f_curve_2e); shading interp; title('Ch2 - Curvature'); caxis([-0.5,0.5]);
 colormap(ens_curve_map); freezeColors;
 
 subplot(1,4,2);
 plotmesh(n_cluster_1e,f_curve_1e);  title('Ch 1 - Cluster #'); caxis([0,max(n_cluster_1e(:,4))]);shading interp;
 colormap(map_easy); freezeColors;
 
 subplot(1,4,3);
 plotmesh(node_mask_cluster_1,f_curve_1e); shading interp; title('Ch2 - Curv, Ch1 Clusters'); caxis([-0.6,0.5]);
 colormap(ens_curve_map_mask); freezeColors;
 
 subplot(1,4,4);
 plotmesh(node_mask_cluster_1_rev,f_curve_1e); shading interp; title('Ch2 - Curv, Ch1 Clusters - Rev'); caxis([-0.6,0.5]);
 colormap(ens_curve_map_mask); freezeColors;
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%histogtams for statistics%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 %curvature from channel 2
 %n_curve_2e
 
 %finding z extrema
 min_z_now=min(n_curve_2e(:,3));
 max_z_now=max(n_curve_2e(:,3));
 
 %z boundaries for histogram - avoiding flat top and flat bottom
 min_z_bound=min_z_now+2;
 max_z_bound=max_z_now-2;
 
 %sorting by z value (low -> high)
 count_en2=1;
 for t=1:numel(n_curve_2e(:,3))
     
     if n_curve_2e(t,3)>=min_z_bound && n_curve_2e(t,3)<=max_z_bound && n_curve_2e(t,4)~=0
         
         %store curvature values for histogram
         curve_all_ch2(count_en2,1)=n_curve_2e(t,4);
         
         %iterate counter
         count_en2=count_en2+1;
         
     end
     
 end
 
 nbins_all=linspace(-0.5,0.5,50);
 [y_all_ch2,x_all_ch2]=hist(curve_all_ch2,nbins_all);
 
 %curvature from channel 2 projected onto the clusters from channel 1
 %node_mask_cluster_1
 
 %counter
 count_en_masked=1;
 
 %for debugging only
  figure, plotmesh(node_mask_cluster_1,f_curve_1e); shading interp; title('Ch2 - Curv, Ch1 Clusters'); caxis([-0.6,0.5]);
 colormap(ens_curve_map_mask); freezeColors; hold on;
 figure, plotmesh(node_mask_cluster_1,f_curve_1e); shading interp; title('Ch2 - Curv, Ch1 Clusters'); caxis([-0.6,0.5]);
 colormap(ens_curve_map_mask); freezeColors; hold on;
 
 for p=1:numel(node_mask_cluster_1(:,1))
     
     if node_mask_cluster_1(p,3)>=min_z_bound && node_mask_cluster_1(p,3)<=max_z_bound && node_mask_cluster_1(p,4) ~= -0.6 && node_mask_cluster_1(p,4) ~= 0
     
        %plot for debugging only - marking off positions used in
        %calculations
        plot3(node_mask_cluster_1(p,1),node_mask_cluster_1(p,2),node_mask_cluster_1(p,3),'g+','MarkerSize',12,'LineWidth',1.5);
         
         %store curvature values for histogram
         curve_ch2_proj_in_ch1(count_en_masked,1)=node_mask_cluster_1(p,4);
         
         %iterate counter
         count_en_masked=count_en_masked+1;
         
     end
     
     
 end
 
 [y_ch2_in_ch1,x_ch2_in_ch1]=hist(curve_ch2_proj_in_ch1,nbins_all);
 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%%%Raw Plot%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 
 figure, hold on; title('Histograms of Ch2s Curvature');
 plot(x_all_ch2,y_all_ch2,'k','LineWidth',1.5);
 plot(x_ch2_in_ch1,y_ch2_in_ch1,'r','LineWidth',1.5,'Color',[0.6,0.6,0.6]);
 ylabel('#'); xlabel('Curvature');
 
 %adding some statistics
 mean_all_ch2=mean(curve_all_ch2)
 std_all_ch2=std(curve_all_ch2)
 
 mean_ch2_in_ch1=mean(curve_ch2_proj_in_ch1)
 std_ch2_in_ch1=std(curve_ch2_proj_in_ch1)
 
 errorbar(mean_all_ch2,(max(y_all_ch2))*0.5,std_all_ch2,'horizontal','LineWidth',1.5,'Color',[0.0,0.0,0.0]);
 errorbar(mean_ch2_in_ch1,((max(y_all_ch2))*0.5)-50,std_ch2_in_ch1,'horizontal','LineWidth',1.5,'Color',[0.6,0.6,0.6]);
 
 plot(mean_all_ch2,(max(y_all_ch2))*0.5,'k+','MarkerSize',12,'LineWidth',1.5,'Color',[0.0,0.0,0.0]);
 plot(mean_ch2_in_ch1,((max(y_all_ch2))*0.5)-50,'k+','MarkerSize',12,'LineWidth',1.5,'Color',[0.6,0.6,0.6]);

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 %%%%%%%%%%%%%%%%%%%%%%Plot with normalization%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 figure, hold on; title('Histograms of Ch2s Curvature - Normalized');
 plot(x_all_ch2,y_all_ch2./max(y_all_ch2),'k','LineWidth',1.5);
 plot(x_ch2_in_ch1,y_ch2_in_ch1./max(y_ch2_in_ch1),'r','LineWidth',1.5,'Color',[0.6,0.6,0.6]);
 ylabel('#'); xlabel('Curvature');
 

 errorbar(mean_all_ch2,0.7,std_all_ch2,'horizontal','LineWidth',1.5,'Color',[0.0,0.0,0.0]);
 errorbar(mean_ch2_in_ch1,0.5,std_ch2_in_ch1,'horizontal','LineWidth',1.5,'Color',[0.6,0.6,0.6]);
 
 plot(mean_all_ch2,0.7,'k+','MarkerSize',12,'LineWidth',1.5,'Color',[0.0,0.0,0.0]);
 plot(mean_ch2_in_ch1,0.5,'k+','MarkerSize',12,'LineWidth',1.5,'Color',[0.6,0.6,0.6]);


% --- Executes on button press in pushbutton25.
function pushbutton25_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton25 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is the button to combine the colocalization, surface area and
%curvature information

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%getting information from text file about colocalization%%%%%%%%%

%getting the path and colocalization text file - green channel
[file_coloc_gr,path_coloc_gr,success]=uigetfile('*.*')
the_file_gr=strcat(path_coloc_gr,file_coloc_gr);

%getting the relevant colocalization information - green channel
[coloc_final_mat_gr]=open_coloc_text_files(the_file_gr);

%getting the colocalization text file - red channel
file_coloc_red='Red_first_colocalization_information.txt';

%getting the path to the colocalization text file - red channel
idx_mast=find(path_coloc_gr=='\');
path_red1_tmp=path_coloc_gr(1:(idx_mast(numel(idx_mast)-3)));
path_red1=strcat(path_red1_tmp,'r0');
path_red2=path_coloc_gr(idx_mast(numel(idx_mast)-2):idx_mast(numel(idx_mast)));
path_coloc_red=strcat(path_red1,path_red2);

%combining path and filename - red channel
the_file_red=strcat(path_coloc_red,file_coloc_red);

%getting the relevant colocalization information - red channel
[coloc_final_mat_red]=open_coloc_text_files(the_file_red);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Green Channel%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%making a new definition of highly colocalizing cluster%%%%%%%%%
%%%%%%%%%%%%%%%%%%calling these super-colocalizers%%%%%%%%%%%%%%%%%%%%%%%%%

%matrix of information about green colocalizing clusters
% coloc_final_mat_gr(:,1) = green clusters that coloc
% coloc_final_mat_gr(:,2) = percentage (by area) colocalization
% coloc_final_mat_gr(:,3) = red clusters that coloc

%image indices
ns=handles.theStartNumber;
ne=handles.theEndNumber;

%getting the paths to cluster images - red channel
path_cluster_red=strcat(path_red1,'\WholeImageStackClustering\Intensity Stack\Im');

%getting paths to cluster images - green channel
path_gr_m=path_red1(1:(numel(path_red1)-3));
path_cluster_green=strcat(path_gr_m,'\g0\WholeImageStackClustering\Intensity Stack\Im');

%locate possible highly colocalizing green clusters - super-colocalizers -
%based on colocalization percentage
idx_super_gr_tmp=find(coloc_final_mat_gr(:,2)>50);

%locate possible highly colocalizing green clusters - super-colocalizers -
%based on comparative area
count_mad=1;
for i=1:numel(idx_super_gr_tmp)
    if coloc_final_mat_gr(idx_super_gr_tmp(i),4) >= coloc_final_mat_gr(idx_super_gr_tmp(i),5)
        poss_gr_super_coloc_tmp(count_mad,1)=coloc_final_mat_gr(idx_super_gr_tmp(i),1);
        count_mad=count_mad+1;
    end
end
 
%counter 
green_ct=0;

if count_mad>1
    
    % removing duplicates
    poss_gr_super_coloc=unique(poss_gr_super_coloc_tmp,'rows');
    
    %locating the super-colocalizers - green channel
    for m=1:numel(poss_gr_super_coloc)
        
        %number of possible green super-cluster - green channel
        gr_super_maybe=poss_gr_super_coloc(m);
        
        %get the list of red clusters that colocizate
        idx_red_super=find(coloc_final_mat_gr(:,1)==gr_super_maybe);
        red_super_maybe=coloc_final_mat_gr(idx_red_super,3);
        
        %getting final supercolocalizers
        [red_clusters_ret]=supercoloc_function(gr_super_maybe,red_super_maybe,path_cluster_green,path_cluster_red,ns,ne,30,50,100);
        
        if red_clusters_ret(1)>0
            
            %making a block
            the_block=[linspace(gr_super_maybe,gr_super_maybe,numel(red_clusters_ret(:,1)))',red_clusters_ret(:,1),red_clusters_ret(:,2)];
            
            if green_ct==0
                the_gr_super_block=the_block;
            else
                the_gr_super_block_tmp=the_gr_super_block;
                clear the_gr_super_block;
                the_gr_super_block=[the_gr_super_block_tmp;the_block];
                clear the_gr_super_block_tmp;
            end
            
            
            %adjust counter
            green_ct=green_ct+1;
            
            %clear statment
            clear the_block;
            
        end
        
        %clear statements
        clear gr_super_maybe; clear idx_red_super; clear red_super_maybe;
        
    end

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%Red Channel%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%making a new definition of highly colocalizing cluster%%%%%%%%%
%%%%%%%%%%%%%%%%%%calling these super-colocalizers%%%%%%%%%%%%%%%%%%%%%%%%%

%matrix of information about red colocalizing clusters
% coloc_final_mat_red(:,1) = red clusters that coloc
% coloc_final_mat_red(:,2) = percentage (by area) colocalization
% coloc_final_mat_red(:,3) = green clusters that coloc


%locate possible highly colocalizing red clusters - super-colocalizers
%based on colocalization percentage
idx_super_red_tmp=find(coloc_final_mat_red(:,2)>50);

%locate possible highly colocalizing green clusters - super-colocalizers -
%based on comparative area
count_mad2=1;
for i=1:numel(idx_super_red_tmp)
    if coloc_final_mat_red(idx_super_red_tmp(i),4) >= coloc_final_mat_red(idx_super_red_tmp(i),5)
        poss_red_super_coloc_tmp(count_mad2,1)=coloc_final_mat_red(idx_super_red_tmp(i),1);
        count_mad2=count_mad2+1;
    end
end

%counter
red_ct=0;

if count_mad2>1

    % removing duplicates
    poss_red_super_coloc=unique(poss_red_super_coloc_tmp,'rows');
    
    %locating the super-colocalizers - red channel
    for n=1:numel(poss_red_super_coloc)
        
        %number of possible red super-cluster - red channel
        red_super_maybe=poss_red_super_coloc(n);
        
        %get the list of green clusters that colocizate
        idx_gr_super=find(coloc_final_mat_red(:,1)==red_super_maybe);
        gr_super_maybe=coloc_final_mat_red(idx_gr_super,3);
        
        %checking if cluster has been used before
        if green_ct>0
            ct_jep1=1;
            for a=1:numel(gr_super_maybe)
                idx_jep1=find(the_gr_super_block(:,1)==gr_super_maybe(a));
                if numel(idx_jep1)>0
                    idx_rem1(ct_jep1,1)=a;
                    ct_jep1=ct_jep1+1;
                end
                clear idx_jep1;
            end
            if ct_jep1>1
                gr_super_maybe(idx_rem1,:)=[];
                clear idx_rem1;
            end
            
            ct_jep2=1;
            for b=1:numel(red_super_maybe)
                idx_jep2=find(the_gr_super_block(:,2)==red_super_maybe(b));
                if numel(idx_jep2)>0
                    idx_rem2(ct_jep2,1)=b;
                    ct_jep2=ct_jep2+1;
                end
                clear idx_jep2;
            end
            if ct_jep2>1
                red_super_maybe(idx_rem2,:)=[];
                clear idx_rem2;
            end
            
        end
        
        
        if numel(gr_super_maybe)>0 && numel(red_super_maybe)>0
            
            %getting final supercolocalizers
            [gr_clusters_ret]=supercoloc_function(red_super_maybe,gr_super_maybe,path_cluster_red,path_cluster_green,ns,ne,30,50,100);
            
            john=1000
            
            
            if gr_clusters_ret(1)>0
                
                %making a block
                the_block=[gr_clusters_ret(:,1),linspace(red_super_maybe,red_super_maybe,numel(gr_clusters_ret(:,1)))',gr_clusters_ret(:,2)];
                
                if red_ct==0
                    the_red_super_block=the_block;
                else
                    the_red_super_block_tmp=the_red_super_block;
                    clear the_red_super_block;
                    the_red_super_block=[the_red_super_block_tmp;the_block];
                    clear the_red_super_block_tmp;
                end
                
                %adjust counter
                red_ct=red_ct+1;
                
                %clear statment
                clear the_block;
                
            end
            
        end
        
        %clear statements
        clear red_super_maybe; clear idx_gr_super; clear gr_super_maybe;
        
    end
    

end

%putting together the matrices of super-colocalizers
if green_ct>0 && red_ct > 0
    the_final_super_block_tmp=[the_gr_super_block;the_red_super_block];
    the_final_super_block=supercoloc_duplicates(path_cluster_green,path_cluster_red,ns,ne,30,50,100,the_final_super_block_tmp);
elseif green_ct>0 && red_ct == 0
    the_final_super_block_tmp=the_gr_super_block;
    the_final_super_block=supercoloc_duplicates(path_cluster_green,path_cluster_red,ns,ne,30,50,100,the_final_super_block_tmp);
elseif green_ct == 0 && red_ct > 0
    the_final_super_block_tmp=the_red_super_block;
    the_final_super_block=supercoloc_duplicates(path_cluster_green,path_cluster_red,ns,ne,30,50,100,the_final_super_block_tmp);
else
    the_final_super_block=0;
end

    
%some notes
%the_gr_super_block(:,1) = green cluster number that are super-colocalizers
%the_gr_super_block(:,2) = red clusters that super colocalize with green
%                          cluster
%the_red_super_block(:,1) = green cluster number that are super-colocalizers
%the_red_super_block(:,2) = red clusters that super colocalize with green
%                           cluster

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%3d renderings%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%



%This are the colobars for curvature
%En's curvature map
ens_curve_map=[1.0000    0.0745    0.6510
    0.9966    0.0778    0.6522
    0.9932    0.0812    0.6535
    0.9898    0.0845    0.6548
    0.9864    0.0879    0.6560
    0.9830    0.0912    0.6573
    0.9796    0.0945    0.6585
    0.9762    0.0979    0.6598
    0.9728    0.1012    0.6611
    0.9694    0.1046    0.6623
    0.9660    0.1079    0.6636
    0.9627    0.1112    0.6648
    0.9593    0.1146    0.6661
    0.9559    0.1179    0.6673
    0.9525    0.1213    0.6686
    0.9491    0.1246    0.6699
    0.9457    0.1279    0.6711
    0.9423    0.1313    0.6724
    0.9389    0.1346    0.6736
    0.9355    0.1379    0.6749
    0.9321    0.1413    0.6762
    0.9287    0.1446    0.6774
    0.9253    0.1480    0.6787
    0.8837    0.1888    0.6941
    0.8422    0.2297    0.7095
    0.8006    0.2706    0.7249
    0.7590    0.3115    0.7403
    0.7174    0.3524    0.7558
    0.6759    0.3932    0.7712
    0.6343    0.4341    0.7866
    0.5927    0.4750    0.8020
    0.5511    0.5159    0.8174
    0.5096    0.5568    0.8328
    0.4680    0.5976    0.8483
    0.4264    0.6385    0.8637
    0.3848    0.6794    0.8791
    0.3433    0.7203    0.8945
    0.3017    0.7612    0.9099
    0.2601    0.8021    0.9253
    0.2186    0.8429    0.9408
    0.1770    0.8838    0.9562
    0.1718    0.8889    0.9581
    0.1667    0.8939    0.9600
    0.1616    0.8990    0.9619
    0.1564    0.9040    0.9638
    0.1513    0.9091    0.9657
    0.1462    0.9141    0.9676
    0.1410    0.9192    0.9695
    0.1359    0.9242    0.9714
    0.1307    0.9293    0.9733
    0.1256    0.9343    0.9752
    0.1205    0.9394    0.9771
    0.1153    0.9444    0.9790
    0.1102    0.9495    0.9809
    0.1051    0.9545    0.9829
    0.0999    0.9596    0.9848
    0.0948    0.9646    0.9867
    0.0896    0.9697    0.9886
    0.0845    0.9747    0.9905
    0.0794    0.9798    0.9924
    0.0742    0.9848    0.9943
    0.0691    0.9899    0.9962
    0.0640    0.9949    0.9981
    0.0588    1.0000    1.0000];

%making first element black
ens_curve_map_mask=[    0         0         0
    0.9966    0.0778    0.6523
    0.9936    0.0808    0.6534
    0.9907    0.0837    0.6545
    0.9877    0.0866    0.6556
    0.9847    0.0895    0.6567
    0.9817    0.0925    0.6578
    0.9788    0.0954    0.6589
    0.9758    0.0983    0.6600
    0.9728    0.1012    0.6611
    0.9699    0.1042    0.6622
    0.9669    0.1071    0.6633
    0.9639    0.1100    0.6644
    0.9610    0.1129    0.6655
    0.9580    0.1158    0.6666
    0.9550    0.1188    0.6677
    0.9520    0.1217    0.6688
    0.9491    0.1246    0.6699
    0.9461    0.1275    0.6710
    0.9431    0.1305    0.6721
    0.9402    0.1334    0.6732
    0.9372    0.1363    0.6743
    0.9342    0.1392    0.6754
    0.9312    0.1422    0.6765
    0.9283    0.1451    0.6776
    0.9253    0.1480    0.6787
    0.8813    0.1913    0.6950
    0.8373    0.2346    0.7113
    0.7932    0.2778    0.7277
    0.7492    0.3211    0.7440
    0.7052    0.3644    0.7603
    0.6612    0.4077    0.7766
    0.6172    0.4510    0.7930
    0.5732    0.4943    0.8093
    0.5291    0.5375    0.8256
    0.4851    0.5808    0.8419
    0.4411    0.6241    0.8583
    0.3971    0.6674    0.8746
    0.3531    0.7107    0.8909
    0.3091    0.7540    0.9072
    0.2650    0.7972    0.9236
    0.2210    0.8405    0.9399
    0.1770    0.8838    0.9562
    0.1714    0.8893    0.9583
    0.1657    0.8949    0.9604
    0.1601    0.9004    0.9625
    0.1545    0.9059    0.9645
    0.1489    0.9115    0.9666
    0.1432    0.9170    0.9687
    0.1376    0.9225    0.9708
    0.1320    0.9281    0.9729
    0.1263    0.9336    0.9750
    0.1207    0.9391    0.9771
    0.1151    0.9447    0.9791
    0.1095    0.9502    0.9812
    0.1038    0.9557    0.9833
    0.0982    0.9613    0.9854
    0.0926    0.9668    0.9875
    0.0869    0.9723    0.9896
    0.0813    0.9779    0.9917
    0.0757    0.9834    0.9937
    0.0701    0.9889    0.9958
    0.0644    0.9945    0.9979
    0.0588    1.0000    1.0000];

%figure out the color
map_easy=[         0         0    0.5625
         0         0    0.6250
         0         0    0.6875
         0         0    0.7500
         0         0    0.8125
         0         0    0.8750
         0         0    0.9375
         0         0    1.0000
         0    0.0625    1.0000
         0    0.1250    1.0000
         0    0.1875    1.0000
         0    0.2500    1.0000
         0    0.3125    1.0000
         0    0.3750    1.0000
         0    0.4375    1.0000
         0    0.5000    1.0000
         0    0.5625    1.0000
         0    0.6250    1.0000
         0    0.6875    1.0000
         0    0.7500    1.0000
         0    0.8125    1.0000
         0    0.8750    1.0000
         0    0.9375    1.0000
         0    1.0000    1.0000
    0.0625    1.0000    0.9375
    0.1250    1.0000    0.8750
    0.1875    1.0000    0.8125
    0.2500    1.0000    0.7500
    0.3125    1.0000    0.6875
    0.3750    1.0000    0.6250
    0.4375    1.0000    0.5625
    0.5000    1.0000    0.5000
    0.5625    1.0000    0.4375
    0.6250    1.0000    0.3750
    0.6875    1.0000    0.3125
    0.7500    1.0000    0.2500
    0.8125    1.0000    0.1875
    0.8750    1.0000    0.1250
    0.9375    1.0000    0.0625
    1.0000    1.0000         0
    1.0000    0.9375         0
    1.0000    0.8750         0
    1.0000    0.8125         0
    1.0000    0.7500         0
    1.0000    0.6875         0
    1.0000    0.6250         0
    1.0000    0.5625         0
    1.0000    0.5000         0
    1.0000    0.4375         0
    1.0000    0.3750         0
    1.0000    0.3125         0
    1.0000    0.2500         0
    1.0000    0.1875         0
    1.0000    0.1250         0
    1.0000    0.0625         0
    1.0000         0         0
    0.9375         0         0
    0.8750         0         0
    0.8125         0         0
    0.7500         0         0
    0.6875         0         0
    0.6250         0         0
    0.5625         0         0
    0.5000         0         0];
map_easy(1,:)=0;


%making a copy of the surface information - Channel 1
node_of_curvature_1=handles.NodeCurvature_1;
face_of_curvature_1=handles.FaceCurvature_1;
node_cl_intensity_1=handles.NodeClusterIntensity_1;
node_intensity_1=handles.NodeIntensityData_1;
node_cl_numbers_1=handles.NodeCluster_1;

%making a copy of the surface information - Channel 2
node_of_curvature_2=handles.NodeCurvature_2;
face_of_curvature_2=handles.FaceCurvature_2;
node_cl_intensity_2=handles.NodeClusterIntensity_2;
node_intensity_2=handles.NodeIntensityData_2;
node_cl_numbers_2=handles.NodeCluster_2;

%marking curvature
[node_cl_1_ret,node_cl_2_ret,node_curve_1_ret,node_curve_2_ret,node_curve_1_ret_rev,node_curve_2_ret_rev]=mask_super_surfaces(node_cl_numbers_1,node_cl_numbers_2,node_of_curvature_1,node_of_curvature_2,the_final_super_block,1,ns,ne);

%curvature plots - surfaces
figure, hold on; title('Really Good Colocalizing Clusters');

subplot(2,3,1);
plotmesh(node_cl_1_ret,face_of_curvature_1); title('Ch1 - really good Coloc Clusters');  shading interp;colormap(map_easy); freezeColors;

subplot(2,3,2);
plotmesh(node_curve_1_ret,face_of_curvature_1);  title('Ch1 - Curv, - Coloc Clusters'); shading interp; caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;

subplot(2,3,3);
plotmesh(node_curve_1_ret_rev,face_of_curvature_1); shading interp; title('Ch1 - Curv, Not Coloc Clusters'); caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;



subplot(2,3,4);
plotmesh(node_cl_2_ret,face_of_curvature_2); title('Ch2 - Coloc Clusters'); shading interp; colormap(map_easy); freezeColors;

subplot(2,3,5);
plotmesh(node_curve_2_ret,face_of_curvature_2); shading interp; title('Ch2 - Curv, - Coloc Clusters'); caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;

subplot(2,3,6);
plotmesh(node_curve_2_ret_rev,face_of_curvature_2); shading interp; title('Ch2 - Curv, Not Coloc Clusters'); caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%Removing super-colocalizers from master lists%%%%%%%%%%%%%%%%%%%%%

%matrix of information about red colocalizing clusters
% coloc_final_mat_red(:,1) = red clusters that coloc
% coloc_final_mat_red(:,2) = percentage (by area) colocalization
% coloc_final_mat_red(:,3) = green clusters that coloc

%matrix of information about green colocalizing clusters
% coloc_final_mat_gr(:,1) = green clusters that coloc
% coloc_final_mat_gr(:,2) = percentage (by area) colocalization
% coloc_final_mat_gr(:,3) = red clusters that coloc

%the_final_super_block

for c=1:numel(the_final_super_block(:,1))
    
    %get some clusters
    gc_now1=the_final_super_block(c,1);
    rc_now1=the_final_super_block(c,2);
    
    %locate green cluster in info matrices - green matrix
    idxg1=find(coloc_final_mat_gr(:,1)==gc_now1);
    if numel(idxg1)>0
        coloc_final_mat_gr(idxg1,:)=[];
    end
    
    %locate green cluster in info matrices - red matrix
    idxg2=find(coloc_final_mat_red(:,3)==gc_now1);
    if numel(idxg2)>0
        coloc_final_mat_red(idxg2,:)=[];
    end
    
    %locate red cluster in info matrices - green matrix
    idxr1=find(coloc_final_mat_gr(:,3)==rc_now1);
    if numel(idxr1)>0
        coloc_final_mat_gr(idxr1,:)=[];
    end
    
    %locate red cluster in info matricues - red matrix
    idxr2=find(coloc_final_mat_red(:,1)==rc_now1);
    if numel(idxr2)>0
        coloc_final_mat_red(idxr2,:)=[];
    end
    
    
    %clear statements
    clear gc_now1; clear rc_now1; 
    clear idxg1; clear idxg2;
    clear idxr1; clear idxr2;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%Getting the Mid Range colocalizers%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%Green Channel%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%locate possible highly colocalizing green clusters - super-colocalizers
%screening 
countR=1;
for a=1:numel(coloc_final_mat_gr(:,2))
    if coloc_final_mat_gr(a,2)>=30 && coloc_final_mat_gr(a,2)<50 
        if coloc_final_mat_gr(a,4)>=coloc_final_mat_gr(a,5)
            idx_super_gr_tmp2(countR,1)=a;
            countR=countR+1;
        end
    end
end

%counter
green_ct=0;

if countR > 1

    % removing duplicates
    poss_gr_super_coloc_tmp2=coloc_final_mat_gr(idx_super_gr_tmp2,1);
    poss_gr_super_coloc2=unique(poss_gr_super_coloc_tmp2,'rows');
    
    %locating the super-colocalizers - green channel
    for m=1:numel(poss_gr_super_coloc2)
        m
        %number of possible green super-cluster - green channel
        gr_super_maybe=poss_gr_super_coloc2(m);
        
        %get the list of red clusters that colocizate
        idx_red_super=find(coloc_final_mat_gr(:,1)==gr_super_maybe);
        red_super_maybe=coloc_final_mat_gr(idx_red_super,3);

        %getting final supercolocalizers
        [red_clusters_ret]=supercoloc_function(gr_super_maybe,red_super_maybe,path_cluster_green,path_cluster_red,ns,ne,30,30,49);
        
        if red_clusters_ret(1)>0

            %making a block
            the_block2=[linspace(gr_super_maybe,gr_super_maybe,numel(red_clusters_ret(:,1)))',(red_clusters_ret)];
            
            if green_ct==0
                the_gr_super_block2=the_block2;
            else
                the_gr_super_block_tmp=the_gr_super_block2;
                clear the_gr_super_block2;
                the_gr_super_block2=[the_gr_super_block_tmp;the_block2];
                clear the_gr_super_block_tmp;
            end
            
            
            %adjust counter
            green_ct=green_ct+1;
            
            %clear statment
            clear the_block2;
            
        end
        
        %clear statements
        clear gr_super_maybe; clear idx_red_super; clear red_super_maybe;
        
    end
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%Getting the mid-range colocalizers%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%red channel%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%matrix of information about red colocalizing clusters
% coloc_final_mat_red(:,1) = red clusters that coloc
% coloc_final_mat_red(:,2) = percentage (by area) colocalization
% coloc_final_mat_red(:,3) = green clusters that coloc


%locate possible highly colocalizing red clusters - super-colocalizers
countB=1;
for b=1:numel(coloc_final_mat_red(:,1))
    if coloc_final_mat_red(b,2)>=30 && coloc_final_mat_red(b,2)<50
        if coloc_final_mat_red(b,4) > coloc_final_mat_red(b,5)
            idx_super_red_tmp2(countB,1)=b;
            countB=countB+1;
        end
    end
end

%counter
red_ct=0;

if countB > 1
    
    % removing duplicates
    poss_red_super_coloc_tmp2=coloc_final_mat_red(idx_super_red_tmp2,1);
    poss_red_super_coloc2=unique(poss_red_super_coloc_tmp2,'rows');
    
    %locating the super-colocalizers - red channel
    for n=1:numel(poss_red_super_coloc2)
        
        %number of possible red super-cluster - red channel
        red_super_maybe=poss_red_super_coloc2(n);
        
        %get the list of green clusters that colocizate
        idx_gr_super=find(coloc_final_mat_red(:,1)==red_super_maybe);
        gr_super_maybe=coloc_final_mat_red(idx_gr_super,3);
        
        %checking if cluster has been used before
        if green_ct>0
            ct_jep1=1;
            for a=1:numel(gr_super_maybe)
                idx_jep1=find(the_gr_super_block2(:,1)==gr_super_maybe(a));
                if numel(idx_jep1)>0
                    idx_rem1(ct_jep1,1)=a;
                    ct_jep1=ct_jep1+1;
                end
                clear idx_jep1;
            end
            if ct_jep1>1
                gr_super_maybe(idx_rem1,:)=[];
                clear idx_rem1;
            end
            
            ct_jep2=1;
            for b=1:numel(red_super_maybe)
                idx_jep2=find(the_gr_super_block2(:,2)==red_super_maybe(b));
                if numel(idx_jep2)>0
                    idx_rem2(ct_jep2,1)=b;
                    ct_jep2=ct_jep2+1;
                end
                clear idx_jep2;
            end
            if ct_jep2>1
                red_super_maybe(idx_rem2,:)=[];
                clear idx_rem2;
            end
            
        end
        
        if numel(red_super_maybe)>0 && numel(gr_super_maybe)>0
          
            %getting final supercolocalizers
            [gr_clusters_ret]=supercoloc_function(red_super_maybe,gr_super_maybe,path_cluster_red,path_cluster_green,ns,ne,30,30,49);
            
            if gr_clusters_ret(1)>0
                
                %making a block
                the_block=[gr_clusters_ret(:,1),linspace(red_super_maybe,red_super_maybe,numel(gr_clusters_ret(:,1)))',gr_clusters_ret(:,2)];
                
                if red_ct==0
                    the_red_super_block2=the_block;
                else
                    the_red_super_block_tmp=the_red_super_block2;
                    clear the_red_super_block2;
                    the_red_super_block2=[the_red_super_block_tmp;the_block];
                    clear the_red_super_block_tmp;
                end
                
                %adjust counter
                red_ct=red_ct+1;
                
                %clear statment
                clear the_block;
                
            end
            
        end
        
        %clear statements
        clear red_super_maybe; clear idx_gr_super; clear gr_super_maybe;
        
    end

end

%putting together the matrices of super-colocalizers
if green_ct>0 && red_ct > 0
    the_final_super_block2_tmp=[the_gr_super_block2;the_red_super_block2];
    the_final_super_block2=supercoloc_duplicates(path_cluster_green,path_cluster_red,ns,ne,30,30,49,the_final_super_block2_tmp);
elseif green_ct>0 && red_ct == 0
    the_final_super_block2_tmp=the_gr_super_block2;
    the_final_super_block2=supercoloc_duplicates(path_cluster_green,path_cluster_red,ns,ne,30,30,49,the_final_super_block2_tmp);
elseif green_ct == 0 && red_ct > 0
    the_final_super_block2_tmp=the_red_super_block2;
    the_final_super_block2=supercoloc_duplicates(path_cluster_green,path_cluster_red,ns,ne,30,30,49,the_final_super_block2_tmp);
else
    the_final_super_block2=0;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%Removing super-colocalizers from master lists%%%%%%%%%%%%%%%%%%%%%

%matrix of information about red colocalizing clusters
% coloc_final_mat_red(:,1) = red clusters that coloc
% coloc_final_mat_red(:,2) = percentage (by area) colocalization
% coloc_final_mat_red(:,3) = green clusters that coloc

%matrix of information about green colocalizing clusters
% coloc_final_mat_g(:,1) = green clusters that coloc
% coloc_final_mat_g(:,2) = percentage (by area) colocalization
% coloc_final_mat_g(:,3) = red clusters that coloc

%the_final_super_block

for c=1:numel(the_final_super_block2(:,1))
    
    %get some clusters
    gc_now1=the_final_super_block2(c,1);
    rc_now1=the_final_super_block2(c,2);
    
    %locate green cluster in info matrices - green matrix
    idxg1=find(coloc_final_mat_gr(:,1)==gc_now1);
    if numel(idxg1)>0
        coloc_final_mat_gr(idxg1,:)=[];
    end
    
    %locate green cluster in info matrices - red matrix
    idxg2=find(coloc_final_mat_red(:,3)==gc_now1);
    if numel(idxg2)>0
        coloc_final_mat_red(idxg2,:)=[];
    end
    
    %locate red cluster in info matrices - green matrix
    idxr1=find(coloc_final_mat_gr(:,3)==rc_now1);
    if numel(idxr1)>0
        coloc_final_mat_gr(idxr1,:)=[];
    end
    
    %locate red cluster in info matricues - red matrix
    idxr2=find(coloc_final_mat_red(:,1)==rc_now1);
    if numel(idxr2)>0
        coloc_final_mat_red(idxr2,:)=[];
    end
    
    
    %clear statements
    clear gc_now1; clear rc_now1; 
    clear idxg1; clear idxg2;
    clear idxr1; clear idxr2;
    
end
    

%marking curvature
[node_cl_1_retA,node_cl_2_retA,node_curve_1_retA,node_curve_2_retA,node_curve_1_ret_revA,node_curve_2_ret_revA]=mask_super_surfaces(node_cl_numbers_1,node_cl_numbers_2,node_of_curvature_1,node_of_curvature_2,the_final_super_block2,1,ns,ne);
the_final_super_block2
%curvature plots - surfaces
figure, title('Medium Good Colocalizing Clusters'); hold on; 

subplot(2,3,1);
plotmesh(node_cl_1_retA,face_of_curvature_1); title('Ch1 - med Coloc Clusters');  shading interp;colormap(map_easy); freezeColors;

subplot(2,3,2);
plotmesh(node_curve_1_retA,face_of_curvature_1);  title('Ch1 - Curv, - Coloc Clusters'); shading interp; caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;

subplot(2,3,3);
plotmesh(node_curve_1_ret_revA,face_of_curvature_1); shading interp; title('Ch1 - Curv, Not Coloc Clusters'); caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;



subplot(2,3,4);
plotmesh(node_cl_2_retA,face_of_curvature_2); title('Ch2 - Coloc Clusters'); shading interp; colormap(map_easy); freezeColors;

subplot(2,3,5);
plotmesh(node_curve_2_retA,face_of_curvature_2); shading interp; title('Ch2 - Curv, - Coloc Clusters'); caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;

subplot(2,3,6);
plotmesh(node_curve_2_ret_revA,face_of_curvature_2); shading interp; title('Ch2 - Curv, Not Coloc Clusters'); caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%Getting the weakest colocalizers%%%%%%%%%%%%%%%%%%%%%

if numel(coloc_final_mat_gr(:,1))>0 && numel(coloc_final_mat_red(:,1))>0
    the_final_super_block3(:,1)=[coloc_final_mat_gr(:,1);coloc_final_mat_red(:,3)];
    the_final_super_block3(:,2)=[coloc_final_mat_gr(:,3);coloc_final_mat_red(:,1)];
elseif numel(coloc_final_mat_gr(:,1))>0 && numel(coloc_final_mat_red(:,1))==0
    the_final_super_block3(:,1)=[coloc_final_mat_gr(:,1)];
    the_final_super_block3(:,2)=[coloc_final_mat_gr(:,3)];
elseif numel(coloc_final_mat_gr(:,1))==0 && numel(coloc_final_mat_red(:,1))>0
    the_final_super_block3(:,1)=[coloc_final_mat_red(:,3)];
    the_final_super_block3(:,2)=[coloc_final_mat_red(:,1)];
end
%marking curvature
[node_cl_1_retB,node_cl_2_retB,node_curve_1_retB,node_curve_2_retB,node_curve_1_ret_revB,node_curve_2_ret_revB]=mask_super_surfaces(node_cl_numbers_1,node_cl_numbers_2,node_of_curvature_1,node_of_curvature_2,the_final_super_block3,1,ns,ne);

%curvature plots - surfaces
figure, title('weakest Colocalizing Clusters'); hold on; 

subplot(2,3,1);
plotmesh(node_cl_1_retB,face_of_curvature_1); title('Ch1 - weakest Coloc Clusters');  shading interp;colormap(map_easy); freezeColors;

subplot(2,3,2);
plotmesh(node_curve_1_retB,face_of_curvature_1);  title('Ch1 - Curv, - Coloc Clusters'); shading interp; caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;

subplot(2,3,3);
plotmesh(node_curve_1_ret_revB,face_of_curvature_1); shading interp; title('Ch1 - Curv, Not Coloc Clusters'); caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;



subplot(2,3,4);
plotmesh(node_cl_2_retB,face_of_curvature_2); title('Ch2 - Coloc Clusters'); shading interp; colormap(map_easy); freezeColors;

subplot(2,3,5);
plotmesh(node_curve_2_retB,face_of_curvature_2); shading interp; title('Ch2 - Curv, - Coloc Clusters'); caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;

subplot(2,3,6);
plotmesh(node_curve_2_ret_revB,face_of_curvature_2); shading interp; title('Ch2 - Curv, Not Coloc Clusters'); caxis([-0.6,0.5]);
colormap(ens_curve_map_mask); freezeColors;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%For Debugging Only%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%Making some paths%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

idxDg=find(path_cluster_green=='\');
idxDr=find(path_cluster_red=='\');

path_Bg=path_cluster_green(1:idxDg(numel(idxDg)-2));
path_Br=path_cluster_red(1:idxDr(numel(idxDr)-2));

path_Bg_e=strcat(path_Bg,'ErodedThreshIms\ErodedThresh');
path_Br_e=strcat(path_Br,'ErodedThreshIms\ErodedThresh');

path_Bg2=path_cluster_green(1:idxDg(numel(idxDg)-3));

%lots of colocalization
gr_path_lots=strcat(path_Bg2,'GreenLots\');
red_path_lots=strcat(path_Bg2,'RedLots\');
ims_for_debug(path_Bg_e,path_Br_e,path_cluster_green,path_cluster_red,gr_path_lots,red_path_lots,the_final_super_block,ns,ne);

%mid range colocalization
gr_path_mid=strcat(path_Bg2,'GreenMid\');
red_path_mid=strcat(path_Bg2,'RedMid\');
ims_for_debug(path_Bg_e,path_Br_e,path_cluster_green,path_cluster_red,gr_path_mid,red_path_mid,the_final_super_block2,ns,ne);

%not that much colocalization
% gr_path_little=strcat(path_Bg2,'GreenLittle\Im');
% red_path_little=strcat(path_Bg2,'RedLittle\Im');
% ims_for_debug(path_Bg_e,path_Br_e,path_cluster_green,path_cluster_red,gr_path_little,red_path_little,the_final_super_block3,ns,ne);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%Removing redundant entries from weak colocalizers%%%%%%%%%%%%%

%removing duplicates from the bad colocalizer matrix
the_final_super_block3_use=unique(the_final_super_block3,'rows');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%Going through weak colocalizers%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%paths to cluster images
% path_cluster_red
% path_cluster_green
% ns
% ne

%counters
count_g=1;
count_r=1;

%make a list of all green and red clusters
for t=ns:ne
   
    %read in images
    im_g1=imread(strcat(path_cluster_green,num2str(t),'.tif'))';
    im_r1=imread(strcat(path_cluster_red,num2str(t),'.tif'))';
    
    %non-zero entries
    idx_g1=find(im_g1>0);
    idx_r1=find(im_r1>0);
    
    %make list - green clusters
    if count_g==1 && numel(idx_g1)>0
       g_kelly_weak=im_g1(idx_g1); 
    elseif count_g>1 && numel(idx_g1)>0
        g_kelly_weak_tmp=g_kelly_weak;
        clear g_kelly_weak;
        g_kelly_weak=[g_kelly_weak_tmp;im_g1(idx_g1)];
        clear g_kelly_weak_tmp;
    end
    
    %iterate counter
    if numel(idx_g1)>0
        count_g=count_g+1;
    end
    
    %make list - red clusters
    if count_r==1 && numel(idx_r1)>0
        r_kelly_weak=im_r1(idx_r1);
    elseif count_r>1 && numel(idx_r1)>0
        r_kelly_weak_tmp=r_kelly_weak;
        clear r_kelly_weak;
        r_kelly_weak=[r_kelly_weak_tmp;im_r1(idx_r1)];
        clear g_kelly_weak_tmp;
    end
    
    %iterate counter
    if numel(idx_r1)>0
        count_r=count_r+1;
    end
    
    %clear statemetns
    clear im_g1; clear im_r1;
    clear idx_g1; clear idx_r1;
    
end

%breaking the non-colocalizing block into 2 matrics
the_bad_block3_gr=the_final_super_block3_use(:,1);
the_bad_block3_red=the_final_super_block3_use(:,2);

%adding a column to each to mark for deletion
the_bad_block3_gr(:,2)=zeros(numel(the_bad_block3_gr(:,1)),1);
the_bad_block3_red(:,2)=zeros(numel(the_bad_block3_red(:,1)),1);


%go through the list of weak colocalizers
for a=1:numel(the_bad_block3_gr(:,1))
    
    %look for clusters
    idx_tory_gr=find(g_kelly_weak(:,1)==the_bad_block3_gr(a,1));
    idx_tory_red=find(r_kelly_weak(:,1)==the_bad_block3_red(a,1));
    
    %marking green clusters for deletion
    if numel(idx_tory_gr)>0 && numel(idx_tory_gr)<=14
        the_bad_block3_gr(a,2)=1;
    end
    
    %marking red clusters for deletion
    if numel(idx_tory_red)>0 && numel(idx_tory_red)<=14
        the_bad_block3_red(a,2)=1;
    end
    
    %clear statements
    clear idx_tory_gr; clear idx_tory_red;

end

%removing elements - green list
idx_bad_gr_100=find(the_bad_block3_gr(:,2)==1);
if numel(idx_bad_gr_100)>0
    the_bad_block3_gr(idx_bad_gr_100,:)=[];
end

%removing elements - red list
idx_bad_red_100=find(the_bad_block3_red(:,2)==1);
if numel(idx_bad_red_100)>0
    the_bad_block3_red(idx_bad_red_100,:)=[];
end

%clearing original matrix
clear the_final_super_block3_use; 

%re-creating matrix
if numel(the_bad_block3_gr(:,1))==numel(the_bad_block3_red(:,1))
    the_final_super_block3_use=[the_bad_block3_gr(:,1),the_bad_block3_red(:,1)];
elseif numel(the_bad_block3_gr(:,1)) > numel(the_bad_block3_red(:,1))
    diff_add=abs(numel(the_bad_block3_gr(:,1))-numel(the_bad_block3_red(:,1)));
    new_red_bad=[the_bad_block3_red(:,1);zeros(diff_add,1)];
    the_final_super_block3_use=[the_bad_block3_gr(:,1),new_red_bad];
else
    diff_add=abs(numel(the_bad_block3_gr(:,1))-numel(the_bad_block3_red(:,1)));
    new_gr_bad=[the_bad_block3_gr(:,1);zeros(diff_add,1)];
    the_final_super_block3_use=[new_gr_bad,the_bad_block3_red(:,1)];
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%making plots of the output%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%the_final_super_block
%the_final_super_block2
%the_final_super_block3_use

%This is the code to make the plots
create_blob_plots(the_final_super_block,the_final_super_block2,the_final_super_block3_use)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%saving outputs%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%locate and create directory
idx_for_blob=strfind(path_coloc_gr,'g0');
path_save_the_blob=strcat(path_coloc_gr(1:(idx_for_blob(1)+2)),'Blob Colocalization\');
mkdir(path_save_the_blob);

%create matrix to save
mat_save_the_blob=[the_final_super_block;the_final_super_block2];

%saving
save(strcat(path_save_the_blob,'Blob_Colocalization_Results.mat'),'mat_save_the_blob');

john=555


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%Making 2d renderings to show%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%extent of colocalization%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %original paths entered by user
% orig_path_send_1=handles.pathname_bd1g;
% orig_path_send_2=handles.pathname_bd2g;
% 
% %breaking apart filename
% idx_e1=find(orig_path_send_1=='\');
% idx_e2=find(orig_path_send_2=='\');
% p1_stem=orig_path_send_1(1:idx_e1((numel(idx_e1)-1)));
% p2_stem=orig_path_send_2(1:idx_e2((numel(idx_e2)-1)));
% 
% %path to eroded boundary images
% p1_er=strcat(p1_stem,'ErodedBoundaryImages\MaskBoundErode');
% p2_er=strcat(p2_stem,'ErodedBoundaryImages\MaskBoundErode');
% 
% %path to boundaries
% p1_bd=strcat(p1_stem,'The_Boundaries\Bound');
% p2_bd=strcat(p2_stem,'The_Boundaries\Bound');
% 
% %get the average eroded boundary images
% [cell_erode_avg_1,frame_list_1]=avg_erode_bound(p1_er,p1_bd,ns,ne);
% [cell_erode_avg_2,frame_list_2]=avg_erode_bound(p2_er,p2_bd,ns,ne); 
% 
% count_264=1;
% 
% for t=ns:ne
%    
%     %read in images - eroded boundary
%     f1_er=imread(strcat(p1_er,num2str(t),'.tif'));
%     f2_er=imread(strcat(p2_er,num2str(t),'.tif'));
%     
%     %reading in images - average eroded boundary - channel 1
%     f1_avg_er_tmp=cell_erode_avg_1(count_264,1);
%     f1_avg_er=f1_avg_er_tmp{1};
%     
%     %reading in images - average eroded boundary - channel 2
%     f2_avg_er_tmp=cell_erode_avg_2(count_264,1);
%     f2_avg_er=f2_avg_er_tmp{1};
%     
%    
%     
%     %pre-allocating for speed
%     if t==ns
%         dim1=size(f1_avg_er,1);
%         dim2=size(f1_avg_er,2);
%         st1_er=zeros(dim1,dim2,ne-ns+1);
%         st2_er=st1_er;
%     end
%         
%     %loading stack
%     st1_er(:,:,count_264)=f1_avg_er;
%     st2_er(:,:,count_264)=f2_avg_er;
%     
%     %iterate counter
%     count_264=count_264+1;
%     
%     %clear statements
%     clear f1_er; clear f2_er;
%     clear f1_avg_er_tmp; clear f1_avg_er;
%     clear f2_avg_er_tmp; clear f2_avg_er;
%     
% end
% 
% %cluster image stacks
% p1_c=strcat(p1_stem,'WholeImageStackClustering\Intensity Stack\Im')
% p2_c=strcat(p2_stem,'WholeImageStackClustering\Intensity Stack\Im')
% count_265=1;
% 
% for s=ns:ne
%     
%     %read in images
%     f1_c=imread(strcat(p1_c,num2str(s),'.tif'));
%     f2_c=imread(strcat(p2_c,num2str(s),'.tif'));
%     
%     %pre-allocating for speed
%     if s==ns
%        dim1A=size(f1_c,1);
%        dim2A=size(f1_c,2);
%        st1_c=zeros(dim1A,dim2A,ne-ns+1);
%        st2_c=zeros(dim1A,dim1A,ne-ns+1);
%     end
%     
%     %loading stacks
%     st1_c(:,:,count_265)=f1_c';
%     st2_c(:,:,count_265)=f2_c';
%     
%     
%    
%     %iterate counter
%     count_265=count_265+1;
%     
%     %clear statements
%     clear f1_c; clear f2_c;
%     
% end
% 
% what_is_intensity1=handles.ClusterIntensity_1
% what_is_intensity2=handles.ClusterIntensity_2
% 
% % for debugging only
% % write_file('Red40_er.tif',40,st2_er)
% % write_file('Red40_cl.tif',40,st2_c)
% 
% %sending to function to draw renderings
% if numel(the_final_super_block)>1
%     graphical_blob_output(st1_er,st1_c,st2_er,st2_c,the_final_super_block,1);
% end
% 
% if numel(the_final_super_block2)>1
%     graphical_blob_output(st1_er,st1_c,st2_er,st2_c,the_final_super_block2,2);
% end
% 
% if numel(the_final_super_block3_use)>1
%     graphical_blob_output(st1_er,st1_c,st2_er,st2_c,the_final_super_block3_use,3);
% end

 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Old code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%image indices
%ns
%ne

%getting the paths to cluster images - green and red channel
% path_cluster_red
% path_cluster_green

% [ret1]=calc_blob_overlap_for_plot(path_cluster_red,path_cluster_green,ns,ne,the_final_super_block);
% [ret2]=calc_blob_overlap_for_plot(path_cluster_red,path_cluster_green,ns,ne,the_final_super_block2);
% [ret3]=calc_blob_overlap_for_plot(path_cluster_red,path_cluster_green,ns,ne,the_final_super_block3_use);

john=10000
john=5000


% --- Executes on button press in pushbutton26.
function pushbutton26_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton26 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%This is a button that I put in to make it a little easier to evaluate how
%well the detection of microvilli worked

%{0 -> -1}
thresh_1_tmp=load('G:\en project\Oct2018 Images\Convexity\Final Program\Microvilli detection tests\ROI45\g0\Final Microvilli Locs test4 thresh 0\Final_villi_info.mat');
thresh_1=thresh_1_tmp.the_final_villi;

%{-0.1 -> -1}
thresh_pt1_tmp=load('G:\en project\Oct2018 Images\Convexity\Final Program\Microvilli detection tests\ROI45\g0\Final Microvilli Locs test2 thresh neg point 1\Final_villi_info.mat');
thresh_pt1=thresh_pt1_tmp.the_final_villi;

%{-0.2 -> -1}
thresh_pt2_tmp=load('G:\en project\Oct2018 Images\Convexity\Final Program\Microvilli detection tests\ROI45\g0\Final Microvilli Locs test 3 thresh neg point 2\Final_villi_info.mat');
thresh_pt2=thresh_pt2_tmp.the_final_villi;

ens_curve_map=[1.0000    0.0745    0.6510
    0.9966    0.0778    0.6522
    0.9932    0.0812    0.6535
    0.9898    0.0845    0.6548
    0.9864    0.0879    0.6560
    0.9830    0.0912    0.6573
    0.9796    0.0945    0.6585
    0.9762    0.0979    0.6598
    0.9728    0.1012    0.6611
    0.9694    0.1046    0.6623
    0.9660    0.1079    0.6636
    0.9627    0.1112    0.6648
    0.9593    0.1146    0.6661
    0.9559    0.1179    0.6673
    0.9525    0.1213    0.6686
    0.9491    0.1246    0.6699
    0.9457    0.1279    0.6711
    0.9423    0.1313    0.6724
    0.9389    0.1346    0.6736
    0.9355    0.1379    0.6749
    0.9321    0.1413    0.6762
    0.9287    0.1446    0.6774
    0.9253    0.1480    0.6787
    0.8837    0.1888    0.6941
    0.8422    0.2297    0.7095
    0.8006    0.2706    0.7249
    0.7590    0.3115    0.7403
    0.7174    0.3524    0.7558
    0.6759    0.3932    0.7712
    0.6343    0.4341    0.7866
    0.5927    0.4750    0.8020
    0.5511    0.5159    0.8174
    0.5096    0.5568    0.8328
    0.4680    0.5976    0.8483
    0.4264    0.6385    0.8637
    0.3848    0.6794    0.8791
    0.3433    0.7203    0.8945
    0.3017    0.7612    0.9099
    0.2601    0.8021    0.9253
    0.2186    0.8429    0.9408
    0.1770    0.8838    0.9562
    0.1718    0.8889    0.9581
    0.1667    0.8939    0.9600
    0.1616    0.8990    0.9619
    0.1564    0.9040    0.9638
    0.1513    0.9091    0.9657
    0.1462    0.9141    0.9676
    0.1410    0.9192    0.9695
    0.1359    0.9242    0.9714
    0.1307    0.9293    0.9733
    0.1256    0.9343    0.9752
    0.1205    0.9394    0.9771
    0.1153    0.9444    0.9790
    0.1102    0.9495    0.9809
    0.1051    0.9545    0.9829
    0.0999    0.9596    0.9848
    0.0948    0.9646    0.9867
    0.0896    0.9697    0.9886
    0.0845    0.9747    0.9905
    0.0794    0.9798    0.9924
    0.0742    0.9848    0.9943
    0.0691    0.9899    0.9962
    0.0640    0.9949    0.9981
    0.0588    1.0000    1.0000];

%get the relevant node matrices
%channel 1
n_curve1=handles.NodeCurvature_1;
f_curve1=handles.FaceCurvature_1;

%making a plot
figure, plotmesh(n_curve1,f_curve1); shading interp; title('Ch1 - Curvature'); caxis([-0.5,0.5]); colorbar;
colormap(ens_curve_map); hold on;

in_arr=thresh_pt1;

for i=min(in_arr(:,5)):max(in_arr(:,5))
   
    idx1=find(in_arr(:,5)==i);
    if numel(idx1)>0
       for j=1:numel(idx1)
          plot3(in_arr(idx1(j),2),in_arr(idx1(j),1),in_arr(idx1(j),3),'k')
          text(in_arr(idx1(j),2),in_arr(idx1(j),1),in_arr(idx1(j),3),num2str(i),'Color','black')
       end
    end
    clear idx1;
end


% --------------------------------------------------------------------
function Untitled_1_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function Untitled_2_Callback(hObject, eventdata, handles)
% hObject    handle to Untitled_2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
