function[surface_area_cluster]=calculate_surface_area_cluster(node_of_curvature_to_save,the_face,zscale_fac)

% inputs
% node_of_curvature_to_save(:,1) = y coordinates of mesh
% node_of_curvature_to_save(:,2) = x coordinates of mesh
% node_of_curvature_to_save(:,3) = z coordinates of mesh
% node_of_curvature_to_save(:,4) = cluster number
% the_face = mapping of how to assemble nodes.
% zscale_fac = 1 or 1.75, it is the scaling for LLS system

%output
%surface_area_cluster(:,1) = the cluster number
%surface_area_cluster(:,2) = the surface area of the cluster in square
%microns

%intializing output
surface_area_cluster=0;

%making things a little simple
x_go=node_of_curvature_to_save(:,1);
y_go=node_of_curvature_to_save(:,2);
z_go=node_of_curvature_to_save(:,3);

%some scaling before unit conversion
%zscale_fac = 1.75 for LLS
%zscale_fac = 1.00 for everything else
% z_go=z_go./zscale_fac;

%unit conversion
%This is strictly assuming that we are using LLS system here at UCSF
%Later I will generalize this
x_go=x_go.*0.1;
y_go=y_go.*0.1;
z_go=z_go.*0.1;

% x_go=x_go.*1;
% y_go=y_go.*1;
% z_go=z_go.*1;


%getting the list of clusters
cluster_list=node_of_curvature_to_save(:,4);
min_c=1;
max_c=max(cluster_list);

%counter
countC=1;

%going through the cluster
for b=min_c:max_c
    
   %get a cluster
   idx_cluster=find(cluster_list==b);
   
   %counter for the face matrix
   count_face=1;
   
   %this is an actual cluster 
   if numel(idx_cluster)>0
       
       for r=1:numel(the_face(:,1))
          
           %look around
           idx1c=find(idx_cluster==the_face(r,1));
           idx2c=find(idx_cluster==the_face(r,2));
           idx3c=find(idx_cluster==the_face(r,3));
           
           %keep the face element
           if numel(idx1c)>0 && numel(idx2c)>0 && numel(idx3c)>0
              
               %store the face
               face_cluster(count_face,1)=the_face(r,1);
               face_cluster(count_face,2)=the_face(r,2);
               face_cluster(count_face,3)=the_face(r,3);
               
               %iterate counter
               count_face=count_face+1;
               
           end

           %clear statements
           clear idx1c; clear idx2c; clear idx3c;
           
       end
       
       if count_face>1
       
           %figuring out the surface area (in units of micron squared)
           for c=1:numel(face_cluster(:,1))
               
               %get the vertices of the triangle
               x1=x_go(face_cluster(c,1));
               y1=y_go(face_cluster(c,1));
               z1=z_go(face_cluster(c,1));
               
               x2=x_go(face_cluster(c,2));
               y2=y_go(face_cluster(c,2));
               z2=z_go(face_cluster(c,2));
               
               x3=x_go(face_cluster(c,3));
               y3=y_go(face_cluster(c,3));
               z3=z_go(face_cluster(c,3));
               
               
               %making vectors with mutual origin
               A=[x1-x2;y1-y2;z1-z2];
               B=[x3-x2;y3-y2;z3-z2];
               
               %cross product
               C = cross(A,B);
               
               %magnitude of cross product
               mag_c=(((C(1).^2)+(C(2).^2)+(C(3).^2)).^0.5);
               
               if c==1
                   tot_surface_area=mag_c*0.5;
               else
                   tot_surface_area=tot_surface_area+(mag_c*0.5);
               end
               
               %clear statements
               clear x1; clear y1; clear z1;
               clear x2; clear y2; clear z2;
               clear x3; clear y3; clear z3;
               clear A; clear B; clear C; clear mag_c;
               
           end
           
           %store the curface area
           surface_area_cluster(countC,1)=b; %cluster number
           surface_area_cluster(countC,2)=tot_surface_area;
           
           %iterate counter
           countC=countC+1;
           
           %clear statements
           clear tot_surface_area; clear face_cluster;
           
       end
       
   end
    
    %clear statements
    clear idx_cluster;
    
end

