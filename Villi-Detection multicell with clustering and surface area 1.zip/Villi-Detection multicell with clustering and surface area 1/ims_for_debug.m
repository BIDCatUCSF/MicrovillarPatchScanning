function[]=ims_for_debug(p_er_g,p_er_r,p_c_g,p_c_r,p_s_g,p_s_r,arr_mast,nStart,nEnd)

mkdir(p_s_g);
mkdir(p_s_r)

for q=nStart:nEnd
    
   %read in the basic images
   im_er_g=imread(strcat(p_er_g,num2str(q),'.tif'));
   im_er_r=imread(strcat(p_er_r,num2str(q),'.tif'));
   im_c_g=imread(strcat(p_c_g,num2str(q),'.tif'));
   im_c_r=imread(strcat(p_c_r,num2str(q),'.tif'));
   
   %blank images to save later
   g_save=zeros(size(im_er_g));
   r_save=zeros(size(im_er_r));
   
   %look for green cluster
   for m=1:numel(arr_mast(:,1))
       idx_boom=find(im_c_g==arr_mast(m,1));
       if numel(idx_boom)>0
           g_save(idx_boom)=im_er_g(idx_boom);
       end
       clear idx_boom;
   end
   
   %look for the red cluster
   for n=1:numel(arr_mast(:,2))
      idx_pow=find(im_c_r==arr_mast(n,2));
      if numel(idx_pow)>0
          r_save(idx_pow)=im_er_r(idx_pow);
      end
      clear idx_pow;
   end
   
   %saving
   imwrite(uint16(g_save),strcat(p_s_g,'Im',num2str(q),'.tif'));
   imwrite(uint16(r_save),strcat(p_s_r,'Im',num2str(q),'.tif'));
   
   %clear statements
   clear im_er_g; clear im_er_r; clear im_c_g; clear im_c_r;
   clear g_save; clear r_save;
  
end








































































