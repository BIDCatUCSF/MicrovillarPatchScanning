function[clust_raw,clust_intens_arr,clust_size_arr]=cluster_calculations(path1,file1)

%outputs
%clust_raw(:,1) = cluster #'s
%clust_raw(:,2) = x coordinates of cluster
%clust_raw(:,3) = y coordinates of cluster
%clust_raw(:,4) = z coordinates of cluster

%clust_intens_arr(:,1) = cluster #
%clust_intens_arr(:,2) = integrated intensity of cluster

%clust_size_arr = cluster #
%clust_size_arr = size of cluster (pixel)


%parsing out the filename
idx_per=find(file1=='.');
numb_try=file1(idx_per(1)-2:idx_per(1)-1);
num_start=str2num(numb_try);

%if the initial value is less than 1
if numel(num_start)==0
   
    %clear statements
    clear num_start; clear numb_try;
    
    %new value
    numb_try=file1(idx_per(1)-1);
    num_start=str2num(numb_try);
    
end


%figuring out how many files there are
a=dir([path1,'*.mat']);
num_ims=numel(a);

%ending index
num_end=num_start+num_ims-1;


%getting the path to the intensity images masked by the eroded boundary
idx_dash=find(path1=='\');
path_stem_tmp=path1(1:idx_dash(numel(idx_dash)-1));
%path_raw=strcat(path_stem_tmp,'ErodedBoundaryImages\MaskBoundErode');
path_raw=strcat(path_stem_tmp,'ErodedThreshIms\ErodedThresh');

%getting the path to the cluster images
path_clust=strcat(path_stem_tmp,'WholeImageStackClustering\Intensity Stack\Im');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%Putting together the information%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%from the clustering%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%counter
count1=1;

%getting a list of the cluster #'s
for k=num_start:num_end

    %read in a cluster image
    im_cl=imread(strcat(path_clust,num2str(k),'.tif'));
    im_cl=double(im_cl);
    
    %finding non-zero entries
    idx_en=find(im_cl>0);
    
    %getting coordinates
    [y_en,x_en]=ind2sub(size(im_cl),idx_en);
    z_en_tmp=linspace(k,k,numel(idx_en));
    z_en=z_en_tmp';
    
    %storing cluster number
    if count1==1
       clust_raw(:,1)=im_cl(idx_en); 
       clust_raw(:,2)=x_en;
       clust_raw(:,3)=y_en;
       clust_raw(:,4)=z_en;
    else
        clust_raw_tmp=clust_raw;
        clear clust_raw;
        clust_raw(:,1)=[clust_raw_tmp(:,1);im_cl(idx_en)];
        clust_raw(:,2)=[clust_raw_tmp(:,2);x_en];
        clust_raw(:,3)=[clust_raw_tmp(:,3);y_en];
        clust_raw(:,4)=[clust_raw_tmp(:,4);z_en];
        clear clust_raw_tmp
    end
    
    %iterate counter
    count1=count1+1;
    
    %clear statement
    clear im_cl; clear idx_en; clear x_en; clear y_en;
    clear z_en; clear z_en_tmp;
end

%cluster extrema
min_c=min(clust_raw(:,1));
max_c=max(clust_raw(:,1));

%another counter
count2=1;

%getting the cluster sizes and intensities
for b=min_c:max_c
    
    %look for a cluster
    idx_h=find(clust_raw(:,1)==b);
    
    %There is a cluster there.
    if numel(idx_h)>0
        
        %store the size
        clust_size_arr(count2,1)=b;
        clust_size_arr(count2,2)=numel(idx_h);
        
        %get xyz coordinates where cluster 'b' is
        x_j=clust_raw(idx_h,2);
        y_j=clust_raw(idx_h,3);
        z_j=clust_raw(idx_h,4);
        
        %initialize another counter
        count3=1;
        
        %calculating intensity from each z slice where cluster 'b' is
        for q=min(z_j):max(z_j)
            
            %checking if there is information in this z slice
            z_check=find(z_j==q);
            
            if numel(z_check)>0
                
                %read in the z slice
                z_jb=imread(strcat(path_raw,num2str(q),'.tif'));
                z_jb=double(z_jb);
                
                %indices to calculate intensity from
                x_idx=x_j(z_check);
                y_idx=y_j(z_check);
                idx_idx=sub2ind(size(z_jb),y_idx,x_idx);
                
                if count3==1
                    intens_now=sum(z_jb(idx_idx));
                    count3=count3+1;
                else
                    intens_now_tmp=intens_now;
                    clear intens_now;
                    intens_now=intens_now_tmp+sum(z_jb(idx_idx));
                    clear intens_now_tmp;
                end

                %clear statements
                clear z_jb; clear x_idx; clear y_idx; clear idx_idx
                
            end
            
            %clear statements
            clear z_check;
            
        end
        
        %store the intensity
        clust_intens_arr(count2,1)=b;
        clust_intens_arr(count2,2)=intens_now;
        
        %iterate counter
        count2=count2+1;
        
        %clear statements
        clear intens_now; clear x_j; clear y_j; clear z_j;
        
    end
    
    %clear statements
    clear idx_h;
    
end