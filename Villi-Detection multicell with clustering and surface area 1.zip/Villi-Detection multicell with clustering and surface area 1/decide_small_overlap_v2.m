function[ret_flag]=decide_small_overlap_v2(cv_villus_overlap,cv_host,cv_other,small_merge_thresh)

%inputs
%cv_villus_overlap = curvature of overlapping node
%cv_host = curvature of overlap villus #1
%cv_other = curvature of other overlapping villi (not #1)
%num_v_host = villus number of overlap villus #1
%num_v_other = villi number of other overlapping villi (not #1)
%small_merge_thresh = (0->100) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Deciding what to put together%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%host - villus 1
host_flag=0;
del_c_host=abs(cv_host-cv_villus_overlap)
check1=abs(((del_c_host/cv_host)*100))
if check1<=small_merge_thresh
    host_flag=1;
end

%other villi
other_flag=0;
for q=1:numel(cv_other)
    del_c_other=abs(cv_other(q)-cv_villus_overlap)
    check2=abs(((del_c_other/cv_other(q))*100))
    if check2<=small_merge_thresh
        other_flag=1;
    else
        other_flag=0;
    end
    
    %clear statements
    clear del_c_other; clear check2;
    
end

%decide on merge
count_merge=1;

for r=1:numel(cv_other)
    %merge
    if host_flag==1 || other_flag==1
         count_merge=count_merge+1;
    end
        
end

%add host villus
if count_merge>1
    ret_flag=1;
else
    ret_flag=0;
end
























