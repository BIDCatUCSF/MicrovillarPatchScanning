function[in1]=merge_small_villi_overlap_v2(in1_in,small_merge_thresh_input)

%At this point of villi detection, there are basically single nodes here
%and there that overlap between nearby villi.
%Villi which largely over with other villi have already been considered in
%previous step.
%This function decides on whether or not to combine villi based on these
%overlapping nodes

%in1_in(:,1) = y coordinates of villi node
%in1_in(:,2) = x coordinates of villi node
%in1_in(:,3) = z coordinates of villi node
%in1_in(:,4) = initial villi number (integer)
%in1_in(:,5) = '1' or '0' indicating whether or no this is center
%in1_in(:,6) = curvature
%in1_in(:,7) = number (integer) in this matrix
%in1_in(:,8) = guide to indicate that overlaps
%small_merge_thresh_input = (0->100), threshold for merging small
%overlapping villi

%This code is added only for debugging
% clear all; close all;
% load('AAAin1_for_testing_code.mat');
% in1_sort=sortrows(in1,4);
% clear in1;
% in1=in1_sort;
% in1_for_debug=in1;

%declaring return
in1=in1_in;

for i=min(in1(:,4)):max(in1(:,4))
   
    %look for villus
    idx1=find(in1(:,4)==i);
    
    %counter to combine 
    count_combine=1;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%getting overlap info for this villus%%%%%%%%%%%%%%%%%%%
    
    if numel(idx1)>0
        
        %look for overlap
        mat_1=in1(idx1,:);
        idx2=find(mat_1(:,8)>0); %these are overlapping nodes

        %there is overlap
        if numel(idx2)>0
            
            for j=1:numel(idx2)
                
                %intermediate counter
                count_inter=1;
            
                %curvature of villus in question
                curve_villus=mat_1(idx2(j),6);
                
                %curvature of host villus' peak
                if count_inter==1
                    idx_c=find(mat_1(:,5)==1);
                    [host_villus_curve]=locate_peakmost_curvature(idx_c,mat_1,j,idx2);
                    
                    %storing
                    inter_mat(count_inter,1)=curve_villus; %curvature of overlapping villus
                    inter_mat(count_inter,2)=i; %villus number of host villus
                    inter_mat(count_inter,3)=host_villus_curve; %curvature of host villus (i)
                    count_inter=count_inter+1;
                    
                    %clear statments
                    clear idx_c;
                    
                end
                
                %finding overlapping villi 
                idx_over_tmp=find(in1(:,8)==mat_1(idx2(j),8));
                if numel(idx_over_tmp)>0
                    for k=1:numel(idx_over_tmp)
                       if in1(idx_over_tmp(k),4)~=i
                           
                           %getting this section of matrix
                           idx_sec=find(in1(:,4)==in1(idx_over_tmp(k),4));
                           mat_sec=in1(idx_sec,:);
                           
                           %find peaks
                           idx_c2=find(mat_sec(:,5)==1);
                           
                           %where is overlapping pixel
                           idx2a=find(mat_sec(:,8)==mat_1(idx2(j),8));
                           
                           %locate peak curvature of overlapping villus
                           [other_villus_curve]=locate_peakmost_curvature(idx_c2,mat_sec,1,idx2a);
                           
                           %storing
                           inter_mat(count_inter,1)=curve_villus; %curvature of overlapping villus
                           inter_mat(count_inter,2)=in1(idx_over_tmp(k),4); %villus number of host villus
                           inter_mat(count_inter,3)=other_villus_curve; %curvature of host villus (i)
                           count_inter=count_inter+1;
                           
                           %clear statement
                           clear idx_sec; clear mat_sec; clear idx_c2; clear idx2a;
                           
                       end
                    end
                end

                %at this point, decide on overlap
                if numel(idx_over_tmp)>0
                    
                    %the decision
                    for t=1:(count_inter-2)
                        
                        [ret_flag]=decide_small_overlap_v2(inter_mat(1,1),inter_mat(1,3),inter_mat(count_inter-1,3),small_merge_thresh_input);
                        
                        %mark for combination
                        if ret_flag == 1
                            things_to_combine(count_combine,1)=i
                            things_to_combine(count_combine,2)=inter_mat(count_inter-1,2)
                            count_combine=count_combine+1
                        end
                        
                    end
                    
                end
                
                %clear statements
                clear idx_over_tmp; clear inter_mat;

            end
            
            %combine things after you look through entire villus (i)
            if count_combine>1
                [in1_ret]=finish_small_overlap_merge(in1,things_to_combine);
                clear in1;
                in1=in1_ret;
                clear in1_ret;
            end
            
            
        end
       
        %clear statements
        clear mat_1; clear idx2;
        
    end
    
    %clear statements
    clear idx1;
    
end
                
                %get peak curvature of each overlapping villi
%                 if numel(idx_over_v_num)>0
%                     count_over2=1;
%                    for g=1:numel(idx_over_v_num)
%                        idx_v1=find(in1(:,4)==idx_over_v_num(g));
%                        if numel(idx_v1)>0
%                            
%                            %section
%                            mat_2=in1(idx_v1,:)
%                            
%                            %peaks
%                            idx_c2=find(mat_2(:,5)==1)
%                            
%                            %locate overlapping pixel
%                            idx2a=find(mat_2(:,8)==mat_1(idx2(j),8));
%                            
%                            %get curvature of other villus
%                            [other_villus_curve]=locate_peakmost_curvature(idx_c2,mat_2,1,idx2a)
%                            
%                            %storing
%                            curve_other_villus(count_over2,1)=idx_over_v_num(g);
%                            curve_other_villus(count_over2,2)=other_villus_curve;
%                            
%                            %iterate counter
%                            count_over2=count_over2+1;
%                            
%                            %clear statements
%                            clear mat_2; clear idx_c2; clear idx_2a;
%                        end
%                        %clear statement
%                        clear idx_v1;
%                    end
%                 end
%                 
%                 if count_over2>1
%                     %deciding whether or not to combine villi
%                     in1_new=decide_small_overlap(curve_villus,host_villus_curve,curve_other_villus(:,2),i,curve_other_villus(:,1),mat_1(idx2(j),8),in1);
%                     
%                     %updating
%                     clear in1;
%                     in1=in1_new;
%                     clear in1_new;
%                 end
%                 
%                 %clear statements
%                 clear idx_c; clear idx_over_tmp; clear idx_over_v_num; clear curve_villus;
%             end
%             
%         end
%         
%         %clear statements
%         clear mat_1; clear idx2; clear host_villus_curve;
%         
%     end
%     
%     %clear statement
%     clear idx1; 
%     
% end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%Making a simpler matrix to output%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%"in1_return" is matrix that will be returned

%adding a spot here for debugging
john=5;


%making the villi number sequential and starting at '1'
count_seq=1;
for m=min(in1(:,4)):max(in1(:,4))
   idx_seq=find(in1(:,4)==m);
   if numel(idx_seq)>0 && count_seq==1
       in1_return(:,1)=in1(idx_seq,1);
       in1_return(:,2)=in1(idx_seq,2);
       in1_return(:,3)=in1(idx_seq,3);
       in1_return(:,4)=in1(idx_seq,6);
       in1_return(:,5)=linspace(count_seq,count_seq,numel(idx_seq))';
   else
       in1_return_tmp=in1_return;
       clear in1_return;
       in1_return=[in1_return_tmp;[in1(idx_seq,1),in1(idx_seq,2),in1(idx_seq,3),in1(idx_seq,6),linspace(count_seq,count_seq,numel(idx_seq))']];
       clear in1_return_tmp;
   end
   
   %iterate counter
   if numel(idx_seq)>0
       count_seq=count_seq+1;
   end
   
   %clear statment
   clear idx_seq;
   
end




















%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%My Initial Attempts%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% for i=1:max(in1(:,8))
%    i
%     %get overlapping element
%     idx1=find(in1(:,8)==i);
%     
%     %ok, it is there
%     if numel(idx1)>0
%         
%         %get villi #s that overlap
%         overlap_v_tmp=in1(idx1,4);
%         overlap_v=unique(overlap_v_tmp,'rows');
%         
%         %get x, y and z coordinates for distance calc. later
%         y_over_node=in1(idx1(1),1);
%         x_over_node=in1(idx1(1),2);
%         z_over_node=in1(idx1(1),3);
%         
%         %curvature of overlapping node
%         c_over_node=in1(idx1(1),6);
%         
%         %counter for center
%         count_center=1;
%         
%         %get the curvature of two closest centers
%         for k=1:numel(overlap_v)
%             
%             %is it there?
%             idx2=find(in1(:,4)==overlap_v(k));
%             
%             %yep!
%             if numel(idx2)>0
%                
%                 %part of matrix that has this villus
%                 mat2=in1(idx2,:);
%                
%                 %look for a peak (center)
%                 idx_peak=find(mat2(:,5)==1);
%                 if numel(idx_peak)>0
%                     peak_curve=mat2(idx_peak(1),6);
%                     ypeak=mat2(idx_peak(1),1);
%                     xpeak=mat2(idx_peak(1),2);
%                     zpeak=mat2(idx_peak(1),3);
%                 else
%                     peak_curve=min(mat2(:,6));
%                     idx_loc=find(mat2(:,6)==peak_curve);
%                     ypeak=mat2(idx_loc(1),1);
%                     xpeak=mat2(idx_loc(1),2);
%                     zpeak=mat2(idx_loc(1),3);
%                     clear idx_loc; 
%                 end
%  
%                 %storing information
%                 c_arr(count_center,1)=peak_curve; %curvature of peak
%                 c_arr(count_center,2)=c_over_node; %curvature of node in question
%                 c_arr(count_center,3)=overlap_v(k); %villus number
%                 c_arr(count_center,4)=(((x_over_node-xpeak).^2)+((y_over_node-ypeak).^2)+((z_over_node-zpeak).^2)).^0.5; %distance between overlapping node and peak
%                 
%                 %iterate counter
%                 count_center=count_center+1;
%                 
%                 %clear statements
%                 clear mat2; clear idx_peak; clear peak_curve;
%                 clear xpeak; clear ypeak; clear zpeak;
%                 
%             end
%             
%             %clear statements
%             clear idx2;
%             
%         end
%         
%         %clear statements
%         clear overlap_v_tmp; clear overlap_v; 
%         clear c_over_node; clear x_over_node; clear y_over_node;
%         clear z_over_node;
%         
%     end
%     
%     c_arr
%     
%     %clear statement
%     clear idx1; clear c_arr;
%     
%     
% end
% 
% john=10000


































