function[host_villus]=locate_peakmost_curvature(idx_c,mat_1,j,idx2)

%This is a function written to find the peak (mountain-top) of villus.
%The peak returned is the one closest to the point of overlap
%This function returns the curvature of that peak.

%inputs
%idx_c = row in of mat_1 where peak exist
%mat_1 = section of "in1" matrix with (1) villus I am looking through
%idx2 = rows in mat_1 where overlapping pixels are
%j = index in idx2 where I am looking


if numel(idx_c)>0
    %getting curvature of closes peak
    mat_test=mat_1(idx_c,:)
    dist_test=(((mat_test(:,1)-mat_1(idx2(j),1)).^2)+((mat_test(:,2)-mat_1(idx2(j),2)).^2)+((mat_test(:,3)-mat_1(idx2(j),3)).^2)).^0.5;
    min_dist=min(dist_test);
    idx_min=find(dist_test==min_dist);
    %storing
    host_villus(1)=mat_test(idx_min(1),6); %curvature of peak
    %clear statements
    clear mat_test; clear dist_test; clear min_dist; clear idx_min;
else
    %getting mountain-top from host villus
    idx_not=find(mat_1(:,8)<1);
    %storing
    host_villus(1)=min(mat_1(idx_not,6)); %curvature of peak
    %clear statement
    clear idx_not;
end



















