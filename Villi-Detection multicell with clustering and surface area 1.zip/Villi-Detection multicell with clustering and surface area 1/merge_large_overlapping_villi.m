function[in_arr_ret_final_final]=merge_large_overlapping_villi(in_arr)

%This is a function that merges villi that share a majority of nodes in
%common. This is step 1 (of 2) in assignment of final villi

%in_arr(:,1) = y coordinates of villi node
%in_arr(:,2) = x coordinates of villi node
%in_arr(:,3) = z coordinates of villi node
%in_arr(:,4) = initial villi number (integer)
%in_arr(:,5) = '1' or '0' indicating whether or no this is center
%in_arr(:,6) = curvature
%in_arr(:,7) = number (integer) in this matrix
%in_arr(:,8) = guide to indicate that overlaps

%NB "in_arr" is the "init_villi_ret" matrix from GUI code

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%Compiling the mapping to merge%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%based on large overlap%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%making a copy to add center positions into output
in_arr_c=in_arr;

%initializing output
in_arr_ret_final=0;
in_arr_ret_final_final=0;

%counter 
count_merge=1;

for i=min(in_arr(:,4)):max(in_arr(:,4))
   
    %get a villus
    idx_v=find(in_arr(:,4)==i);
    tot_villus_nodes=numel(idx_v);
    
    %there is villus (habemus villum)
    if numel(idx_v)>0
        
        %do any elements overlap
        idx_over=find(in_arr(idx_v,8)>0);
        
        %something overlaps
        if numel(idx_over)>0
            
            %intermediate counter
            count_inter=1;
            
            for k=1:numel(idx_over)
                
                %get the overlap number
                over_look=in_arr(idx_v(idx_over(k)),8);
                idx_over_look=find(in_arr(:,8)==over_look);
                
                for m=1:numel(idx_over_look)
                   if in_arr(idx_over_look(m),4)~=i
                       overlap_check(count_inter,1)=in_arr(idx_over_look(m),4);
                       count_inter=count_inter+1;
                   end
                end
                
                %clear statements
                clear over_look; clear idx_over_look;
                
            end
            
            %figure out how many instances of other villi
            count_inter2=1;
            for d=min(overlap_check(:,1)):max(overlap_check(:,1))
               idx_john2=find(overlap_check(:,1)==d);
               if numel(idx_john2)>0
                   overlap_check_final(count_inter2,1)=d;
                   overlap_check_final(count_inter2,2)=(numel(idx_john2)/tot_villus_nodes)*100;
                   count_inter2=count_inter2+1;
               end
                clear idx_john2;
            end
            
            %clear statments
            clear overlap_check;
            
            %compiling matrix to map the merge
            idx_merge=find(overlap_check_final(:,2)>=40);
            if numel(idx_merge)>0
                for p=1:numel(idx_merge)
                   map_merge(count_merge,1)=i;
                   map_merge(count_merge,2)=overlap_check_final(idx_merge(p),1);
                   map_merge(count_merge,3)=overlap_check_final(idx_merge(p),2);
                   count_merge=count_merge+1;
                end
            end
            %clear statement
            clear idx_merge;
            
        end
        
        %clear statments
        clear idx_over;  
        clear overlap_check_final;
        
    end
    
    %clear statements
    clear idx_v; clear tot_villus_nodes;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%going through the merge map and re-assembling things%%%%%%%%%%

%some re-working of matrix
map_merge_send(:,1)=map_merge(:,1);
map_merge_send(:,2)=map_merge(:,2);
clear map_merge;

%figuring out how to combine large overlapping clusters
[cell_merge_ret,how_many]=combine_list_function(map_merge_send);

%counter
count_k=1;

%creating matrix to return
for q=1:how_many
    
    %get an element from the cell array
    cell_en_tmp=cell_merge_ret(q,1);
    cell_en=cell_en_tmp{1};
    
    %get elements from "in_arr" matrix
    if numel(cell_en)>0
        
        for a=1:numel(cell_en(:,1))
            
            idx_k1=find(in_arr(:,4)==cell_en(a,1));
            idx_k2=find(in_arr(:,4)==cell_en(a,2));
            
            if a==1
                ele_look=[in_arr(idx_k1,:);in_arr(idx_k2,:)];
            else
                ele_look_tmp=ele_look;
                clear ele_look;
                ele_look=[ele_look_tmp;[in_arr(idx_k1,:);in_arr(idx_k2,:)]];
                clear ele_look_tmp;
            end
            
            %clear statement
            clear idx_k1; clear idx_k2
            
        end
        
        %removing duplicate entries
        ele_look_final=unique(ele_look,'rows');
        ele_look_final_sort=sortrows(ele_look_final,4);
        
        %changing microvilli indices to lowest value
        new_idx=min(ele_look_final_sort(:,4));
        ele_look_final_sort(:,4)=new_idx;
        
        %storing
        if count_k==1
            clear in_arr_ret;
            in_arr_ret=ele_look_final_sort;
        else
            in_arr_ret_tmp=in_arr_ret;
            clear in_arr_ret;
            in_arr_ret=[in_arr_ret_tmp;ele_look_final_sort];
            clear in_arr_ret_tmp;
        end
        
        %keeping track of elements to remove from "in_arr"
        if count_k==1
            ele_remove=unique(ele_look_final(:,4),'rows');
        else
            ele_remove_tmp=ele_remove;
            clear ele_remove;
            ele_remove=[ele_remove_tmp;unique(ele_look_final(:,4),'rows')];
            clear ele_remove_tmp;
        end
        
        %iterate counter
        count_k=count_k+1;
        
        %clear statements
        clear ele_look; clear ele_look_final;
        clear ele_look_final_sort; clear new_idx;
        
    end
    
    %clear statements
    clear cell_en_tmp; clear cell_en;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%fine tuning the matrix to return%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%removing duplicates%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% %for debugging only
% in_arr_ret_check=in_arr_ret;

%clearing a few columns to make this easier
in_arr_ret(:,5)=zeros(numel(in_arr_ret(:,1)),1);
in_arr_ret(:,7)=zeros(numel(in_arr_ret(:,1)),1);
in_arr_ret(:,8)=zeros(numel(in_arr_ret(:,1)),1);

%counter
count_anna=1;

for f=min(in_arr_ret(:,4)):max(in_arr_ret(:,4))
   
    %looking for duplicates 
    idx_jie=find(in_arr_ret(:,4)==f);
    
    if numel(idx_jie)>0
       
        %remove matrix section
        ma_sect=in_arr_ret(idx_jie,:);
        
        %removing duplicate entries
        ma_sect_unique=unique(ma_sect,'rows');
        
        if count_anna==1
            in_arr_ret_final=ma_sect_unique;
        else
            in_arr_ret_final_tmp=in_arr_ret_final;
            clear in_arr_ret_final;
            in_arr_ret_final=[in_arr_ret_final_tmp;ma_sect_unique];
            clear in_arr_ret_final_tmp;
        end
        
        %iterate counter
        count_anna=count_anna+1;
        
        %clear statements
        clear ma_sect; clear ma_sect_unique;
        
        
    end
    
    %clear statements
    clear idx_jie;
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%fine tuning the matrix to return%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%removing used elements from original matrix%%%%%%%%%%%

%list of villi to remove = ele_remove

% %for debugging only
% in_arr_test=in_arr;

%clearing a few columns to make this easier
in_arr(:,5)=zeros(numel(in_arr(:,1)),1);
in_arr(:,7)=zeros(numel(in_arr(:,1)),1);
in_arr(:,8)=zeros(numel(in_arr(:,1)),1);

if numel(ele_remove)>0
    
    for p=1:numel(ele_remove)
        
        idx_bye=find(in_arr(:,4)==ele_remove(p));
        if numel(idx_bye)>0
            in_arr(idx_bye,:)=[];
        end
        
        %clear statements
        clear idx_bye;
        
    end
    
end

%making the final thing to return
in_arr_ret_final_final=[in_arr_ret_final;in_arr];
in_arr_ret_final_final(:,7)=[1:numel(in_arr_ret_final_final(:,1))]';

%adding center positions back in
idx_cs=find(in_arr_c(:,5)==1);

if numel(idx_cs)>0
   
    for a=1:numel(idx_cs)
       
        dist_cs=(in_arr_c(idx_cs(a),1)-in_arr_ret_final_final(:,1))+(in_arr_c(idx_cs(a),2)-in_arr_ret_final_final(:,2))+(in_arr_c(idx_cs(a),3)-in_arr_ret_final_final(:,3));
        idx_kk=find(dist_cs==0);
        if numel(idx_kk)>0
            in_arr_ret_final_final(idx_kk,5)=1;
        end
        clear idx_kk; clear dist_cs;
    end
    
end












































