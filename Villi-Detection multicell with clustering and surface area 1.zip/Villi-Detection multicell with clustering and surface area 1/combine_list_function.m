function[cell_merge,count_264]=combine_list_function(map_merge)

%This is a script written to try out strategies to combine lists of
%overlapping villi.
%It takes the list "map_merge" and merges microvilli together that are
%connected
%"map_merge" specifically contains lists of microvilli which have
%significant overlap with one another.

%inputs
%map_merge(:,1) = microvilli #
%map_merge(:,2) = microvilli #

%output
%cell_merge = cell array that contain lists of numbers of microvilli to
%             combine.
%count_264 = counter to tell me how many elements of cell array are used
%for example, cell_merge(1,1) = {[40,50,60,65]}, which means that these
%should be combined into one microvillus.



%cell array to hold final combination matrix
cell_merge=cell(1000,1);

%counter to load cell array
count_264=1;

%going through the list
while numel(map_merge(:,1))>0
    
    %counter to help me figure out conditions
    count_condition=0;
    
    %grab the first entry
    thing_first=map_merge(1,:);
    
    %remove this entry
    map_merge(1,:)=[];
    
    %look around - column 1 and 2
    idx1=find(map_merge(:,1)==thing_first(1));
    idx2=find(map_merge(:,2)==thing_first(2));
    idx3=find(map_merge(:,1)==thing_first(2));
    idx4=find(map_merge(:,2)==thing_first(1));
    
    
    %condition (1) - single entry
    if numel(idx1)==0 && numel(idx2)==0 && numel(idx3)==0 && numel(idx4)==0
        count_condition=1;
        cell_merge(count_264,1)={thing_first};
        count_264=count_264+1;
    
    %coniditon (2) - repeated entry
    elseif (numel(idx1)==1 && numel(idx2)==1 && idx1(1)==idx2(1)) || (numel(idx3)==1 && numel(idx4)==1 && idx3(1)==idx4(1)) 
            
            %conidtion marker
            count_condition=2;
        
            %store
            cell_merge(count_264,1)={thing_first};
        
            if (numel(idx1)==1 && numel(idx2)==1) 
                %remove element
                map_merge(idx1,:)=[];
                
            elseif (numel(idx3)==1 && numel(idx4)==1) 
                %remove element
                map_merge(idx3,:)=[];
            end

            %iterate counter
            count_264=count_264+1;
            
        
    %condition (3) - complicated case
    elseif (numel(idx1)>0 || numel(idx2)>0 || numel(idx3)>0 || numel(idx4)>0) && count_condition==0

            %doing calculation
            [vec_ret1]=look_through(thing_first,map_merge);
            
            %assembling vector to store
            for q=1:numel(vec_ret1(:,1))
                jor_store(q,1)=map_merge(vec_ret1(q),1);
                jor_store(q,2)=map_merge(vec_ret1(q),2);
            end
            
            %adding the "thing_first" element
            jor_store_tmp=jor_store;
            clear jor_store;
            jor_store=[thing_first;jor_store_tmp];
            clear jor_store_tmp;
            
            %storing
            cell_merge(count_264,1)={jor_store};
            count_264=count_264+1;

            
            %removing
            map_merge(vec_ret1,:)=[];
           
            
            %clear statment
            clear vec_ret1; clear jor_store;

    end
    
    
    
    %clear statemetns
    clear thing_first; clear idx1; clear idx2; clear idx3; clear idx4;
    
end

























