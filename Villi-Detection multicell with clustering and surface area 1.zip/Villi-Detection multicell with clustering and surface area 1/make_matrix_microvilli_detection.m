function[XYZ_2_send_ret]=make_matrix_microvilli_detection(n_curve1_func,f_curve1_func,sorted_prelim_peak_func,q,cell_prelim_peak_func)

%This is a function written to compile the matrices needed for microvilli
%detection.
%Using this function, make the use of parallel processing possible - at
%least, I think it will

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%inputs%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%n_curve1_func - nodes containing curvature information
%f_curve1_func - faces associated with node matrix
%sorted_prelim_peak_func - matrix containing likely peak positions
%q - index I am looking at

%initializing output
XYZ_2_send_ret=[];

%ring 1
ring1_tmp=cell_prelim_peak_func(sorted_prelim_peak_func(q,6),1);
ring1=ring1_tmp{1};

%ring 2
ring2=peak_detection_ring_2_wrapper(ring1,n_curve1_func,f_curve1_func,sorted_prelim_peak_func(q,5));

%ring 3
ring_send=[ring1;ring2];
ring3=peak_detection_ring_2_wrapper(ring_send,n_curve1_func,f_curve1_func,sorted_prelim_peak_func(q,5));
clear ring_send;

if numel(ring2)>0 && numel(ring3)>0

    %creating a matrix to send to protrusion detection
    peak_stuff=[sorted_prelim_peak_func(q,1),sorted_prelim_peak_func(q,2),sorted_prelim_peak_func(q,3),0,sorted_prelim_peak_func(q,4)];
    list_ones=linspace(1,1,numel(ring1(:,1)))';
    list_twos=linspace(2,2,numel(ring2(:,1)))';
    list_threes=linspace(3,3,numel(ring3(:,1)))';
    XYZ_2_send_ret(:,1)=[peak_stuff(:,2);ring1(:,2);ring2(:,2);ring3(:,2)];
    XYZ_2_send_ret(:,2)=[peak_stuff(:,1);ring1(:,1);ring2(:,1);ring3(:,1)];
    XYZ_2_send_ret(:,3)=[peak_stuff(:,3);ring1(:,3);ring2(:,3);ring3(:,3)];
    XYZ_2_send_ret(:,4)=[peak_stuff(:,4);list_ones;list_twos;list_threes];
    XYZ_2_send_ret(:,5)=[peak_stuff(:,5);ring1(:,4);ring2(:,4);ring3(:,4)];
    
else
    XYZ_2_send_ret=[];
    
end






































