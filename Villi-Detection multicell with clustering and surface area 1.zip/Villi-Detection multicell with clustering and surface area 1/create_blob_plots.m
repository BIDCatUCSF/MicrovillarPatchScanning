function[]=create_blob_plots(s1,s2,s3)


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Inputs%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%s1 = first superblock >50% colocalization
%s1(:,1) = green cluster #
%s1(:,2) = red cluster #
%s1(:,3) = colocalization %

%s2 = second superblock - 30% -> 50% colocalization
%s2(:,1) = green cluster #
%s2(:,2) = red cluster #
%s2(:,3) = colocalization %


%s3  = these do not colocalization
%s3(:,1) = green cluster #
%s3(:,2) = red cluster #


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%Consituency Plots%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%flag
the_flag=0;

if numel(s1)>1 && numel(s2)>1
    
    %put together
    all_s=[s1;s2];
    
    %adding column for constituency index
    all_s(:,4)=zeros(numel(all_s(:,1)),1);
    
    %flag
    the_flag=1;
    
elseif numel(s1)>1 && numel(s2)==1
    
    %put together
    all_s=[s1];
    
    %adding column for constituency index
    all_s(:,4)=zeros(numel(all_s(:,1)),1);
    
    %flag
    the_flag=1;
    
elseif numel(s1)==1 && numel(s2)>1
    
    %put together
    all_s=[s2];
    
    %adding column for constituency index
    all_s(:,4)=zeros(numel(all_s(:,1)),1);
    
    %flag
    the_flag=1;
        
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%get green duplicates

if the_flag==1

    min_g=min(all_s(:,1));
    max_g=max(all_s(:,1));
    
    for i=min_g:max_g
        
        %look around
        idxg=find(all_s(:,1)==i);
        
        if numel(idxg)>1
            all_s(idxg,4)=1/numel(idxg);
        end
        
        %clear statement
        clear idxg;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%get red duplicates
    
    min_r=min(all_s(:,2));
    max_r=max(all_s(:,2));
    
    for j=min_r:max_r
        
        %look around
        idxr=find(all_s(:,2)==j);
        
        if numel(idxr)>1
            all_s(idxr,4)=numel(idxr);
        end
        
        %clear statements
        clear idxr;
        
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%the rest
    
    idx_rest=find(all_s(:,4)==0);
    if numel(idx_rest)>0
        all_s(idx_rest,4)=1;
    end
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%the plots
    figure, hold on; title('Colocalization and Constituency');
    plot(all_s(:,3),all_s(:,4),'ko','MarkerSize',12,'LineWidth',1.5);
    xlabel('Colocalization %'); ylabel('Constituency (#Red / #Green)');
    xlim([0,100]); 
    
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%Number of clusters in colocalizing blobs%%%%%%%%%%%%%%%%%%

%there are some colocalizing clusters
if the_flag == 1
    
    %cluster in coloc blobs - green channel
    
    %counter
    count_gr_coloc=0;
    
    for p=min_g:max_g
        idx_tom=find(all_s(:,1)==p);
        if numel(idx_tom)>0
            p
            count_gr_coloc=count_gr_coloc+1;
        end
        clear idx_tom;
    end
    
     %cluster in coloc blobs - red channel
     
     %counter
     count_red_coloc=0;
     
     for s=min_r:max_r
        idx_car=find(all_s(:,2)==s);
        if numel(idx_car)>0
            count_red_coloc=count_red_coloc+1;
        end
        clear idx_car;
     end
     
     %clusters not in coloc blobs - green channel
     
     %counter 
     count_green_no_coloc=0;
     
     %extrema 
     min_g_no=1;%min(s3(:,1));
     max_g_no=max(s3(:,1));
     
     for q=min_g_no:max_g_no
        idx_hank=find(s3(:,1)==q);
        if numel(idx_hank)>0
            count_green_no_coloc=count_green_no_coloc+1;
        end
        clear idx_hank;
         
     end
     
     %clusters not in coloc blobs - red channel
     
     %counter
     count_red_no_coloc=0;
     
     %extrema
     min_r_no=1;%min(s3(:,2));
     max_r_no=max(s3(:,2));
     
     for a=min_r_no:max_r_no
        idx_jep=find(s3(:,2)==a);
        if numel(idx_jep)>0
            count_red_no_coloc=count_red_no_coloc+1;
        end
        clear idx_jep;
         
     end
     
     %total number of clusters
     all_gr_total=count_gr_coloc+count_green_no_coloc;
     all_red_total=count_red_coloc+count_red_no_coloc;
     
     %the bar plot
     the_bars=[count_gr_coloc,all_gr_total,count_red_coloc,all_red_total];
     x=categorical({'Green Coloc.', 'Green All', 'Red Coloc', 'Red All'});
     x=reordercats(x,{'Green Coloc.', 'Green All', 'Red Coloc', 'Red All'});
     figure,
     b=bar(x,the_bars); ylabel('# of clusters');
     b.FaceColor = 'flat';
     b.CData(1,:) = [0.5 0.5 0.5];
     b.CData(2,:) = [0 0 0];
     b.CData(3,:) = [0.5 0.5 0.5];
     b.CData(4,:) = [0 0 0];
     title('# of Clusters in Coloc. Blobs');
     
end















