function[proj2d,proj2d_out,proj2d_x,proj2d_y,proj2d_z]=do_proj4(min_y_arr,max_y_arr,num_images,master_list,x_abs_center)

%This is a function to do one of four 2d projection to help us figure out
%the geometry of the clusters - so we can ditch the ones that are useless

%inputs
%min_y_arr = lowest y of set of calculated boundaries 
%max_y_arr = highest y of set of calculated boundares
%num_images = total number of images
%master_list(:,1) = x coordinates of all clusters
%master_list(:,2) = y coordinates of all clusters
%master_list(:,3) = z coordinates of all clusters
%master_list(:,4) = all intensities at xy coordinates
%master_list(:,5) = intensities in clusters
%master_list(:,6) = cluster numbers

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%extrema stuff for 2d projection
abs_min_y=min(min_y_arr(:,1));
abs_max_y=max(max_y_arr(:,1));

%pre-allocating for speed - intensity projections
proj2d=zeros(num_images,abs_max_y-abs_min_y+1);
proj2d_in=zeros(num_images,abs_max_y-abs_min_y+1);
proj2d_out=zeros(num_images,abs_max_y-abs_min_y+1);

%pre-allocating for speed - coordinate projections
proj2d_x=zeros(num_images,abs_max_y-abs_min_y+1);
proj2d_y=zeros(num_images,abs_max_y-abs_min_y+1);
proj2d_z=zeros(num_images,abs_max_y-abs_min_y+1);

for q=1:num_images
   
    %get the information for this z slice
    idx_list=find(master_list(:,3)==q);
    master_list_tmp=master_list(idx_list,:);
    
    %counter
    count=1;
    
    if numel(idx_list)>0
        
        for g=abs_min_y:abs_max_y
            
            %looking for y coordinate
            idx_look=find(master_list_tmp(:,2)==g);
            
            %counter
            count2=1;
            
            if numel(idx_look)>0
               
                for p=1:numel(idx_look)
                    if master_list_tmp(idx_look(p),1)>x_abs_center
                        
                        %all intensity
                        thing_keep(count2,1)=master_list_tmp(idx_look(p),4);
                        
                        %intensity in cluster
                        thing_keep_in(count2,1)=master_list_tmp(idx_look(p),5);
                        
                        %intensity out of cluster
                        thing_keep_out(count2,1)=master_list_tmp(idx_look(p),6);
                        
                       %storing y coordinate
                       thing_keep_x(count2,1)=master_list_tmp(idx_look(p),1);
                        
                        %iterate counter
                        count2=count2+1;
                        
                    end
                end
                
                %loading projections
                if count2>1
                    
                    %intensity projections
                    proj2d(q,count)=max(thing_keep(:,1));
                    proj2d_in(q,count)=max(thing_keep_in(:,1));
                    proj2d_out(q,count)=max(thing_keep_out(:,1));
                    
                    %coordinate projections
                    proj2d_x(q,count)=(thing_keep_x(1));
                    proj2d_y(q,count)=g;
                    proj2d_z(q,count)=q;
                    
                end
                
                %clear statements
                clear thing_keep; clear thing_keep_out; clear thing_keep_in;
                
            end
            clear idx_look;
            count=count+1;
        end
        
    end
    
    clear idx_list; clear master_list_tmp
    
end









