function[in1A_ret]=finish_small_overlap_merge(in1A,idx_combine)

%This is a function that merge two villi in the master list "in1A". The
%list of villi numbers to combine is in "idx_combine".

%inputs
%in1A(:,1) = y coordinates of villi node
%in1A(:,2) = x coordinates of villi node
%in1A(:,3) = z coordinates of villi node
%in1A(:,4) = initial villi number (integer)
%in1A(:,5) = '1' or '0' indicating whether or no this is center
%in1A(:,6) = curvature
%in1A(:,7) = number (integer) in this matrix
%in1A(:,8) = guide to indicate that overlaps

%idx_combine(:,1) = villi number for host villus
%idx_combine(:,2) = villi number for villus to merge

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%initializing return
in1A_ret=in1A;

%counter 
count_p=1;

%changing
for p=1:numel(idx_combine(:,1))
    %changing
    idx_change=find(in1A(:,4)==idx_combine(p,2));
    if numel(idx_change)>0
        in1A_ret(idx_change,4)=idx_combine(p,1);
        list_check(count_p,1)=idx_combine(p,1);
        count_p=count_p+1;
    end
    clear idx_change;
end

%checking for redundant entries
if count_p>1
    
   %look at the cluster
    for q=1:numel(list_check(:,1))
      idx_all=find(in1A_ret(:,4)==list_check(q,1));
      
      %go through cluster
      if numel(idx_all)>0
          
          %take section out
          mat2=in1A_ret(idx_all,:);
         
          %counter
          count2=1;
          
          while count2<=numel(mat2(:,1))
             
              %distance
              dist_c=(mat2(count2,1)-mat2(:,1))+(mat2(count2,2)-mat2(:,2))+(mat2(count2,3)-mat2(:,3));
              idx_z=find(dist_c==0);
              if numel(idx_z)>1
                  mat2(idx_z(2:numel(idx_z)),:)=[];
              end
              
              %iterate counter
              count2=count2+1;
              
              %clear statements
              clear dist_c; clear idx_z;
              
          end

          %making matrix to output
          in1A_ret(idx_all,:)=[];
          in1A_ret_tmp=in1A_ret;
          clear in1A_ret;
          in1A_ret=[in1A_ret_tmp;mat2];
          
          %clear statements
          clear mat2;
          
      end
      
      %clear statement
      clear idx_all;
      
    end
   
    
    
    
end
























