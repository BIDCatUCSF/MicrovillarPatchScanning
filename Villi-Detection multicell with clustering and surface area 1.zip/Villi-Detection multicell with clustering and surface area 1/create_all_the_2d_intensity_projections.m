function[output_1,output_2,output_3,output_4]=create_all_the_2d_intensity_projections(int_stack,cl_stack,num_images)

%This is a function written to make the four cardinal 2d projections

% %image indices
% ns=1;
% ne=36;
% 
% int_stack='G:\en project\Oct2018 Images\Screen Clusters by Paras\Final_ER1_Avg_Stack.tif';
% cl_stack='G:\en project\Oct2018 Images\Screen Clusters by Paras\Final_Cluster_Stack.tif';
% 
% %get number images
% int_info=imfinfo(cl_stack);
% num_images=numel(int_info);

%cell array to hold boundary and intensity information
cell_intensity=cell(num_images,3);
cell_bound=cell(num_images,1);

%reading in the stacks
for r=1:num_images

   %images
   int_im=int_stack(:,:,r);
   cl_im=cl_stack(:,:,r);

   %some dimensions
   if r==1
       dim1=size(int_im,1);
       dim2=size(int_im,2);
       im_keep=int_im;
       int_tot=int_im;
   else
       int_tot=int_tot+int_im;
   end

   %figuring out center
   idx_c=find(int_im>0);
   [y_c,x_c]=ind2sub(size(cl_im),idx_c);

   %calculate angle
   bound_send=[y_c,x_c];
   [giant_coord_list_tmp]=calc_angle(bound_send,mean(x_c),mean(y_c),im_keep);
   giant_coord_list=sortrows(giant_coord_list_tmp,3);
   
   %storing the initial boundary
   cell_bound(r,1)={[giant_coord_list(:,1),giant_coord_list(:,2)]};
   
   %storing the intensity information - all intensity
   cell_intensity(r,1)={int_im(idx_c)};
   
   %getting the actual centers
   bw_im=poly2mask(giant_coord_list(:,1),giant_coord_list(:,2),dim1,dim2);
   center_tmp=regionprops(bw_im,'Centroid');
   centers=center_tmp.Centroid;
   centers_keep(r,1)=centers(1);
   centers_keep(r,2)=centers(2);
   
   %clear statements
   clear int_im; clear cl_im; clear giant_coord_list; clear giant_coord_list_tmp;
   clear BW; clear idx_c; clear bw_im; clear bound_send;
   clear center_tmp; clear centers; 
   
end

%absolute centers
x_abs_center=mean(centers_keep(:,1));
y_abs_center=mean(centers_keep(:,2));



%getting the actual angle to use
for s=1:num_images

    %images
    int_im=int_stack(:,:,s);
    cl_im=cl_stack(:,:,s);
    
    %get a boundary
    bound_tmp=cell_bound(s,1);
    bound=bound_tmp{1};
    
    %adding z
    bound(:,3)=linspace(s,s,numel(bound(:,1)))';
    
    %getting intensity - raw
    idx_b=sub2ind(size(int_im),bound(:,2),bound(:,1));
    bound(:,4)=int_im(idx_b);
    
    %getting intensity in cluster and out of cluster
    all_intensity=int_im(idx_b);
    all_cluster=cl_im(idx_b);
    
    %version 3 modification
    %int_out_cluster - will contain cluster numbers
    
    for u=1:numel(idx_b)
        if all_cluster(u,1)<1
            int_in_cluster(u,1)=0;
            %int_out_cluster(u,1)=all_intensity(u,1);
            int_out_cluster(u,1)=0;
        else
            int_in_cluster(u,1)=all_intensity(u,1);
            %int_out_cluster(u,1)=0;
            int_out_cluster(u,1)=all_cluster(u,1);
        end
    end

    %adding intensities - in and out of cluster
    bound(:,5)=int_in_cluster;
    bound(:,6)=int_out_cluster;
    
    
    if s==1
        master_list=bound;
    else
        master_list_tmp=master_list;
        clear master_list;
        master_list=[master_list_tmp;bound];
        clear master_list_tmp;
    end
    
    %extrema arrays - x
    min_x_arr(s,1)=min(bound(:,1));
    max_x_arr(s,1)=max(bound(:,1));
    
    %extrema arrays - y
    min_y_arr(s,1)=min(bound(:,2));
    max_y_arr(s,1)=max(bound(:,2));
    
    %clear statements
    clear bound_tmp; clear bound; clear int_im; clear idx_b;
    clear all_intensity; clear all_cluster; clear int_in_cluster;
    clear int_out_cluster;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%functions calls to do the projections%%%%%%%%%%%%%%%%%%%%%%%%

%projection 1
[proj2d_1,proj2d_out_1,proj2d_x_1,proj2d_y_1,proj2d_z_1]=do_proj1(min_x_arr,max_x_arr,num_images,master_list,y_abs_center);

%projection 2
[proj2d_2,proj2d_out_2,proj2d_x_2,proj2d_y_2,proj2d_z_2]=do_proj2(min_x_arr,max_x_arr,num_images,master_list,y_abs_center);

%projection 3
[proj2d_3,proj2d_out_3,proj2d_x_3,proj2d_y_3,proj2d_z_3]=do_proj3(min_y_arr,max_y_arr,num_images,master_list,x_abs_center);

%projection 4
[proj2d_4,proj2d_out_4,proj2d_x_4,proj2d_y_4,proj2d_z_4]=do_proj4(min_y_arr,max_y_arr,num_images,master_list,x_abs_center);

%some notes
% proj2d_# = intensity projections
% proj2d_out_# = cluster projections

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%Creating cell arrays to simplify outputs%%%%%%%%%%%%%%%%%%%%

%cell arrays
output_1=cell(5,1);
output_2=cell(5,1);
output_3=cell(5,1);
output_4=cell(5,1);

%loading
output_1(1,1)={proj2d_1};
output_1(2,1)={proj2d_out_1};
output_1(3,1)={proj2d_x_1};
output_1(4,1)={proj2d_y_1};
output_1(5,1)={proj2d_z_1};

output_2(1,1)={proj2d_2};
output_2(2,1)={proj2d_out_2};
output_2(3,1)={proj2d_x_2};
output_2(4,1)={proj2d_y_2};
output_2(5,1)={proj2d_z_2};

output_3(1,1)={proj2d_3};
output_3(2,1)={proj2d_out_3};
output_3(3,1)={proj2d_x_3};
output_3(4,1)={proj2d_y_3};
output_3(5,1)={proj2d_z_3};

output_4(1,1)={proj2d_4};
output_4(2,1)={proj2d_out_4};
output_4(3,1)={proj2d_x_4};
output_4(4,1)={proj2d_y_4};
output_4(5,1)={proj2d_z_4};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%figures for debugging%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%more figures intensity
% figure, imagesc((proj2d_1)); colormap(gray); colorbar; title('All Intensity 1');
% figure, imagesc((proj2d_2)); colormap(gray); colorbar; title('All Intensity 2');
% figure, imagesc((proj2d_3)); colormap(gray); colorbar; title('All Intensity 3');
% figure, imagesc((proj2d_4)); colormap(gray); colorbar; title('All Intensity 4');
% 
% %more figures - clusters
% figure, imagesc((proj2d_out_1)); colormap(jet); colorbar; title('Clusters Themselves 1');
% figure, imagesc((proj2d_out_2)); colormap(jet); colorbar; title('Clusters Themselves 2');
% figure, imagesc((proj2d_out_3)); colormap(jet); colorbar; title('Clusters Themselves 3');
% figure, imagesc((proj2d_out_4)); colormap(jet); colorbar; title('Clusters Themselves 4');



