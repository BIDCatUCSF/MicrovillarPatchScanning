function[x_c_ret,y_c_ret,z_c_ret]=find_local_center_of_cell(in_arr,node1)

% inputs
% in_arr(:,1) = x coordinates of area being fit
% in_arr(:,2) = y coordinates of area being fit
% in_arr(:,3) = z coordinates of area being fit


%node1 = node curvature matrix of entire t-cell

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% xmin=min(in_arr(:,1));
% xmax=max(in_arr(:,1));
% 
% ymin=min(in_arr(:,2));
% ymax=max(in_arr(:,2));
% 
% zmin=min(in_arr(:,3));
% zmax=max(in_arr(:,3));
% % 
% % figure, hold on;
% % 
% % for i=1:numel(node1(:,1))
% %    
% %     if node1(i,1)>=xmin && node1(i,1)<=xmax && node1(i,2)>=ymin && node1(i,2)<=ymax && node1(i,3)>=zmin && node1(i,3)<=zmax
% %         plot3(node1(i,1),node1(i,2),node1(i,3),'ro','MarkerSize',12,'LineWidth',3.5)
% %     end
% %     
% % end
% 
% stop_here = 1000


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%get the extrema z
z_min=min(in_arr(:,3));
z_max=max(in_arr(:,3));

%sorting the node matrix
node1_sort=sortrows(node1,3);

%getting section of node matrix - minimum z
idx_min_tmp=find(node1_sort(:,3)>=z_min);
if numel(idx_min_tmp)>0
    idx_min=idx_min_tmp(1);
else
    idx_min=1;
end

%getting section of node matrix - maximum z
idx_max_tmp=find(node1_sort(:,3)<=z_max);
if numel(idx_max_tmp)>0
   idx_max=idx_max_tmp(numel(idx_max_tmp)); 
else
    idx_max=numel(node1_sort(:,3));
end

%the centers
x_c_ret=mean(node1_sort(idx_min:idx_max,1));
y_c_ret=mean(node1_sort(idx_min:idx_max,2));
z_c_ret=mean(node1_sort(idx_min:idx_max,3));



























