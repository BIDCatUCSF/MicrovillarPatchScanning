function[node_villi]=make_node_of_cluster(node1,fv)

%This is a function to create a node matrix with villi numbers

%creating a node matrix to return
node_villi=node1;
node_villi(:,4)=0;

for r=1:numel(fv(:,1))
   
    diff_now=(node1(:,1)-fv(r,1))+(node1(:,2)-fv(r,2))+(node1(:,3)-fv(r,3));
    idx_z=find(diff_now==0);
    
    if numel(idx_z)>0
        node_villi(idx_z,4)=fv(r,4);
    end
        
    %clear statements
    clear diff_now; clear idx_z;
  
    
end








