function[]=make_scatter_plot_mixed(min_cl,max_cl,ncurve,nclusterA,ncluster_infoA,is_size,is_switched)


%counter
count=1;

count_curve2=1;

figure, hold on;

for i=min_cl:max_cl

    %find the cluster
    idx1=find(nclusterA(:,4)==i);
    
    %counter
    count_curve=1;
    
    if numel(idx1)>0
   
        %for every point in this cluster, find its position in curvature
        %matrix
        for p=1:numel(idx1)
            
            %coordinates 
            x1=nclusterA(idx1(p),1);
            y1=nclusterA(idx1(p),2);
            z1=nclusterA(idx1(p),3);
            
            %distance
            dist_arr=(((x1-ncurve(:,1)).^2)+((y1-ncurve(:,2)).^2)+((z1-ncurve(:,3)).^2)).^0.5;
            min_dist=min(dist_arr);
            idx_too_close=find(dist_arr==min_dist);
            
            if ncurve(idx_too_close(1),4) ~= 0
                
                %plotting
                plot(ncurve(idx_too_close(1),4),ncluster_infoA(idx1(p),4),'ko','MarkerSize',4,'MarkerEdgeColor',[0.62,0.62,0.62],'LineWidth',4);
                
                %storing for later average
                curv_to_avg_tmp(count_curve,1)=ncurve(idx_too_close(1),4);
                curv_to_avg_tmp(count_curve,2)=ncluster_infoA(idx1(p),4);
                
                %iterate counter
                count_curve=count_curve+1;
                
            end
            
           
            %clear statements
            clear x1; clear y1; clear z1; clear dist_arr; clear min_dist; clear idx_too_close;
            
        end
        
     
    end
    
    %arrays to plot
    if count_curve>1
        
        avg_curve_plot(count_curve2,1)=mean(curv_to_avg_tmp(:,1));
        avg_curve_plot(count_curve2,2)=mean(curv_to_avg_tmp(:,2));
        
        %iterate counter
        count_curve2=count_curve2+1;
        
        %clear statmeents
        clear curv_to_avg_tmp;
        
    end
    
    %clear statements
    clear idx1;
    
end

if is_size == 1 && is_switched == 0
    plot(avg_curve_plot(:,1),avg_curve_plot(:,2),'k+','LineWidth',1.5,'MarkerSize',12);
    ylabel('Size of Cluster - Channel 2'); xlabel('Curvature - Channel 1');xlim([-0.5,0.5]); 
elseif is_size == 1 && is_switched == 1
    plot(avg_curve_plot(:,1),avg_curve_plot(:,2),'k+','LineWidth',1.5,'MarkerSize',12);
    ylabel('Size of Cluster - Channel 1'); xlabel('Curvature - Channel 2');xlim([-0.5,0.5]); 
elseif is_size == 0 && is_switched == 0
    plot(avg_curve_plot(:,1),avg_curve_plot(:,2),'k+','LineWidth',1.5,'MarkerSize',12);
    ylabel('Intensity of Cluster - Channel 2'); xlabel('Curvature - Channel 1');xlim([-0.5,0.5]);
elseif is_size == 0 && is_switched == 1    
    plot(avg_curve_plot(:,1),avg_curve_plot(:,2),'k+','LineWidth',1.5,'MarkerSize',12);
    ylabel('Intensity of Cluster - Channel 1'); xlabel('Curvature - Channel 2');xlim([-0.5,0.5]);
end























