function[]=make_plots_for_coloc(the_arr1,the_arr2,para_compare)

%inputs
%the_arr#(:,1) = cluster #
%the_arr#(:,2) = cluster size (square microns)
%the_arr#(:,3) = cluster integrated intensity
%the_arr#(:,4) = cluster curvature (mean)
%the_arr#(:,5) = cluster curvature (std dev)
%the_arr#(:,6) = colocalization %

%para_compare = integer 
%             = 2 (cluster size)
%             = 3 (integrated intensity)
%             = 4 (curvature)

%get the entries with at least some colocalization
idx_1n=find(the_arr1(:,6)>0);
idx_2n=find(the_arr2(:,6)>0);

%get the parameter to compare to
if para_compare==2 %cluster size
    the_y1=the_arr1(idx_1n,2);
    the_y2=the_arr2(idx_2n,2);
elseif para_compare==3 %integrated intensity
    the_y1=the_arr1(idx_1n,3);
    the_y2=the_arr2(idx_2n,3);
elseif para_compare==4 %curvature
    the_y1=the_arr1(idx_1n,4);
    the_y2=the_arr2(idx_2n,4);
end

%information for the bar plots - channel 1
idx_low_1=find(the_arr1(:,6)<30);
idx_high_1=find(the_arr1(:,6)>60);
if numel(idx_low_1)>0 && numel(idx_high_1)>0
    bar_1=[mean(the_arr1(idx_low_1,para_compare)),mean(the_arr1(idx_high_1,para_compare))];
    std_1_low=std(the_arr1(idx_low_1,para_compare));
    std_1_high=std(the_arr1(idx_high_1,para_compare));
elseif numel(idx_low_1)>0 && numel(idx_high_1)==0
    bar_1=[mean(the_arr1(idx_low_1,para_compare));0];
    std_1_low=std(the_arr1(idx_low_1,para_compare));
    std_1_high=0;
elseif numel(idx_low_1)==0 && numel(idx_high_1)>0
    bar_1=[0;mean(the_arr1(idx_high_1,para_compare))];
    std_1_low=0;
    std_1_high=std(the_arr1(idx_high_1,para_compare));
end


%information for the bar plots - channel 2
idx_low_2=find(the_arr2(:,6)<30);
idx_high_2=find(the_arr2(:,6)>60);

if numel(idx_low_2)>0 && numel(idx_high_2)>0
    bar_2=[mean(the_arr2(idx_low_2,para_compare)),mean(the_arr2(idx_high_2,para_compare))];
    std_2_low=std(the_arr2(idx_low_2,para_compare));
    std_2_high=std(the_arr2(idx_high_2,para_compare));
    
elseif numel(idx_low_2)>0 && numel(idx_high_2)==0
    bar_2=[mean(the_arr2(idx_low_2,para_compare));0];
    std_2_low=std(the_arr2(idx_low_2,para_compare));
    std_2_high=0;
    
elseif numel(idx_low_2)==0 && numel(idx_high_2)>0
    bar_2=[0;mean(the_arr2(idx_high_2,para_compare))];
    std_2_low=0;
    std_2_high=std(the_arr2(idx_high_2,para_compare));
    
end


%making the figure
figure, hold on;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%Green Channel%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subplot(2,2,1); scatter(the_arr1(idx_1n,6),the_y1,'MarkerFaceColor',[0,1,0]); xlabel('Colocalization %');
xlim([0, 100]);
if para_compare==2 %cluster size
    ylabel('Cluster Size (um)');
elseif para_compare==3 %integrated intensity
    ylabel('Integr. Intens.');
elseif para_compare==4 %curvature
    ylabel('Curvature');
end


subplot(2,2,2); hold on; bar(bar_1,'FaceColor',[0,1,0]); 

xlabel('Colocalization %');
if para_compare==2 %cluster size
    ylabel('Cluster Size (um)');
elseif para_compare==3 %integrated intensity
    ylabel('Integr. Intens.');
elseif para_compare==4 %curvature
    ylabel('Curvature');
end
er=errorbar([1,2],bar_1,[std_1_low,std_1_high],[std_1_low,std_1_high]);
er.Color=[0 0 0];
er.LineStyle='none';

the_x_labels={'','<40%','>60%',''};
set(gca,'xticklabel',the_x_labels);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%Red Channel%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


subplot(2,2,3); scatter(the_arr2(idx_2n,6),the_y2,'MarkerFaceColor',[1,0,0]); xlabel('Colocalization %');
xlim([0, 100]);
if para_compare==2 %cluster size
    ylabel('Cluster Size (um)');
elseif para_compare==3 %integrated intensity
    ylabel('Integr. Intens.');
elseif para_compare==4 %curvature
    ylabel('Curvature');
end


subplot(2,2,4); hold on; bar(bar_2,'FaceColor',[1,0,0]); 

xlabel('Colocalization %');
if para_compare==2 %cluster size
    ylabel('Cluster Size (um)');
elseif para_compare==3 %integrated intensity
    ylabel('Integr. Intens.');
elseif para_compare==4 %curvature
    ylabel('Curvature');
end
er=errorbar([1,2],bar_2,[std_2_low,std_2_high],[std_2_low,std_2_high]);
er.Color=[0 0 0];
er.LineStyle='none';

the_x_labels={'','<40%','>60%',''};
set(gca,'xticklabel',the_x_labels);




























