function[node_return,node_reverse_return]=mask_cluster_w_curvature_v3(ncurve1,ncluster2)

%This is the second version of function that masks the positions of clusters in one
%channel onto the curvature of another channel. An example would be masking
%the locations of clusters in Channel A onto the surface of the curvature
%in Channel B.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%This is the revised code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%making the mnimum -0.5
idx_too_low=find(ncurve1(:,4)<=-0.5);
if numel(idx_too_low)>0
    ncurve1(idx_too_low,4)=-0.5;
end

%making the reverse mask to return
node_return=ncluster2;
node_reverse_return=node_return;

for m=1:numel(node_return(:,4))
    
    %calculate distance
    dist_arr=(((node_return(m,2)-ncurve1(:,2)).^2)+((node_return(m,1)-ncurve1(:,1)).^2)+((node_return(m,3)-ncurve1(:,3)).^2)).^0.5;
    
    %find lowest distance
    min_dist=min(dist_arr);
    
     %location of minimum distance
     idx_em=find(dist_arr==min_dist);
    
    if node_return(m,4)>0

        %masking
        node_return(m,4)=ncurve1(idx_em(1),4);

    else
        node_return(m,4)=-0.6;
    end

    %making the total node matrix
    node_reverse_return(m,4)=ncurve1(idx_em(1),4);
    
    %clear statements
    clear dist_arr; clear min_dist; clear idx_em;
    
end



%masking reverse matrix
idx_blank2=find(node_return(:,4)>-0.6);
if numel(idx_blank2)>0
    node_reverse_return(idx_blank2,4)=-0.6;
end




