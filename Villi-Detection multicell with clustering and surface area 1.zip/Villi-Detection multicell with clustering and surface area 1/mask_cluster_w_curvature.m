function[node_return,node_reverse_return]=mask_cluster_w_curvature(ncurve1,ncluster2)

%This is the original function that masks the positions of clusters in one
%channel onto the curvature of another channel. An example would be masking
%the locations of clusters in Channel A onto the surface of the curvature
%in Channel B.

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%This is the original code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%make a new node matrix to return
node_return=ncurve1;


%making the mnimum -0.5
idx_too_low=find(node_return(:,4)<=-0.5);
if numel(idx_too_low)>0
    node_return(idx_too_low,4)=-0.5;
end

node_reverse_return=node_return;

for m=1:numel(node_return(:,4))
    
   %calculate distance
   dist_arr=(((node_return(m,2)-ncluster2(:,2)).^2)+((node_return(m,1)-ncluster2(:,1)).^2)+((node_return(m,3)-ncluster2(:,3)).^2)).^0.5;
    
   %find lowest distance
   min_dist=min(dist_arr);
   
   if min_dist<100
       idx_em=find(dist_arr==min_dist);
   else
       idx_em=[];
   end
    
   if numel(idx_em)>0
       if ncluster2(idx_em(1),4)==0
           node_return(m,4)=-0.6;
       end
   end
    
   %clear statements
   clear dist_arr; clear min_dist; clear idx_em;
   
    
end

%making the reverse node
idx_blank=find(node_return(:,4)>-0.6);

if numel(idx_blank)>0
    node_reverse_return(idx_blank,4)=-0.6;
end




