function[all_ring2]=peak_detection_ring_2_wrapper(curve_ret_values,n_curve1,f_curve1,the_point)

%pre-allocating
all_ring2=[];

%local counter
loc_count=1;

%getting the values of curvature around ring 1
if numel(curve_ret_values)>1
    
    for f=1:numel(curve_ret_values(:,5))
        
        %defining existing coordinates - initially
        if f==1
            pre_exist_pts=[curve_ret_values(:,5);the_point];
        end
        
        %look around
        [curve_ret_values2]=peak_detection_ring_2(n_curve1,f_curve1,curve_ret_values(f,5),pre_exist_pts);
        
        %add to list of previous pts
        if numel(curve_ret_values2)>1
            pre_exist_pts_tmp=pre_exist_pts;
            clear pre_exist_pts;
            pre_exist_pts=[pre_exist_pts_tmp;curve_ret_values2(:,5)];
            clear pre_exist_pts_tmp;
        end
        
        %making a list of node coordinates for ring 2
        if numel(curve_ret_values2)>1
            
            if loc_count==1
                all_ring2=curve_ret_values2;
                loc_count=loc_count+1;
            else
                all_ring2_tmp=all_ring2;
                clear all_ring2
                all_ring2=[all_ring2_tmp;curve_ret_values2];
                clear all_ring2_tmp;
            end
            
        end
        
    end
    
end



















