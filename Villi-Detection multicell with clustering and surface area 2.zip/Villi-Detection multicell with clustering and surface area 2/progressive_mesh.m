function [vertex1,face1] = progressive_mesh(vertex,face,filename)

% progressive_mesh - generate a simplified mesh
%
%   [vertex1,face1] = progressive_mesh(vertex,face,filename);
%