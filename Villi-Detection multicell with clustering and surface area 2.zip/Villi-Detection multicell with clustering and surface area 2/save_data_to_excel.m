function[]=save_data_to_excel(arr_now,file_to_save_xcel)

%This is a simple function written to save the sizes of clusters to excel
%sheets for easy analysis later

%input 
% arr_now(:,1) = cluster number
% arr_now(:,2) = size of cluster
% arr_now(:,3) = integrated intensity of cluster
% arr_now(:,4) = mean curvatyre
% arr_now(:,5) = std. dev. of curvature
% file_excel_save = filename to save data




%counter
count=1
another_counter=1;

        
%cluster numbers
clust_num_now=arr_now(:,1);

%sizes
clust_sizes=arr_now(:,2);

%integrated intensities
ints_now=arr_now(:,3);

%mean curvature
mean_curve_now=arr_now(:,4);

%standard deviation of curvature
std_dev_curve_now=arr_now(:,5);


if another_counter==1
    % adding headers
    str1={'Cluster Number'};
    str2={'Size of Cluster (um^2)'};
    str3={'Integrated Intensity of Cluster'};
    str4={'Mean Curvature'};
    str5={'Std. Dev. Curvature'};
    xlswrite(file_to_save_xcel,str1,count,'A1');
    xlswrite(file_to_save_xcel,str2,count,'B1');
    xlswrite(file_to_save_xcel,str3,count,'C1');
    xlswrite(file_to_save_xcel,str4,count,'D1');
    xlswrite(file_to_save_xcel,str5,count,'E1');
end


%adding data
cloc1_tmp=num2str(1+numel(clust_num_now));
cloc1=strcat('A2:A',cloc1_tmp);
cloc2=strcat('B2:B',cloc1_tmp);
cloc3=strcat('C2:C',cloc1_tmp);
cloc4=strcat('D2:D',cloc1_tmp);
cloc5=strcat('E2:E',cloc1_tmp);

xlswrite(file_to_save_xcel,clust_num_now,count,cloc1);
xlswrite(file_to_save_xcel,clust_sizes,count,cloc2);
xlswrite(file_to_save_xcel,ints_now,count,cloc3);
xlswrite(file_to_save_xcel,mean_curve_now,count,cloc4);
xlswrite(file_to_save_xcel,std_dev_curve_now,count,cloc5);


%iterate counter
another_counter=another_counter+1;


















