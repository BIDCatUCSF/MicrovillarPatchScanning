function[]=save_data_to_excel_two_channel(arr_now1,arr_now2,file_to_save_xcel)

%This is a simple function written to save the sizes of clusters to excel
%sheets for easy analysis later

%input 
% arr_now(:,1) = cluster number
% arr_now(:,2) = size of cluster
% arr_now(:,3) = integrated intensity of cluster
% arr_now(:,4) = mean curvatyre
% arr_now(:,5) = std. dev. of curvature
% file_excel_save = filename to save data




%counter
count=1
another_counter=1;

        
%cluster numbers
clust_num_now_1=arr_now1(:,1);
clust_num_now_2=arr_now2(:,1);

%sizes
clust_sizes_1=arr_now1(:,2);
clust_sizes_2=arr_now2(:,2);

%integrated intensities
ints_now_1=arr_now1(:,3);
ints_now_2=arr_now2(:,3);

%mean curvature
mean_curve_now_1=arr_now1(:,4);
mean_curve_now_2=arr_now2(:,4);

%standard deviation of curvature
std_dev_curve_now_1=arr_now1(:,5);
std_dev_curve_now_2=arr_now2(:,5);

if another_counter==1
    
    
    % adding headers channel 1
    str1={'Ch1: Cluster Number'};
    str2={'Ch1: Size of Cluster (um^2)'};
    str3={'Ch1: Integrated Intensity of Cluster'};
    str4={'Ch1: Mean Curvature'};
    str5={'Ch1: Std. Dev. Curvature'};
    
    % adding headers channel 2
    str6={'Ch2: Cluster Number'};
    str7={'Ch2: Size of Cluster (um^2)'};
    str8={'Ch2: Integrated Intensity of Cluster'};
    str9={'Ch2: Mean Curvature'};
    str10={'Ch2: Std. Dev. Curvature'};
    
    xlswrite(file_to_save_xcel,str1,count,'A1');
    xlswrite(file_to_save_xcel,str2,count,'B1');
    xlswrite(file_to_save_xcel,str3,count,'C1');
    xlswrite(file_to_save_xcel,str4,count,'D1');
    xlswrite(file_to_save_xcel,str5,count,'E1');
    xlswrite(file_to_save_xcel,str6,count,'F1');
    xlswrite(file_to_save_xcel,str7,count,'G1');
    xlswrite(file_to_save_xcel,str8,count,'H1');
    xlswrite(file_to_save_xcel,str9,count,'I1');
    xlswrite(file_to_save_xcel,str10,count,'J1');
    
end


%adding data
cloc1_tmp=num2str(1+numel(clust_num_now_1));
cloc1=strcat('A2:A',cloc1_tmp);
cloc2=strcat('B2:B',cloc1_tmp);
cloc3=strcat('C2:C',cloc1_tmp);
cloc4=strcat('D2:D',cloc1_tmp);
cloc5=strcat('E2:E',cloc1_tmp);

cloc1A_tmp=num2str(1+numel(clust_num_now_2));
cloc6=strcat('F2:F',cloc1A_tmp);
cloc7=strcat('G2:G',cloc1A_tmp);
cloc8=strcat('H2:H',cloc1A_tmp);
cloc9=strcat('I2:I',cloc1A_tmp);
cloc10=strcat('J2:J',cloc1A_tmp);


xlswrite(file_to_save_xcel,clust_num_now_1,count,cloc1);
xlswrite(file_to_save_xcel,clust_sizes_1,count,cloc2);
xlswrite(file_to_save_xcel,ints_now_1,count,cloc3);
xlswrite(file_to_save_xcel,mean_curve_now_1,count,cloc4);
xlswrite(file_to_save_xcel,std_dev_curve_now_1,count,cloc5);

xlswrite(file_to_save_xcel,clust_num_now_2,count,cloc6);
xlswrite(file_to_save_xcel,clust_sizes_2,count,cloc7);
xlswrite(file_to_save_xcel,ints_now_2,count,cloc8);
xlswrite(file_to_save_xcel,mean_curve_now_2,count,cloc9);
xlswrite(file_to_save_xcel,std_dev_curve_now_2,count,cloc10);


%iterate counter
another_counter=another_counter+1;


















