function[n1_thresh,ni2_thresh_ret,nc2_thresh_ret,nc2_thresh]=thresh_and_coloc_hetero_ch_v2(n1,ni2,nc2,small_curve,big_curve,per_include_tmp)

%n1 = node matrix from whole surface
%ni2 = nodes of intensity
%nc2 = nodes of cluster
%small_curve = low curvature threshold
%big curve = high curvature threshold
%per_include_tmp = percentage of cluster that must contain thresholded
%pixels

%making decimal
per_include=per_include_tmp/100;

%declaring threshold nodes
n1_thresh=n1;
ni2_thresh=ni2;


nc2_thresh=nc2;
nc2_thresh_ret=nc2; 
nc2_thresh_ret(:,4)=0;
nc2_thresh(:,4)=0;

ni2_thresh_ret=ni2_thresh;
ni2_thresh_ret(:,4)=0;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%apply curvature threshold to%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%to curvature nodes%%%%%%%%%%%%%%%%%%%%%%%%%%%

for j=1:numel(n1(:,4))
    %find a spot to reject by inputted threshold
   if n1(j,4)<=small_curve || n1(j,4)>=big_curve
        n1_thresh(j,4)=-0.6;  
   end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%applying curvature threshold%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%to cluster and intensity nodes%%%%%%%%%%%%%%%%%%%%%%%

for i=1:numel(n1(:,4))

    %find a spot to reject by inputted threshold
   if n1(i,4)>small_curve && n1(i,4)<big_curve
       
       %calculate distance
       dist_arr=(((n1_thresh(i,2)-ni2_thresh(:,2)).^2)+((n1_thresh(i,1)-ni2_thresh(:,1)).^2)+((n1_thresh(i,3)-ni2_thresh(:,3)).^2)).^0.5;
       
       %find the minimum distance
       min_dist=min(dist_arr);

       %find the minimum
       if min_dist < 7
           idx_em=find(dist_arr<(min_dist+0.25));
           
           if numel(idx_em)>0
               %do the masking - cluster matrix
               nc2_thresh(idx_em,4)=nc2(idx_em,4);
               ni2_thresh_ret(idx_em,4)=ni2(idx_em,4);
           end
           
           %clear statements
           clear idx_em;

       end
       
       %clear statements
       clear dist_arr; clear min_dist; 
       
   end
end

%making some modification to the returned cluster matrix
idx_all=find(nc2_thresh(:,4)>0);

if numel(idx_all)>0
    
    %extrema of cluster number
    min_cl=min(nc2_thresh(idx_all,4));
    max_cl=max(nc2_thresh(idx_all,4));
    
    for k=min_cl:max_cl
        
        %find original cluster
        idx_orig=find(nc2(:,4)==k);
        
        %find how many pixels exist in thresholded image
        idx_remain=find(nc2_thresh==k);

        if numel(idx_orig)>0 && numel(idx_remain)>0
            
            %making these doubles to be on the safe side
            orig_size=double(numel(idx_orig));
            thresh_size=double(numel(idx_remain));

            if (thresh_size/orig_size)>=per_include
                nc2_thresh_ret(idx_orig,4)=nc2(idx_orig,4);
            end

            %clear statements
            clear orig_size; clear thresh_size;
    
        end
        
        %clear statements
        clear idx_orig; clear idx_remain;
        
    end

    %clear statements
    clear min_cl; clear max_cl;
    
end














