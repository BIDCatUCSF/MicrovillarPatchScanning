function[sb_return]=supercoloc_duplicates(path_g,path_r,ns,ne,min_coverage,min_main_coverage,max_main_coverage,sb)

%This is a function written to deal with the case of having duplicate
%entries in superblock - very rare occurence!

%Inputs
% path_g - path to green cluster images with image name prefix
% path_r - path to red cluster images with image name prefix
% ns - starting image index
% ne - ending image index
% min_coverage - minimum amount that two clusters must overlap to be in set
%                (usually 30%)
% min_main_coverage - minimum total overlap of large cluster to be accepted
% max_main_coverage - maximum total overlap of large cluster to be accepted

% clear all; close all;
% ns=34;
% ne=73;
% min_coverage=30;
% max_main_coverage=49;
% min_main_coverage=30;
% path_g='G:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\ROI40\ROI40 latest clustering\Registered\g0\WholeImageStackClustering\Intensity Stack\Im';
% path_r='G:\en project\Oct2018 Images\Domain Size Tests\Initial Tests\Pearson Test Parallel Processing - wide - v1 projection\ROI40\ROI40 latest clustering\Registered\r0\WholeImageStackClustering\Intensity Stack\Im';
% sb=[5,8,32;21,9,38.7434554973822;21,22,38.7434554973822;27,29,47.6821192052980;27,60,47.6821192052980;32,14,31.3432835820896;32,41,31.3432835820896;34,58,38.3838383838384;38,59,38.2352941176471;44,17,34.6153846153846;47,35,43.8596491228070;55,69,35.7142857142857;62,53,43.5897435897436;63,72,37.8378378378378;66,50,48.7804878048781;66,66,48.7804878048781;68,3,37.5000000000000;18,25,38.2978723404255;21,17,41.1347517730496;21,61,41.1347517730496;21,69,41.1347517730496;79,29,36.0655737704918;83,74,46.7532467532468;83,78,46.7532467532468];
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%Looking for duplicates in superblock%%%%%%%%%%%%%%%%%%%%%%

%remove duplicates
sb_tmp=sb; 
clear sb;
sb=unique(sb_tmp,'rows')

%creating matrix to return
sb_return=sb;

if numel(sb)>1
    
    %add a column to mark for removal
    sb(:,4)=zeros(numel(sb(:,1)),1);
    
    for i=1:numel(sb(:,1))
        
        %get some clusters
        g1=sb(i,1);
        r1=sb(i,2);
        
        %look around
        idxG_tmp=find(sb(:,1)==g1);
        idxR_tmp=find(sb(:,2)==r1);
        
        %see if used twice
        count_ever=1;
        for u=1:numel(idxG_tmp)
            for v=1:numel(idxR_tmp)
                if ((idxG_tmp(u)-idxR_tmp(v))==0) && (u==v)
                    idxG(count_ever)=idxG_tmp(u);
                    idxR(count_ever)=idxR_tmp(v);
                    count_ever=count_ever+1;
                end
            end
        end
        if count_ever==1
            idxG=0;
            idxR=0;
        end
     
            
        
        %is this element repeated
        if numel(idxG)>1 && numel(idxR)>1
            
            idxG=idxG';
            idxR=idxR';
        
            g1
            r1
            
            %colocalization %'s
            coloc_p=sb(idxG,3);
            
            %maximum colocalization percentage
            max_coloc=max(coloc_p);
            
            %counter
            countA=1;
            
            %grab elements with lower coloc %
            for k=1:numel(idxG)
                if coloc_p(k)~=max_coloc
                   idx_remove_tmp(countA,1)=idxG(k);
                   countA=countA+1;
                end
            end
            
            %look through and see if blob needs to be removed
            for f=1:(countA-1)
                
               %the spot
               g0=sb(idx_remove_tmp(f),1); 
               r0=sb(idx_remove_tmp(f),2); 
               p0=sb(idx_remove_tmp(f),3);
               
               %counters
               count_ud=1;

               %get blob
               %look above
               for g=1:10
                  if (idx_remove_tmp(f)-g)>0
                    if sb(idx_remove_tmp(f)-g,1)==g0 && sb(idx_remove_tmp(f)-g,3)==p0 
                        idx_think(count_ud)=idx_remove_tmp(f)-g;
                        count_ud=count_ud+1;
                    elseif sb(idx_remove_tmp(f)-g,2)==r0 && sb(idx_remove_tmp(f)-g,3)==p0
                        idx_think(count_ud)=idx_remove_tmp(f)-g;
                        count_ud=count_ud+1;
                    end
                  end
               end
               
               %get blob
               %look below
               for q=1:10
                  if (idx_remove_tmp(f)+q)<=numel(sb(:,1))
                    if sb(idx_remove_tmp(f)+q,1)==g0 && sb(idx_remove_tmp(f)+q,3)==p0 
                        idx_think(count_ud)=idx_remove_tmp(f)+q;
                        count_ud=count_ud+1;
                    elseif sb(idx_remove_tmp(f)+q,2)==r0 && sb(idx_remove_tmp(f)+q,3)==p0
                        idx_think(count_ud)=idx_remove_tmp(f)+q;
                        count_ud=count_ud+1;
                    end
                  end
               end
               
               %mark initial spot for removal
               sb(idx_remove_tmp(f),4)=1; 
               
               %take blob and do overlap calculation
               if count_ud>1
                   
                   %the blob 
                   the_blob_check=sb(idx_think,:);
                   
                   %which way
                   gA=the_blob_check(1,1);
                   rA=the_blob_check(1,2);
                   idx_sA=find(the_blob_check(:,1)==gA);
                   idx_sB=find(the_blob_check(:,2)==rA);
                   
                   %do overlap calculation
                   if numel(idx_sA)>1
                       [red_clusters_ret1]=supercoloc_function(gA,the_blob_check(idx_sA,2),path_g,path_r,ns,ne,min_coverage,min_main_coverage,max_main_coverage);
                       if numel(red_clusters_ret1)==0
                           %mark initial spot for removal
                            sb(idx_think,4)=1; 
                       else
                           sb(idx_think,3)=red_clusters_ret1(1,2); 
                       end
                   elseif numel(idx_sB)>1
                       [gr_clusters_ret1]=supercoloc_function(rA,the_blob_check(idx_sB,1),path_r,path_gr,ns,ne,min_coverage,min_main_coverage,max_main_coverage);
                       if numel(gr_clusters_ret1)==0
                           %mark initial spot for removal
                            sb(idx_think,4)=1; 
                       else
                           sb(idx_think,3)=gr_clusters_ret1(1,2); 
                       end
                   end
                   
                   %clear statements
                   clear the_blob_check; clear gA; clear rA; clear idx_sA; clear idx_sB;
                   
               end
               
               %clear statements
               clear g0; clear r0; clear p0; clear idx_think;
               
            end

            %clear statements
            clear coloc_p; clear max_coloc;
            
        end
        
        
        %clear statements
        clear g1; clear r1; 
        clear idxG; clear idxR;
        clear idxG_tmp; clear idxR_tmp;
        
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%Making the return argument%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

idx_delete=find(sb(:,4)==1);
if numel(idx_delete)>0
    sb_return(idx_delete,:)=[];
end

















