function[n1_thresh,ni1_thresh,nc1_thresh_tmp,nc1_thresh_ret]=thresh_and_coloc_homo_ch(n1,ni1,nc1,small_curve,big_curve,clust_per_include_tmp)

%nc1 = node matrix from whole surface
%ni1 = nodes of intensity
%nc1 = nodes of cluster
%small_curve = low curvature threshold
%big curve = high curvature threshold

%making decimal form
clust_per_include=clust_per_include_tmp/100;

%declaring threshold nodes
n1_thresh=n1;
ni1_thresh=ni1;
nc1_thresh_tmp=nc1;
nc1_thresh_ret=nc1; nc1_thresh_ret(:,4)=0;

%applying curvature threshold
for i=1:numel(n1(:,4))
   if n1(i,4)<small_curve || n1(i,4)>big_curve
       n1_thresh(i,4)=-0.7;
       ni1_thresh(i,4)=0;
       nc1_thresh_tmp(i,4)=0;
   end
end

%modifying node containing clusters
idx_clusters=find(nc1_thresh_tmp(:,4)>0);

if numel(idx_clusters)>0
    
    %extrema of cluster number
    all_clusters=nc1_thresh_tmp(idx_clusters,4);
    min_cluster=min(all_clusters);
    max_cluster=max(all_clusters);
    
    for j=min_cluster:max_cluster
        
        %look and see if cluster is in threshold cluster node matrix
        idx_find_thresh=find(nc1_thresh_tmp(:,4)==j);
        
        if numel(idx_find_thresh)>0
            
            %locate clusters in original cluster node matrix
            idx_find_orig=find(nc1(:,4)==j);
            
            %making these doubles to be on safe side
            nCl_t=double(numel(idx_find_thresh));
            nCl=double(numel(idx_find_orig));
            
            if (nCl_t/nCl)>=clust_per_include
                nc1_thresh_ret(idx_find_orig,4)=j;
            end
            
            %clear statements
            clear idx_find_orig; clear nCl_t; clear nCl;
            
        end
        
        %clear statements
        clear idx_find_thresh;
        
    end

end















