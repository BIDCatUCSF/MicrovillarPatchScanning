function[ret_node,idx_mask]=screen_node_matrix(input_node,curvey_node,min_t,max_t)

%This is a generic function to screen column 4 of the input node matrix
%using the minimum value (min_t) and maximum value (max_t);

%initializing return node
ret_node=input_node;
ret_node(:,4)=-0.6;

%counter to return coordinates masked out
count_mask=1;

for i=1:numel(input_node(:,4))
    
    if input_node(i,4)>=max_t || input_node(i,4)<=min_t
        ret_node(i,4)=-0.6;
        idx_mask(count_mask,1)=i;
        count_mask=count_mask+1;
    else
        ret_node(i,4)=curvey_node(i,4);
    end
end


if count_mask==1
    idx_mask=0;
end
































