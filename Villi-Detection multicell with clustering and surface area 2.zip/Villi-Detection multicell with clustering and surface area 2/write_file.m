function[]=write_file(the_name,num_tiles,the_data)

%making info string
thing_info=strcat('ImageJ=1.52o images=',num2str(num_tiles),' slices=',num2str(num_tiles),' loop=false min=0.0 max=199.0 ');

for k=1:num_tiles
    imwrite(uint16(the_data(:,:,k)),the_name,'WriteMode','append','Compression','none','Description',thing_info);
end

% t = Tiff(the_name,'w');
% 
% tagstruct.ImageLength = size(the_data,1);
% tagstruct.ImageWidth = size(the_data,2);
% tagstruct.Photometric = Tiff.Photometric.RGB;
% tagstruct.BitsPerSample = 16;
% tagstruct.SamplesPerPixel = 73;
% tagstruct.RowsPerStrip = 16;
% tagstruct.PlanarConfiguration = Tiff.PlanarConfiguration.Chunky;
% tagstruct.Software = 'MATLAB';
% setTag(t,tagstruct)
% 
% write(t,the_data);
% 
% close(t);



