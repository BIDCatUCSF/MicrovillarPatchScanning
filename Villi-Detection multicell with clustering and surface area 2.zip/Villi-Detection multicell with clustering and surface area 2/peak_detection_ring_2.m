function[curve_ret2]=peak_detection_ring_2(nodeK,faceK,the_point,existing_points)

%This a function that finds the second ring of points that surround a
%central point 

%inputs
%nodeK - matrix of x y z coordinates and curvature information
%facek - matrix describing how mesh is assembled.
%the point (integer) - listing in face matrix of point from ring 1
%existing points (array of integers) - points in face matrix of ring 1 and
%                                      central point


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%Code%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%locate point in face matrix
idx1e=find(faceK(:,1)==the_point);
idx2e=find(faceK(:,2)==the_point);
idx3e=find(faceK(:,3)==the_point);

%looking through these parts of the mesh
if numel(idx1e)~=0 || numel(idx2e)~=0 || numel(idx3e)~=0
   
    %this is a list of points (refs to  (x,y,z)) coordinates in node matrix
    all_e=[faceK(idx1e,1);faceK(idx1e,2);faceK(idx1e,3);faceK(idx2e,1);faceK(idx2e,2);faceK(idx2e,3);faceK(idx3e,1);faceK(idx3e,2);faceK(idx3e,3)];
    
    %remove points from previous ring and center
    for k=1:numel(existing_points)
        
        %look around
        idx_look=find(all_e==existing_points(k));
        
        %remove entry
        if numel(idx_look)>0
            all_e(idx_look)=[];
        end
        
        %clear statement
        clear idx_look;
         
    end
    
    %storing the surviving points
    if numel(all_e)>0
        
        %pre-allocating for speed
         curve_ret2=zeros(numel(all_e),5);
         curve_ret2=double(curve_ret2);
         
        for r=1:numel(all_e)
        
            curve_ret2(r,1)= nodeK(all_e(r),1);
            curve_ret2(r,2)= nodeK(all_e(r),2);
            curve_ret2(r,3)= nodeK(all_e(r),3);
            curve_ret2(r,4)= nodeK(all_e(r),4);
            curve_ret2(r,5)= all_e(r);
            
            %plotting
%             plot3(nodeK(all_e(r),1),nodeK(all_e(r),2),nodeK(all_e(r),3),'b+','MarkerSize',12,'LineWidth',3);
            
        end
        
    else
        curve_ret2=0;
    end
    
end





































